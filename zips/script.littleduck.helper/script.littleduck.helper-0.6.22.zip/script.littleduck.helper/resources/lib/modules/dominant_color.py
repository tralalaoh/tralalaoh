# -*- coding: utf-8 -*-
"""
dominant_color.py — extract dominant color from the current fanart and set
Window(Home).Property(fanart.bgcolor) for the FanartColorBg skin setting.

Uses the same path-resolution technique as script.embuary.helper's _openimage:
strips image:// wrapper, probes the Kodi thumbnail cache, falls back to direct
access.  Color is obtained by blurring to 200x200 then squeezing to 1x1.
"""
import os
import xbmc
import xbmcgui
import xbmcvfs

try:
    from urllib.parse import unquote as url_unquote
except ImportError:
    from urllib import unquote as url_unquote

try:
    from PIL import Image, ImageFilter
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    xbmc.log('###littleduck dominant_color: PIL not available', 2)

_color_cache = {}   # image_path (original) -> 'FFRRGGBB'


def _openimage(image):
    """
    Resolve any Kodi image path to a PIL Image.
    Mirrors script.embuary.helper image._openimage closely so the same
    cached thumbnails are found.
    """
    if not image:
        return None

    # Strip image:// wrapper + URL-decode  (embuary does the same)
    bare = url_unquote(image.replace('image://', ''))
    if bare.endswith('/'):
        bare = bare[:-1]

    # Build candidate thumbnail-cache paths (Kodi stores thumbs as *.jpg / *.png)
    candidates = []
    for src in [xbmc.getCacheThumbName(bare), xbmc.getCacheThumbName(image)]:
        base = 'special://profile/Thumbnails/%s/' % src[0]
        candidates += [
            base + src[:-4] + '.jpg',
            base + src[:-4] + '.png',
            'special://profile/Thumbnails/Video/%s/%s' % (src[0], src),
        ]

    for cache in candidates:
        if xbmcvfs.exists(cache):
            try:
                return Image.open(xbmcvfs.translatePath(cache))
            except Exception:
                continue

    # Last resort: direct path (works for local library fanart)
    if xbmcvfs.exists(image):
        try:
            return Image.open(xbmcvfs.translatePath(image))
        except Exception:
            pass

    return None


def _extract_color(image_path):
    """
    Blur to 200x200, squeeze to 1x1, return average as 'FFRRGGBB'.
    Darkens by 0.65 so the colour is usable as a readable background.
    Returns '' on failure.
    """
    if image_path in _color_cache:
        return _color_cache[image_path]

    img = _openimage(image_path)
    if img is None:
        return ''

    try:
        img = img.resize((200, 200), Image.LANCZOS)
        img = img.convert('RGB')
        img = img.filter(ImageFilter.GaussianBlur(30))
        col = img.resize((1, 1), Image.LANCZOS).getpixel((0, 0))
        # Darken 65% — keeps the hue visible while staying readable as bg
        r = max(15, int(col[0] * 0.65))
        g = max(15, int(col[1] * 0.65))
        b = max(15, int(col[2] * 0.65))
        color = 'FF%02X%02X%02X' % (r, g, b)

        if len(_color_cache) >= 200:
            for k in list(_color_cache.keys())[:50]:
                del _color_cache[k]
        _color_cache[image_path] = color
        return color

    except Exception as e:
        xbmc.log('###littleduck dominant_color extract: %s' % e, 2)
        return ''


def _get_contrast_text_color(r, g, b):
    def _srgb(c):
        c /= 255.0
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    lum = 0.2126 * _srgb(r) + 0.7152 * _srgb(g) + 0.0722 * _srgb(b)
    white_contrast = (1.05) / (lum + 0.05)
    dark_lum = 0.0045  # FF141515
    dark_contrast = (lum + 0.05) / (dark_lum + 0.05)
    return 'FFFFFFFF' if white_contrast >= dark_contrast * 0.42 else 'FF141515'


def _hsv_to_hex(h, s, v):
    import colorsys
    r, g, b = [int(x * 255) for x in colorsys.hsv_to_rgb(h, s, v)]
    return 'FF%02X%02X%02X' % (r, g, b)


def update_addon_icon_color(icon_path):
    """
    Extract dominant color from an addon icon and set three window properties:
      addon.icon_color     — vivid accent (for focused buttons/borders)
      addon.icon_bg        — very dark shade (for dialog background)
      addon.icon_panel     — dark shade (for description/metadata panel backgrounds)
      addon.icon_textcolor — FFFFFFFF or FF141515 for text on the vivid accent
    """
    import colorsys
    home = xbmcgui.Window(10000)

    def _clear():
        for prop in ('addon.icon_color', 'addon.icon_bg', 'addon.icon_panel', 'addon.icon_textcolor'):
            home.setProperty(prop, '')

    if not PIL_AVAILABLE or not icon_path:
        _clear()
        return

    img = _openimage(icon_path)
    if img is None:
        _clear()
        return

    try:
        img = img.resize((50, 50), Image.LANCZOS).convert('RGB')
        pixels = list(img.getdata())

        color_bins = {}
        for pixel in pixels:
            simple = (pixel[0] // 10, pixel[1] // 10, pixel[2] // 10)
            color_bins[simple] = color_bins.get(simple, 0) + 1

        dom = max(color_bins, key=color_bins.get)
        r, g, b = [x * 10 for x in dom]

        h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)

        # Vivid accent — boost saturation, ensure readable brightness
        s_vivid = min(1.0, s * 1.3)
        v_vivid = max(0.75, v)
        vr, vg, vb = [int(x * 255) for x in colorsys.hsv_to_rgb(h, s_vivid, v_vivid)]
        vivid = 'FF%02X%02X%02X' % (vr, vg, vb)
        text_color = _get_contrast_text_color(vr, vg, vb)

        # Dark dialog background — same hue, high saturation, very low brightness
        bg = _hsv_to_hex(h, min(1.0, s * 1.1), 0.22)

        # Panel background — same hue, slightly less saturation, slightly lighter than bg
        panel = _hsv_to_hex(h, min(1.0, s * 0.95), 0.13)

        home.setProperty('addon.icon_color', vivid)
        home.setProperty('addon.icon_bg', bg)
        home.setProperty('addon.icon_panel', panel)
        home.setProperty('addon.icon_textcolor', text_color)

    except Exception as e:
        xbmc.log('###littleduck addon_icon_color: %s' % e, 2)
        _clear()


def update_fanart_bgcolor(fanart_art_label):
    """
    Called from listitem_monitor whenever the focused item changes.
    Sets (or clears) Window(Home).Property(fanart.bgcolor).
    """
    home = xbmcgui.Window(10000)

    if not PIL_AVAILABLE:
        return
    if not xbmc.getCondVisibility('Skin.HasSetting(FanartColorBg)'):
        home.setProperty('fanart.bgcolor', '')
        return
    if not fanart_art_label:
        home.setProperty('fanart.bgcolor', '')
        return

    color = _extract_color(fanart_art_label)
    home.setProperty('fanart.bgcolor', color)
