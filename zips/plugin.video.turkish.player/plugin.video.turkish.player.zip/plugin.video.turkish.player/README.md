# Turkish Series Player for Kodi

High-performance Kodi player addon for Turkish series with multi-provider support and TMDb Helper integration.

## 🎬 Features

- **Multi-Provider Support:**
  - **3SK Engine** (Arabic audio) - Shows ALL matches, user chooses correct episode
  - **Qrmzi Engine** (Arabic audio) - Auto-verified with forensic matching
  - **Turkish123 Engine** (English subtitles) - Direct URL construction

- **Smart Resolution:**
  - User selection dialog for 3SK (safest approach!)
  - Forensic verification for Qrmzi (prevents wrong series)
  - Intelligent provider fallback
  
- **Optimized Performance:**
  - Multi-threaded stream resolution
  - Smart caching system
  - Android TV optimized (3 workers, 5s timeouts)

- **TMDb Helper Integration:**
  - Seamless browsing experience
  - No duplicate UI
  - Professional integration

## 📺 Installation

### Method 1: Manual Installation (Recommended)

1. Download the latest release zip file
2. In Kodi, go to: **Add-ons → Install from zip file**
3. Select the downloaded zip
4. Wait for "Addon enabled" notification

### Method 2: File Copy

1. Extract addon folder to Kodi's addons directory:
   - **Windows:** `%APPDATA%\Kodi\addons\`
   - **Linux:** `~/.kodi/addons/`
   - **Android:** `/sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons/`
2. Restart Kodi

## ⚙️ Configuration

### Step 1: Install TMDb Helper

This addon requires TMDb Helper for browsing series:

1. Install from official Kodi repository
2. Configure TMDb Helper with your API key (or use default)

### Step 2: Enable Turkish Series Player

1. Open TMDb Helper settings
2. Go to **Players** section
3. Enable **Turkish Series Player**
4. Set priority if you have multiple players

### Step 3: Configure Audio Preference

1. Go to **Add-ons → My Add-ons → Video Add-ons**
2. Select **Turkish Series Player**
3. Open **Settings**:
   - **Use Arabic Audio:** Enable for 3SK/Qrmzi (default: OFF)
   - **Enable 3SK:** User-choice Arabic provider (default: ON)
   - **Enable Qrmzi:** Auto-verified Arabic provider (default: ON)

## 🎯 How It Works

### For Arabic Audio (3SK):

1. User clicks play in TMDb Helper
2. Addon searches ALL Arabic name variants
3. **Selection dialog** shows all matches found
4. User picks the correct episode
5. Stream starts playing

**Why user selection?**  
- Multiple series may have same/similar Arabic names
- User knows best which is correct
- Safest approach - no wrong matches!

### For Arabic Audio (Qrmzi):

1. Addon generates direct URLs from Arabic names
2. **Forensic verification:** Checks if Latin name in image/stream
3. Only plays if verified (prevents wrong series)
4. Automatic - no user interaction needed

### For English Subtitles (Turkish123):

1. Direct URL construction with cached slug
2. Fast playback (1-2 seconds)
3. Falls back to search if needed

## 📋 Supported Content

- ✅ Turkish TV Series
- ✅ Season 1+ episodes
- ✅ Multiple audio/subtitle options
- ❌ Movies (coming soon)

## 🔧 Troubleshooting

### "No stream found"

**Try this:**
1. Check your internet connection
2. Try different audio preference (Arabic ↔ English)
3. Enable debug logging in settings
4. Check Kodi log: `grep "TurkishPlayer\|FastResolver" kodi.log`

### Wrong episode playing (3SK)

**Solution:**
- When selection dialog appears, carefully choose correct series
- Look for episode number and Arabic title
- If multiple match, try each until correct one plays

### Slow loading

**Optimization:**
1. Clear Kodi cache
2. Ensure good internet speed (5+ Mbps)
3. Disable unused providers in settings

## 📱 Platform Support

- ✅ Android TV / Fire Stick (Optimized!)
- ✅ Windows
- ✅ Linux
- ✅ Mac OS
- ✅ iOS (jailbroken)
- ✅ Raspberry Pi

## 🚀 Performance

- **First Episode:** 3-5 seconds
- **User Selection (3SK):** + 5-10 seconds (one-time)
- **Subsequent Episodes:** 1-3 seconds (cached)

## 🔐 Privacy & Security

- No data collection
- No tracking
- No ads
- Open source
- All requests go directly to streaming providers

## 📖 Technical Details

**Architecture:**
- Plugin type: `xbmc.python.pluginsource`
- Provides: `video`
- Python version: 3.0+

**Dependencies:**
- `script.module.requests` >= 2.31.0
- `script.module.beautifulsoup4` >= 4.11.0
- TMDb Helper (runtime)

**Engines:**
- `engine_3sk.py` - 3SK scraper with user selection
- `engine_qrmzi.py` - Qrmzi with forensic verification  
- `engine_turkish123.py` - Turkish123 with direct URLs

## 🤝 Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create feature branch
3. Test thoroughly on Android TV
4. Submit pull request

## 📜 License

MIT License - See LICENSE file for details

## 👏 Credits

- Original scraping logic: Community contributors
- TMDb Helper integration: Optimized architecture
- Forensic verification: Anti-wrong-match system
- Multi-threading: Android TV performance

## 📞 Support

Having issues? 

1. **Check logs first:** Enable debug in settings
2. **Search existing issues** on GitHub
3. **Create new issue** with:
   - Kodi version
   - Platform (Android TV / Windows / etc.)
   - Series name and episode
   - Full error log

## 🔄 Changelog

### v1.1.0 (2026-01-16)
- 🎯 **NEW:** 3SK shows ALL matches - user chooses!
- 🔍 **NEW:** Qrmzi forensic verification
- ⚡ **FASTER:** Multi-threaded resolution
- ✅ **RELIABLE:** No more wrong series matches

### v1.0.3 (2026-01-16)
- Fixed 3SK series name validation
- Added Turkish/English name fallback

### v1.0.0 (2026-01-16)
- Initial release as TMDb Helper player

---

**Made with ❤️ for Turkish series fans worldwide**
