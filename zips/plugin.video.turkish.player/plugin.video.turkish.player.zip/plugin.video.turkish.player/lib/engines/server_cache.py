# -*- coding: utf-8 -*-
"""
Server Index Cache
Remembers which server worked for each episode (24h cache)
NO stream URL caching - always fetch fresh streams
"""
import time
try:
    import xbmc
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGDEBUG = 0
        LOGINFO = 1
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"[{level}] {msg}")
class ServerIndexCache:
    """
    Smart server index caching
    
    YOUR PROVEN LOGIC from Turkish123/3SK addons:
    - Cache which server index worked (24h)
    - Test cached server FIRST on next playback
    - NO stream URL caching (always fetch fresh)
    
    Why no stream URL cache?
    - Tokens expire in 5-15 minutes
    - Always need fresh URLs
    - Server index rarely changes (cache it!)
    """
    
    def __init__(self):
        self.server_cache = {}  # {episode_url_hash: (server_index, timestamp)}
        self.stats = {
            'server_hits': 0,
            'server_misses': 0
        }
    
    def get_server_index(self, episode_url):
        """
        Get cached server index (which server worked last time)
        Cache lifetime: 24 hours
        
        Args:
            episode_url (str): Episode URL (used as cache key)
        
        Returns:
            int: Server index (0-based) or None if not cached/expired
        """
        cache_key = self._hash_key(episode_url)
        
        if cache_key not in self.server_cache:
            self.stats['server_misses'] += 1
            return None
        
        server_index, timestamp = self.server_cache[cache_key]
        
        # Check expiration (24 hours = 86400 seconds)
        if time.time() - timestamp > 86400:
            self._log(f"Server index cache expired: {episode_url[:50]}", xbmc.LOGDEBUG)
            del self.server_cache[cache_key]
            self.stats['server_misses'] += 1
            return None
        
        self._log(f"SERVER INDEX CACHE HIT: {episode_url[:50]} -> Server {server_index}", xbmc.LOGINFO)
        self.stats['server_hits'] += 1
        return server_index
    
    def set_server_index(self, episode_url, server_index):
        """
        Cache which server worked for this episode
        
        Args:
            episode_url (str): Episode URL
            server_index (int): Server index that worked (0-based)
        """
        cache_key = self._hash_key(episode_url)
        self.server_cache[cache_key] = (server_index, time.time())
        self._log(f"CACHED SERVER INDEX: {episode_url[:50]} -> Server {server_index}", xbmc.LOGINFO)
    
    def clear_expired(self):
        """Remove expired entries (24h+)"""
        now = time.time()
        expired = [k for k, (_, t) in self.server_cache.items() if now - t > 86400]
        
        for k in expired:
            del self.server_cache[k]
        
        if expired:
            self._log(f"Cleared {len(expired)} expired server indices", xbmc.LOGINFO)
    
    def get_stats(self):
        """
        Get cache statistics
        
        Returns:
            dict: Cache stats
        """
        total = self.stats['server_hits'] + self.stats['server_misses']
        hit_rate = (self.stats['server_hits'] / total * 100) if total > 0 else 0
        
        return {
            'server_hits': self.stats['server_hits'],
            'server_misses': self.stats['server_misses'],
            'hit_rate': hit_rate,
            'cache_size': len(self.server_cache)
        }
    
    def _hash_key(self, url):
        """Create cache key from URL"""
        # Simple hash - just use URL as key
        # Could use hashlib for shorter keys if needed
        return url
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message"""
        if KODI_ENV:
            xbmc.log(f"ServerCache: {message}", level)
        else:
            print(f"ServerCache: {message}")


