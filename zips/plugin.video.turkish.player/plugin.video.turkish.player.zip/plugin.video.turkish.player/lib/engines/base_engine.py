# -*- coding: utf-8 -*-
"""
Base Engine Abstract Class
Defines interface for all streaming engines
"""
from abc import ABC, abstractmethod
class BaseEngine(ABC):
    """
    Abstract base class for streaming engines
    
    All engines (3SK, Turkish123, etc.) must implement these methods
    """
    
    @abstractmethod
    def search_series(self, series_names):
        """
        Search for series using multiple name variants
        
        Args:
            series_names (list): List of series names to try
                Example: ['KÃ„Â±zÃ„Â±lcÃ„Â±k Ã…Å¾erbeti', 'Cranberry Sorbet', 'Ã™â€¦Ã˜Â±Ã˜Â¨Ã™â€° Ã˜Â§Ã™â€žÃ™Æ’Ã˜Â´Ã™â€¦Ã˜Â´']
        
        Returns:
            list: Search results with episode information
                [
                    {
                        'title': 'Series Name S01E05',
                        'episode_url': 'https://...',
                        'season': 1,
                        'episode': 5,
                        'poster': 'https://...'
                    },
                    ...
                ]
        """
        pass
    
    @abstractmethod
    def get_episode_url(self, search_results, season, episode):
        """
        Find specific episode URL from search results
        
        Args:
            search_results (list): Results from search_series()
            season (int): Target season number
            episode (int): Target episode number
        
        Returns:
            str: Episode URL or None if not found
        """
        pass
    
    @abstractmethod
    def get_stream_url(self, episode_url, force_refresh=False):
        """
        Extract stream URL from episode page
        
        Args:
            episode_url (str): URL of episode page
            force_refresh (bool): Force refresh cache
        
        Returns:
            list: List of stream options
                [
                    {
                        'name': 'Server 1',
                        'url': 'https://stream.m3u8',
                        'quality': 'HD'
                    },
                    ...
                ]
        """
        pass
    
    @abstractmethod
    def get_engine_name(self):
        """
        Get engine name for logging/display
        
        Returns:
            str: Engine name (e.g., '3SK', 'Turkish123')
        """
        pass
    
    @abstractmethod
    def get_audio_language(self):
        """
        Get audio language provided by this engine
        
        Returns:
            str: Language code ('ar', 'en', 'tr', etc.)
        """
        pass


