# -*- coding: utf-8 -*-
"""
Qrmzi Streaming Engine (Arabic Audio)
ULTIMATE VERSION - Using ALL proven scraping methods from 3SK + Turkish123
"""

import re
import unicodedata
import requests
from bs4 import BeautifulSoup
from urllib.parse import quote, urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import xbmc
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGDEBUG = 0
        LOGINFO = 1
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"[Qrmzi] {msg}")

# Android TV optimizations
MAX_WORKERS = 5  # Concurrent requests
TIMEOUT = 5      # Fail-fast


class EngineQrmzi:
    """
    Qrmzi engine with ULTIMATE scraping power
    
    Features ALL proven methods from:
      - 3SK: OK.RU handling, nested iframes, JavaScript unpacking
      - Turkish123: Tukipasti/Dwish, multiple patterns, depth resolution
      - Enhanced: Shadwo.pro specific handling
    """
    
    def __init__(self):
        """Initialize Qrmzi engine"""
        self.name = "Qrmzi"
        self.base_url = "https://www.qrmzi.tv"
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': self.base_url + '/'
        })
        
        self._log("Qrmzi Engine initialized (ULTIMATE version)", xbmc.LOGINFO)
    
    def resolve_episode(self, arabic_name, episode, season, tmdb_original_name):
        """
        Resolve episode with forensic verification
        
        Args:
            arabic_name: Arabic series name
            episode: Episode number
            season: Season number
            tmdb_original_name: Original Latin name from TMDB (for verification)
        
        Returns:
            dict: {'url': '...', 'quality': '...'} or None
        """
        
        self._log(f"=== QRMZI RESOLVER (Forensic Verification + ULTIMATE Scraping) ===", xbmc.LOGINFO)
        self._log(f"Arabic name: {arabic_name[:30]}...", xbmc.LOGINFO)
        self._log(f"Episode: S{season:02d}E{episode:02d}", xbmc.LOGINFO)
        self._log(f"Verification Key: '{tmdb_original_name}'", xbmc.LOGINFO)
        
        # Generate candidate URLs
        potential_urls = self._generate_episode_urls(arabic_name, episode)
        
        self._log(f"Testing {len(potential_urls)} generated URLs...", xbmc.LOGINFO)
        
        # Normalize original name for verification
        normalized_original = self._normalize_latin(tmdb_original_name)
        
        # Test URLs in parallel with verification
        verified_stream = self._verify_urls_parallel(potential_urls, normalized_original)
        
        if not verified_stream:
            self._log("No verified stream found", xbmc.LOGWARNING)
            return None
        
        self._log(f"✓ Verified stream found!", xbmc.LOGINFO)
        
        return {
            'url': verified_stream,
            'quality': 'HD'
        }
    
    def _generate_episode_urls(self, arabic_name, episode):
        """Generate candidate URLs"""
        urls = []
        clean_name = arabic_name.strip().replace(' ', '-')
        
        # Try both patterns
        urls.append(f"{self.base_url}/episode/مسلسل-{clean_name}-الحلقة-{episode}/")
        urls.append(f"{self.base_url}/episode/{clean_name}-الحلقة-{episode}/")
        
        return urls
    
    def _verify_urls_parallel(self, urls, normalized_original):
        """Test URLs in parallel with forensic verification"""
        
        def verify_and_extract(url):
            """Test single URL with verification"""
            try:
                self._log(f"Testing: {url[:60]}...", xbmc.LOGDEBUG)
                
                response = self.session.get(url, timeout=TIMEOUT, allow_redirects=True)
                
                if response.status_code != 200:
                    return None
                
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # === FORENSIC VERIFICATION ===
                is_confirmed = False
                
                # Check 1: Image Filename
                img = soup.select_one('.singleSeries .cover img')
                if img:
                    img_src = img.get('data-src') or img.get('src') or ''
                    if normalized_original in img_src.lower():
                        self._log(f"✓ VERIFIED via Image: {img_src[:50]}...", xbmc.LOGINFO)
                        is_confirmed = True
                
                # Check 2: Iframe URL
                if not is_confirmed:
                    embed = soup.select_one('.getEmbed iframe')
                    if embed:
                        iframe_src = embed.get('src', '').lower()
                        if normalized_original in iframe_src:
                            self._log(f"✓ VERIFIED via Stream URL: {iframe_src[:50]}...", xbmc.LOGINFO)
                            is_confirmed = True
                
                # If verified, extract stream
                if is_confirmed:
                    stream_url = self._extract_stream(soup, url)
                    return stream_url
                else:
                    self._log(f"✗ Not verified (wrong series)", xbmc.LOGDEBUG)
                    return None
                
            except requests.Timeout:
                self._log(f"Timeout: {url[:40]}", xbmc.LOGDEBUG)
                return None
            except Exception as e:
                self._log(f"Error testing {url[:40]}: {e}", xbmc.LOGDEBUG)
                return None
        
        # Test URLs in parallel
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = {executor.submit(verify_and_extract, url): url for url in urls}
            
            for future in as_completed(futures):
                result = future.result()
                if result:
                    # Found verified stream, cancel remaining
                    for f in futures:
                        f.cancel()
                    return result
        
        return None
    
    def _extract_stream(self, soup, page_url):
        """Extract stream URL from verified page"""
        
        try:
            # Find iframe embed
            embed = soup.select_one('.getEmbed iframe')
            
            if not embed:
                self._log("No iframe found", xbmc.LOGERROR)
                return None
            
            iframe_src = embed.get('src', '')
            
            if not iframe_src:
                self._log("Empty iframe src", xbmc.LOGERROR)
                return None
            
            # Make absolute URL
            if not iframe_src.startswith('http'):
                iframe_src = urljoin(self.base_url, iframe_src)
            
            self._log(f"Resolving iframe: {iframe_src[:60]}...", xbmc.LOGINFO)
            
            # ULTIMATE RESOLUTION with max depth
            stream_url = self._resolve_iframe(iframe_src, max_depth=3)
            
            # Validate we got an actual stream URL
            if stream_url:
                if '.m3u8' in stream_url or '.mp4' in stream_url:
                    return stream_url
                else:
                    self._log(f"Resolved URL is not a stream: {stream_url[:80]}", xbmc.LOGERROR)
                    return None
            
            return None
            
        except Exception as e:
            self._log(f"Stream extraction error: {e}", xbmc.LOGERROR)
            return None
    
    # =========================================================================
    # ULTIMATE IFRAME RESOLVER - ALL PROVEN METHODS
    # =========================================================================
    
    def _resolve_iframe(self, iframe_url, max_depth=3):
        """
        ULTIMATE iframe resolver using ALL proven methods from 3SK + Turkish123
        
        Handles:
          - OK.RU (3 methods)
          - Tukipasti/Dwish
          - Shadwo.pro
          - Nested iframes
          - JavaScript unpacking
          - Video tags
        """
        
        if max_depth <= 0:
            self._log("Max iframe depth reached", xbmc.LOGWARNING)
            return None
        
        try:
            self._log(f"Resolving iframe (depth {3-max_depth}): {iframe_url[:80]}...", xbmc.LOGDEBUG)
            
            response = self.session.get(
                iframe_url, 
                headers={
                    'Referer': self.base_url,
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                timeout=10,
                allow_redirects=True
            )
            
            if response.status_code != 200:
                self._log(f"Iframe returned status {response.status_code}", xbmc.LOGWARNING)
                return None
            
            html_content = response.text
            
            # ================================================================
            # METHOD 1: OK.RU HANDLING (from 3SK + Turkish123)
            # ================================================================
            if 'ok.ru' in iframe_url or 'ok.ru' in html_content:
                self._log("Detected OK.RU embed", xbmc.LOGINFO)
                
                # Method 1a: hlsManifestUrl
                hls_match = re.search(r'"hlsManifestUrl"\s*:\s*"([^"]+)"', html_content)
                if hls_match:
                    url = hls_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if url.startswith('http'):
                        self._log("Found OK.RU HLS manifest", xbmc.LOGINFO)
                        return url
                
                # Method 1b: Videos array
                videos_match = re.search(r'"videos"\s*:\s*\[([^\]]+)\]', html_content)
                if videos_match:
                    for quality in ['hd', 'sd', 'low']:
                        q_match = re.search(
                            rf'"name"\s*:\s*"{quality}"\s*,\s*"url"\s*:\s*"([^"]+)"',
                            videos_match.group(1)
                        )
                        if q_match:
                            url = q_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                            if url.startswith('http'):
                                self._log(f"Found OK.RU {quality} quality", xbmc.LOGINFO)
                                return url
                
                # Method 1c: Direct okcdn URL
                okcdn_match = re.search(r'"(https://[^"]+okcdn\.ru[^"]+\.m3u8[^"]*)"', html_content)
                if okcdn_match:
                    url = okcdn_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if '&quot;' not in url and url.startswith('http'):
                        self._log("Found OK.RU okcdn URL", xbmc.LOGINFO)
                        return url
            
            # ================================================================
            # METHOD 2: TUKIPASTI/DWISH HANDLING (from Turkish123)
            # ================================================================
            if 'tukipasti' in iframe_url.lower() or 'dwish' in iframe_url.lower():
                self._log("Detected Tukipasti/Dwish embed", xbmc.LOGINFO)
                m3u8_match = re.search(r'(https?://[^\s"\']*\.m3u8[^\s"\']*)', html_content)
                if m3u8_match:
                    url = m3u8_match.group(1)
                    self._log("Found Tukipasti/Dwish m3u8", xbmc.LOGINFO)
                    return url
            
            # ================================================================
            # METHOD 3: SHADWO SPECIFIC (enhanced)
            # ================================================================
            if 'shadwo' in iframe_url.lower():
                self._log("Detected shadwo.pro embed - using ULTIMATE extraction", xbmc.LOGINFO)
            
            # ================================================================
            # METHOD 4: GENERIC EXTRACTION (from 3SK + Turkish123)
            # ================================================================
            stream_url = self._extract_stream_from_html(html_content)
            if stream_url:
                return stream_url
            
            # ================================================================
            # METHOD 5: NESTED IFRAME (from both engines)
            # ================================================================
            nested = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html_content, re.IGNORECASE)
            if nested:
                next_url = nested.group(1)
                if not next_url.startswith('http'):
                    next_url = urljoin(iframe_url, next_url)
                
                if not next_url.startswith('about:') and not next_url.startswith('javascript:'):
                    self._log(f"Following nested iframe: {next_url[:60]}...", xbmc.LOGDEBUG)
                    return self._resolve_iframe(next_url, max_depth - 1)
            
            # ================================================================
            # METHOD 6: VIDEO TAG EXTRACTION
            # ================================================================
            video_match = re.search(r'<video[^>]*>.*?<source[^>]+src=["\']([^"\']+)["\']', html_content, re.IGNORECASE | re.DOTALL)
            if video_match:
                video_url = video_match.group(1)
                if '.m3u8' in video_url or '.mp4' in video_url:
                    self._log(f"Found video source tag: {video_url[:60]}...", xbmc.LOGINFO)
                    return video_url
            
            # No stream found
            self._log(f"No stream found. HTML snippet: {html_content[:300]}...", xbmc.LOGWARNING)
            return None
            
        except Exception as e:
            self._log(f"Error resolving iframe: {e}", xbmc.LOGERROR)
            import traceback
            self._log(traceback.format_exc(), xbmc.LOGDEBUG)
            return None
    
    def _extract_stream_from_html(self, html_content):
        """
        ULTIMATE stream extraction - ALL patterns from 3SK + Turkish123
        """
        
        # ================================================================
        # STEP 1: JAVASCRIPT UNPACKING (from 3SK + Turkish123)
        # ================================================================
        if 'eval(function(p,a,c,k,e,d)' in html_content:
            self._log("Detected packed JavaScript, unpacking...", xbmc.LOGDEBUG)
            try:
                unpacked = self._unpack_js(html_content)
                if unpacked:
                    html_content = unpacked
                    self._log("JavaScript unpacked successfully", xbmc.LOGDEBUG)
            except:
                self._log("JavaScript unpacking failed", xbmc.LOGDEBUG)
        
        # ================================================================
        # STEP 2: ALL PROVEN PATTERNS
        # ================================================================
        patterns = [
            # Direct URLs
            ('Direct m3u8', r'(https?://[^\s"\'<>]+\.m3u8(?:\?[^\s"\'<>]+)?)'),
            ('Direct mp4', r'(https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]+)?)'),
            
            # JWPlayer
            ('JWPlayer file (double)', r'"file"\s*:\s*"([^"]+)"'),
            ('JWPlayer file (single)', r"'file'\s*:\s*'([^']+)'"),
            ('sources array', r'"sources"\s*:\s*\[\s*"([^"]+)"'),
            
            # Attributes
            ('source attribute', r'source:\s*"([^"]+)"'),
            ('src attribute', r'src:\s*"([^"]+)"'),
            ('url attribute', r'"url"\s*:\s*"([^"]+)"'),
            
            # JavaScript vars
            ('video.src', r'video\.src\s*=\s*["\']([^"\']+)["\']'),
            ('videoSource', r'videoSource\s*=\s*["\']([^"\']+)["\']'),
            
            # HLS
            ('hlsManifestUrl', r'hlsManifestUrl["\']?\s*:\s*["\']([^"\']+)["\']'),
            
            # Embeds
            ('Tukipasti', r'https://tukipasti\.[^\s\'"]+'),
            ('Dwish', r'https://dwish\.[^\s\'"]+'),
        ]
        
        for name, pattern in patterns:
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                url = match.group(1) if match.lastindex else match.group(0)
                
                # Clean up
                url = url.replace('\\/', '/')
                url = url.replace('\\u0026', '&')
                url = url.replace('&amp;', '&')
                url = url.replace('\\"', '"')
                
                # Validate
                if url.startswith('http') and any(ext in url.lower() for ext in ['.m3u8', '.mp4', '.mkv', 'tukipasti', 'dwish']):
                    self._log(f"Extracted via {name}: {url[:100]}...", xbmc.LOGINFO)
                    return url
        
        return None
    
    def _unpack_js(self, packed):
        """Basic JavaScript unpacker (simplified version)"""
        try:
            match = re.search(r"}\('(.*)',(\d+),(\d+),'([^']*)'\.split\('\|'\)", packed)
            if not match:
                return None
            
            payload, radix, count, symtab = match.groups()
            radix = int(radix)
            symbols = symtab.split('|')
            
            def lookup(m):
                value = int(m.group(0), radix)
                return symbols[value] if value < len(symbols) and symbols[value] else m.group(0)
            
            return re.sub(r'\b\w+\b', lookup, payload)
        except:
            return None
    
    def _normalize_latin(self, text):
        """Normalize Latin name for matching"""
        if not text:
            return ""
        
        # Remove diacritics
        text = ''.join(
            c for c in unicodedata.normalize('NFD', text) 
            if unicodedata.category(c) != 'Mn'
        )
        
        # Lowercase
        text = text.lower()
        
        # Clean up
        text = text.replace(' ', '-')
        text = text.replace(':', '')
        text = re.sub(r'[^a-z0-9\-]', '', text)
        text = re.sub(r'-+', '-', text).strip('-')
        
        return text
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message"""
        if KODI_ENV:
            xbmc.log(f"EngineQrmzi: {message}", level)
        else:
            print(f"[Qrmzi] {message}")
