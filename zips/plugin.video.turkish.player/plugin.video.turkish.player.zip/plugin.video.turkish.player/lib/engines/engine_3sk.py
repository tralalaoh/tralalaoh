# -*- coding: utf-8 -*-
"""
3SK Streaming Engine (Arabic Audio)
Extracted from working 3SK addon - STREAM LOGIC UNCHANGED
YOUR PROVEN LOGIC:
- Smart server index caching (24h)
- NO stream URL caching (always fresh)
- JavaScript unpacking
- OK.RU handling
- Nested iframe resolution
"""
import re
import urllib.parse
try:
    import requests
except ImportError as e:
    raise ImportError("requests module required: pip install requests")
try:
    from bs4 import BeautifulSoup
except ImportError as e:
    raise ImportError("BeautifulSoup4 module required: pip install beautifulsoup4")
try:
    import xbmc
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGDEBUG = 0
        LOGINFO = 1
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"Engine3SK: {msg}")
# Handle imports for both Kodi and standalone
try:
    from .base_engine import BaseEngine
    from .server_cache import ServerIndexCache
    from .utils import unpack_js, parse_episode_info, deduplicate_results
except ImportError:
    # Standalone execution
    from base_engine import BaseEngine
    from server_cache import ServerIndexCache
    from utils import unpack_js, parse_episode_info, deduplicate_results
# ==============================================================================
# CONFIGURATION (from YOUR 3SK addon)
# ==============================================================================
MAX_SERVERS_TO_TEST = 3  # Android TV optimization
SITE_CONFIG = {
    "DOMAINS": [
        "https://esheaq.onl",
        "https://x.esheaq.onl",
        "https://3sk.media",
        "https://u.3sk.media"
    ],
    "SELECTORS": {
        "series_container": "article.postEp",
        "series_title": "div.title",
        "series_url": "a",
        "series_img_selector": ".imgBg img",
        "series_img_attr": "data-image",
        
        "episode_list_container": "#epiList",
        "episode_item": "article.postEp",
        "episode_num": "div.episodeNum span:nth-of-type(2)",
        "episode_link": "a",
        
        "server_list": "ul.serversList li",
        "server_attr": "data-src"
    }
}
# ==============================================================================
# ENGINE3SK CLASS
# ==============================================================================
class Engine3SK(BaseEngine):
    """
    3SK streaming engine for Arabic audio content
    
    YOUR PROVEN CODE - Stream extraction logic unchanged
    """
    
    def __init__(self):
        """Initialize engine"""
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://google.com/'
        })
        
        # Find active domain
        self.base_url = self._find_active_domain()
        
        # Initialize server index cache (NO stream URL cache!)
        self.cache = ServerIndexCache()
        
        self._log("3SK Engine initialized: {}".format(self.base_url), xbmc.LOGINFO)
    
    def get_engine_name(self):
        """Get engine name"""
        return '3SK'
    
    def get_audio_language(self):
        """Get audio language"""
        return 'ar'  # Arabic
    
    # ==========================================================================
    # NEW METHODS FOR TMDB INTEGRATION
    # ==========================================================================
    
    def search_series(self, series_names):
        """
        Search for series using multiple name variants
        
        Args:
            series_names (list): List of series names to try
        
        Returns:
            list: Search results with episode info parsed
        """
        all_results = []
        
        for name in series_names:
            if not name:
                continue
            
            self._log(f"Searching 3SK for: {name}", xbmc.LOGINFO)
            results = self._search(name)
            
            if results:
                # Parse episode info for each result
                for result in results:
                    season, episode = parse_episode_info(result['title'])
                    result['season'] = season
                    result['episode'] = episode
                
                all_results.extend(results)
                self._log(f"Found {len(results)} results for '{name}'", xbmc.LOGINFO)
        
        # Deduplicate
        all_results = deduplicate_results(all_results)
        
        self._log(f"Total unique results: {len(all_results)}", xbmc.LOGINFO)
        return all_results
    
    def build_virtual_series_folder(self, search_results):
        """
        Build complete virtual series folder from landing page
        
        PHASE 2C: Cache ALL episodes for fast access
        - Search once, get ALL episodes
        - Cache to SQLite
        - Only scrape streams on-demand when user clicks play
        
        Args:
            search_results (list): Results from search_series()
        
        Returns:
            list: All episodes [{'title': str, 'url': str, 'episode_number': int, 'season': int}, ...]
            or empty list if failed
        """
        self._log("=== BUILDING VIRTUAL SERIES FOLDER ===", xbmc.LOGINFO)
        
        if not search_results:
            self._log("No search results to build folder from", xbmc.LOGWARNING)
            return []
        
        # Pick ANY episode from search results
        first_episode_url = search_results[0]['episode_url']
        self._log(f"Using episode: {first_episode_url[:60]}...", xbmc.LOGINFO)
        
        # Get landing page (redirects to series page or episode landing page)
        landing_page_url = self._get_landing_page(first_episode_url)
        
        if not landing_page_url:
            self._log("Failed to get landing page", xbmc.LOGERROR)
            return []
        
        self._log(f"Landing page: {landing_page_url[:60]}...", xbmc.LOGINFO)
        
        # Get ALL episodes from landing page
        all_episodes = self._get_episodes_from_landing_page(landing_page_url)
        
        if not all_episodes:
            self._log("No episodes found on landing page", xbmc.LOGWARNING)
            return []
        
        self._log(f"Ã¢Å“â€œ Found {len(all_episodes)} episodes in virtual folder", xbmc.LOGINFO)
        
        # Convert to cache format
        virtual_folder = []
        for ep in all_episodes:
            virtual_folder.append({
                'title': ep.get('title', ''),
                'url': ep.get('url', ''),
                'episode_number': ep.get('number', 0),
                'season': ep.get('season', 1)
            })
        
        # Sort by episode number
        virtual_folder.sort(key=lambda x: x['episode_number'])
        
        # Show sample
        self._log("Sample episodes:", xbmc.LOGINFO)
        for ep in virtual_folder[:5]:
            self._log(f"  E{ep['episode_number']:03d}: {ep['title']}", xbmc.LOGINFO)
        if len(virtual_folder) > 5:
            self._log(f"  ... and {len(virtual_folder) - 5} more", xbmc.LOGINFO)
        
        return virtual_folder
    
    def get_episode_url(self, search_results, season, episode):
        """
        Find specific episode URL from search results
        
        YOUR 3SK STRATEGY:
        1. Get search results (may only show latest episodes)
        2. Pick ANY episode from results
        3. Visit that episode's landing page
        4. Landing page shows ALL episodes
        5. Find target episode from landing page
        
        Args:
            search_results (list): Results from search_series()
            season (int): Target season number
            episode (int): Target episode number
        
        Returns:
            str: Episode URL or None
        """
        self._log(f"Looking for S{season:02d}E{episode:02d}", xbmc.LOGINFO)
        
        if not search_results:
            self._log("No search results to process", xbmc.LOGWARNING)
            return None
        
        # Debug: Show what search returned
        self._log(f"Search returned {len(search_results)} results", xbmc.LOGINFO)
        for i, r in enumerate(search_results[:5], 1):  # Show first 5
            self._log(f"  {i}. {r['title']} -> S{r.get('season', '?')}E{r.get('episode', '?')}", xbmc.LOGINFO)
        
        # STRATEGY 1: Try direct match in search results
        direct_matches = [
            r for r in search_results 
            if r.get('season') == season and r.get('episode') == episode
        ]
        
        if direct_matches:
            self._log(f"Ã¢Å“â€œ Direct match in search results!", xbmc.LOGINFO)
            return direct_matches[0]['episode_url']
        
        # STRATEGY 2: Use landing page (YOUR 3SK METHOD)
        self._log(f"Not in search results, trying landing page method...", xbmc.LOGINFO)
        
        # Pick first episode from search results
        first_episode_url = search_results[0]['episode_url']
        self._log(f"Getting landing page from: {first_episode_url[:60]}...", xbmc.LOGINFO)
        
        # Get landing page (has ALL episodes)
        landing_page_url = self._get_landing_page(first_episode_url)
        
        if not landing_page_url:
            self._log("Failed to get landing page", xbmc.LOGERROR)
            return None
        
        self._log(f"Got landing page: {landing_page_url[:60]}...", xbmc.LOGINFO)
        
        # Get ALL episodes from landing page
        all_episodes = self._get_episodes_from_landing_page(landing_page_url)
        
        self._log(f"Landing page has {len(all_episodes)} episodes", xbmc.LOGINFO)
        
        if all_episodes:
            # Show first 5 episodes
            for i, ep in enumerate(all_episodes[:5], 1):
                self._log(f"  {i}. {ep['title']} -> S{ep.get('season', '?')}E{ep.get('number', '?')}", xbmc.LOGINFO)
        
        # Find target episode in landing page results
        for ep in all_episodes:
            if ep.get('season') == season and ep.get('number') == episode:
                self._log(f"Ã¢Å“â€œ Found S{season:02d}E{episode:02d} on landing page!", xbmc.LOGINFO)
                return ep['url']
        
        # Not found
        self._log(f"S{season:02d}E{episode:02d} not found even on landing page", xbmc.LOGWARNING)
        
        # Show what episodes ARE available
        unique_episodes = set((ep.get('season'), ep.get('number')) for ep in all_episodes if ep.get('season') and ep.get('number'))
        if unique_episodes:
            self._log(f"Available episodes: {sorted(list(unique_episodes))[:10]}", xbmc.LOGINFO)
        
        return None
    
    # ==========================================================================
    # YOUR PROVEN STREAM EXTRACTION LOGIC (UNCHANGED)
    # ==========================================================================
    
    def get_stream_url(self, episode_url, force_refresh=False):
        """
        YOUR PROVEN get_stream_url() METHOD
        
        SMART SERVER INDEX CACHE (NO stream URL cache):
        1. Check SERVER INDEX cache (24h)
        2. Test cached server FIRST
        3. Fallback to testing other servers (max 3)
        4. Cache server index that works
        
        Args:
            episode_url (str): Episode page URL
            force_refresh (bool): Force ignore cache
        
        Returns:
            list: Stream options [{'name': '...', 'url': '...', 'quality': '...'}]
        """
        cache_key = episode_url
        
        # Get all available servers
        response = self._request(episode_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        see_link = soup.find('a', href=re.compile(r'/see/$'))
        if see_link:
            video_page_url = self._fix_url(see_link['href'])
        else:
            video_page_url = episode_url.rstrip('/') + '/see/'
        
        response = self._request(video_page_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        servers = soup.select(SITE_CONFIG["SELECTORS"]["server_list"])
        self._log(f"Found {len(servers)} server options", xbmc.LOGINFO)
        
        # Check SERVER INDEX cache (which server worked before)
        cached_server_index = self.cache.get_server_index(cache_key) if not force_refresh else None
        
        verified_servers = []
        
        # SMART: Test cached server FIRST!
        if cached_server_index is not None and cached_server_index < len(servers):
            self._log(f"Testing CACHED server {cached_server_index + 1} first", xbmc.LOGINFO)
            
            server = servers[cached_server_index]
            embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
            
            if embed_url:
                embed_url = self._fix_url(embed_url)
                stream_url = self._resolve_server(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    self._log(f"SUCCESS! Cached server {cached_server_index + 1} still works!", xbmc.LOGINFO)
                    
                    quality = self._guess_quality(stream_url)
                    verified_servers.append({
                        'name': f"Server {cached_server_index + 1} (Cached)",
                        'url': stream_url,
                        'quality': quality
                    })
                    
                    # Update cache
                    self.cache.set_server_index(cache_key, cached_server_index)
                    
                    return verified_servers
                else:
                    self._log(f"Cached server {cached_server_index + 1} now dead", xbmc.LOGWARNING)
        
        # Test first N servers
        self._log(f"Testing first {MAX_SERVERS_TO_TEST} servers...", xbmc.LOGINFO)
        servers_to_test = servers[:MAX_SERVERS_TO_TEST]
        
        for idx, server in enumerate(servers_to_test):
            # Skip if we already tested cached server
            if idx == cached_server_index:
                continue
            
            embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
            if not embed_url:
                continue
            
            embed_url = self._fix_url(embed_url)
            server_name = f"Server {idx + 1}"
            
            stream_url = self._resolve_server(embed_url)
            
            if stream_url and self._test_stream_url(stream_url):
                quality = self._guess_quality(stream_url)
                verified_servers.append({
                    'name': server_name,
                    'url': stream_url,
                    'quality': quality
                })
                self._log(f"SUCCESS: {server_name} verified!", xbmc.LOGINFO)
                
                # Cache server index
                self.cache.set_server_index(cache_key, idx)
                
                break  # Stop after finding 1 (Android TV optimization)
        
        # Fallback to remaining servers if needed
        if not verified_servers and len(servers) > MAX_SERVERS_TO_TEST:
            self._log("Trying remaining servers...", xbmc.LOGINFO)
            
            for idx, server in enumerate(servers[MAX_SERVERS_TO_TEST:], start=MAX_SERVERS_TO_TEST):
                if idx == cached_server_index:
                    continue
                
                embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
                if not embed_url:
                    continue
                
                embed_url = self._fix_url(embed_url)
                stream_url = self._resolve_server(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    verified_servers.append({
                        'name': f"Server {idx + 1}",
                        'url': stream_url,
                        'quality': self._guess_quality(stream_url)
                    })
                    
                    self.cache.set_server_index(cache_key, idx)
                    break
        
        # Log cache stats
        stats = self.cache.get_stats()
        self._log(f"Cache stats: {stats['server_hits']} hits, {stats['hit_rate']:.1f}% hit rate", xbmc.LOGINFO)
        
        return verified_servers
    
    def _resolve_server(self, embed_url):
        """
        YOUR PROVEN _resolve_server() METHOD (UNCHANGED)
        Resolve server to stream URL
        """
        is_internal = any(d in embed_url for d in SITE_CONFIG["DOMAINS"]) or "emb=true" in embed_url
        
        if is_internal:
            try:
                r2 = self._request(embed_url)
                if not r2:
                    return None
                
                stream_url = self._extract_stream_from_html(r2.text)
                if stream_url:
                    return stream_url
                
                nested_iframe = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', r2.text)
                if nested_iframe:
                    iframe_url = nested_iframe.group(1)
                    if not iframe_url.startswith('http'):
                        iframe_url = urllib.parse.urljoin(embed_url, iframe_url)
                    
                    if not iframe_url.startswith('about:') and not iframe_url.startswith('javascript:'):
                        return self._resolve_iframe(iframe_url)
            except:
                return None
        else:
            return self._resolve_iframe(embed_url)
        
        return None
    
    def _resolve_iframe(self, iframe_url, max_depth=3):
        """
        YOUR PROVEN _resolve_iframe() METHOD (UNCHANGED)
        Resolve iframe to find stream
        """
        if max_depth <= 0:
            return None
        
        self._log(f"Resolving iframe: {iframe_url[:80]}", xbmc.LOGDEBUG)
        
        try:
            response = self._request(iframe_url)
            if not response:
                return None
            
            html_content = response.text
            
            # OK.RU specific handling
            if 'ok.ru' in iframe_url or 'ok.ru' in html_content:
                # Method 1: hlsManifestUrl
                hls_match = re.search(r'"hlsManifestUrl"\s*:\s*"([^"]+)"', html_content)
                if hls_match:
                    url = hls_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if url.startswith('http'):
                        return url
                
                # Method 2: Videos array
                videos_match = re.search(r'"videos"\s*:\s*\[([^\]]+)\]', html_content)
                if videos_match:
                    for quality in ['hd', 'sd', 'low']:
                        q_match = re.search(
                            rf'"name"\s*:\s*"{quality}"\s*,\s*"url"\s*:\s*"([^"]+)"',
                            videos_match.group(1)
                        )
                        if q_match:
                            url = q_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                            if url.startswith('http'):
                                return url
                
                # Method 3: Direct okcdn URL
                okcdn_match = re.search(r'"(https://[^"]+okcdn\.ru[^"]+\.m3u8[^"]*)"', html_content)
                if okcdn_match:
                    url = okcdn_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if '&quot;' not in url and url.startswith('http'):
                        return url
            
            # Generic extraction
            stream_url = self._extract_stream_from_html(html_content)
            if stream_url:
                return stream_url
            
            # Nested iframe
            nested = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html_content)
            if nested:
                next_url = nested.group(1)
                if not next_url.startswith('http'):
                    next_url = urllib.parse.urljoin(iframe_url, next_url)
                
                if not next_url.startswith('about:') and not next_url.startswith('javascript:'):
                    return self._resolve_iframe(next_url, max_depth - 1)
            
            return None
        
        except Exception as e:
            self._log(f"Error resolving iframe: {e}", xbmc.LOGERROR)
            return None
    
    def _extract_stream_from_html(self, html_content):
        """
        YOUR PROVEN _extract_stream_from_html() METHOD (UNCHANGED)
        Extract stream URL using multiple patterns
        """
        # Unpack JavaScript if needed
        if 'eval(function(p,a,c,k,e,d)' in html_content:
            unpacked = unpack_js(html_content)
            if unpacked:
                html_content = unpacked
        
        patterns = [
            ('JWPlayer file (double quotes)', r'"file"\s*:\s*"([^"]+)"'),
            ('JWPlayer file (single quotes)', r"'file'\s*:\s*'([^']+)'"),
            ('sources array', r'"sources"\s*:\s*\[\s*"([^"]+)"'),
            ('Direct m3u8', r'(https?://[^\s"\'<>]+\.m3u8(?:\?[^\s"\'<>]+)?)'),
            ('Direct mp4', r'(https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]+)?)')
        ]
        
        for name, pattern in patterns:
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                url = match.group(1)
                url = url.replace('\\/', '/').replace('\\u0026', '&').replace('&amp;', '&')
                
                if url.startswith('http') and any(ext in url.lower() for ext in ['.m3u8', '.mp4', '.mkv']):
                    self._log(f"Extracted via {name}: {url[:100]}", xbmc.LOGINFO)
                    return url
        
        return None
    
    def _test_stream_url(self, url):
        """
        YOUR PROVEN _test_stream_url() METHOD (UNCHANGED)
        Quick test if URL is accessible
        """
        try:
            head_response = self.session.head(url, timeout=3, allow_redirects=True)
            
            if head_response.status_code == 200:
                return True
            elif head_response.status_code in [301, 302, 303, 307, 308]:
                return True
            elif head_response.status_code == 403:
                # Try GET with range header
                get_response = self.session.get(url, headers={'Range': 'bytes=0-512'}, timeout=3)
                return get_response.status_code in [200, 206]
            
            return False
        except:
            return False
    
    def _guess_quality(self, url):
        """Guess quality from URL"""
        url_lower = url.lower()
        if 'hd' in url_lower or '1080' in url_lower:
            return 'HD'
        elif 'sd' in url_lower or '720' in url_lower:
            return 'SD'
        return 'Auto'
    
    # ==========================================================================
    # INTERNAL HELPER METHODS
    # ==========================================================================
    
    def _find_active_domain(self):
        """Find active domain from list"""
        self._log("Checking 3SK domains...", xbmc.LOGINFO)
        for domain in SITE_CONFIG["DOMAINS"]:
            try:
                r = self.session.head(domain, timeout=5, allow_redirects=True)
                if r.status_code < 400:
                    self._log(f"Active domain: {domain}", xbmc.LOGINFO)
                    return domain
            except:
                continue
        
        # Fallback to first domain
        return SITE_CONFIG["DOMAINS"][0]
    
    def _request(self, url):
        """Make HTTP request"""
        try:
            self._log(f"Request: {url[:80]}", xbmc.LOGDEBUG)
            return self.session.get(url, timeout=30, allow_redirects=True)
        except Exception as e:
            self._log(f"Request failed: {e}", xbmc.LOGERROR)
            return None
    
    def _fix_url(self, url):
        """Fix relative URLs"""
        if url.startswith("http"):
            return url
        return urllib.parse.urljoin(self.base_url, url)
    
    def _search(self, query):
        """
        Search 3SK site (YOUR PROVEN LOGIC)
        
        Args:
            query (str): Search query
        
        Returns:
            list: Search results
        """
        search_url = f"{self.base_url}/?s={urllib.parse.quote(query)}"
        self._log(f"Searching: {search_url}", xbmc.LOGINFO)
        
        response = self._request(search_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        articles = soup.select('article.post')
        self._log(f"Found {len(articles)} search results", xbmc.LOGINFO)
        
        results = []
        for article in articles:
            try:
                link = article.find('a')
                if not link:
                    continue
                
                episode_url = link.get('href', '')
                if not episode_url:
                    continue
                
                # Fix relative URLs
                if not episode_url.startswith('http'):
                    episode_url = self._fix_url(episode_url)
                
                # Get title
                title_div = article.select_one('.title')
                title = title_div.text.strip() if title_div else "Unknown"
                
                # Get episode number
                ep_num_div = article.select_one('.episodeNum')
                ep_num_text = ep_num_div.text.strip() if ep_num_div else ""
                ep_match = re.search(r'(\d+)', ep_num_text)
                ep_num = int(ep_match.group(1)) if ep_match else 0
                
                # Get image
                img = article.select_one('img')
                poster = ""
                if img:
                    poster = img.get('data-image') or img.get('src') or ""
                
                results.append({
                    'title': title,
                    'episode_url': episode_url,
                    'episode_number': ep_num,
                    'poster': poster
                })
            except Exception as e:
                self._log(f"Error parsing search result: {e}", xbmc.LOGERROR)
                continue
        
        return results
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message"""
        if KODI_ENV:
            xbmc.log(f"Engine3SK: {message}", level)
        else:
            print(f"Engine3SK: {message}")
    
    def _get_landing_page(self, episode_url):
        """
        Get landing page URL from an episode
        
        YOUR 3SK STRATEGY:
        - Episode URL leads to a landing page
        - Landing page shows all episodes of the series
        
        Returns:
            str: Landing page URL (may be same as episode_url)
        """
        self._log(f"Getting landing page for: {episode_url[:60]}...", xbmc.LOGDEBUG)
        
        response = self._request(episode_url)
        if not response:
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Check if this page HAS episodes (it's already the landing page)
        epi_list = soup.select_one('#epiList')
        if epi_list and len(epi_list.select('article')) > 0:
            self._log("This IS a landing page with #epiList", xbmc.LOGDEBUG)
            return episode_url
        
        # Check for related episodes
        articles = soup.select('article.post') or soup.select('article.postEp')
        if len(articles) > 5:  # If has many episodes, it's the landing page
            self._log(f"This IS a landing page ({len(articles)} episodes)", xbmc.LOGDEBUG)
            return episode_url
        
        # Otherwise, return the episode URL (it might be the landing page)
        self._log("Using episode URL as landing page", xbmc.LOGDEBUG)
        return episode_url
    
    def _get_episodes_from_landing_page(self, landing_url):
        """
        Extract ALL episodes from landing page
        
        YOUR 3SK METHOD from get_episodes()
        
        Returns:
            list: All episodes found on landing page
        """
        self._log(f"Extracting episodes from landing page...", xbmc.LOGINFO)
        
        response = self._request(landing_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        episodes = []
        
        # Try #epiList first (series page)
        epi_list = soup.select_one('#epiList')
        if epi_list:
            items = epi_list.select('article.postEp')
            self._log(f"Found {len(items)} in #epiList", xbmc.LOGDEBUG)
        else:
            # Landing page - try different selectors
            items = soup.select('article.postEp')
            if not items:
                items = soup.select('article.post')
            if not items:
                items = soup.select('article')
            self._log(f"Found {len(items)} on landing page", xbmc.LOGDEBUG)
        
        # Parse each article
        for idx, item in enumerate(items):
            try:
                # Get link
                a_tag = item.select_one('a') or item.find('a')
                if not a_tag:
                    continue
                
                ep_url = self._fix_url(a_tag['href'])
                
                # Get title
                title_div = item.select_one('.title')
                title = title_div.text.strip() if title_div else ""
                
                # Extract episode number
                num_tag = item.select_one('.episodeNum')
                if num_tag:
                    num_text = num_tag.text.strip()
                    ep_match = re.search(r'(\d+)', num_text)
                    ep_num = int(ep_match.group(1)) if ep_match else (len(items) - idx)
                else:
                    # Try from title
                    ep_match = re.search(r'(?:Ã˜Â§Ã™â€žÃ˜Â­Ã™â€žÃ™â€šÃ˜Â©|Episode|Ã˜Â­Ã™â€žÃ™â€šÃ˜Â©|Ep)\s*(\d+)', title, re.IGNORECASE)
                    if not ep_match:
                        ep_match = re.search(r'(\d+)', title)
                    ep_num = int(ep_match.group(1)) if ep_match else (len(items) - idx)
                
                # Extract season
                season_match = re.search(r'(?:Ã™â€¦Ã™Ë†Ã˜Â³Ã™â€¦|Season|Ã˜Â§Ã™â€žÃ™â€¦Ã™Ë†Ã˜Â³Ã™â€¦)\s*(\d+)', title, re.IGNORECASE)
                season = int(season_match.group(1)) if season_match else 1
                
                if not title:
                    title = f"Episode {ep_num}"
                
                episodes.append({
                    'number': ep_num,
                    'url': ep_url,
                    'title': title,
                    'season': season
                })
                
            except Exception as e:
                self._log(f"Error parsing episode {idx}: {e}", xbmc.LOGERROR)
                continue
        
        # Sort by season and episode (newest first, like YOUR addon)
        episodes.sort(key=lambda x: (x.get('season', 1), -x['number']))
        
        self._log(f"Extracted {len(episodes)} total episodes", xbmc.LOGINFO)
        
        return episodes

    def get_stream_url_from_video_page(self, video_page_url):
        """
        Extract stream from /see/ page
        NEW METHOD for player addon integration
        
        Args:
            video_page_url: Must be the /see/ page URL
                           Example: https://x.esheeg.onl/watch/v5xim3y7ux/see/
        
        Returns:
            List of stream options
        """
        
        # Ensure URL ends with /see/
        if not video_page_url.endswith('/see/'):
            self._log("URL doesn't end with /see/, appending it", xbmc.LOGWARNING)
            video_page_url = video_page_url.rstrip('/') + '/see/'
        
        self._log(f"Scraping /see/ page: {video_page_url[:60]}...", xbmc.LOGINFO)
        
        # Get /see/ page
        response = self._request(video_page_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Parse server list
        servers = soup.select(SITE_CONFIG["SELECTORS"]["server_list"])
        self._log(f"Found {len(servers)} server options", xbmc.LOGINFO)
        
        # Check SERVER INDEX cache (which server worked before)
        cache_key = video_page_url
        cached_server_index = self.cache.get_server_index(cache_key)
        
        verified_servers = []
        
        # SMART: Test cached server FIRST!
        if cached_server_index is not None and cached_server_index < len(servers):
            self._log(f"Testing CACHED server {cached_server_index + 1} first", xbmc.LOGINFO)
            
            server = servers[cached_server_index]
            embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
            
            if embed_url:
                embed_url = self._fix_url(embed_url)
                stream_url = self._resolve_server(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    self._log(f"SUCCESS! Cached server {cached_server_index + 1} still works!", xbmc.LOGINFO)
                    
                    quality = self._guess_quality(stream_url)
                    verified_servers.append({
                        'name': f"Server {cached_server_index + 1} (Cached)",
                        'url': stream_url,
                        'quality': quality
                    })
                    
                    # Update cache
                    self.cache.set_server_index(cache_key, cached_server_index)
                    
                    return verified_servers
                else:
                    self._log(f"Cached server {cached_server_index + 1} now dead", xbmc.LOGWARNING)
        
        # Test first N servers
        self._log(f"Testing first {MAX_SERVERS_TO_TEST} servers...", xbmc.LOGINFO)
        servers_to_test = servers[:MAX_SERVERS_TO_TEST]
        
        for idx, server in enumerate(servers_to_test):
            # Skip if we already tested cached server
            if idx == cached_server_index:
                continue
            
            embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
            if not embed_url:
                continue
            
            embed_url = self._fix_url(embed_url)
            server_name = f"Server {idx + 1}"
            
            stream_url = self._resolve_server(embed_url)
            
            if stream_url and self._test_stream_url(stream_url):
                quality = self._guess_quality(stream_url)
                verified_servers.append({
                    'name': server_name,
                    'url': stream_url,
                    'quality': quality
                })
                self._log(f"SUCCESS: {server_name} verified!", xbmc.LOGINFO)
                
                # Cache server index
                self.cache.set_server_index(cache_key, idx)
                
                break  # Stop after finding 1 (Android TV optimization)
        
        # Fallback to remaining servers if needed
        if not verified_servers and len(servers) > MAX_SERVERS_TO_TEST:
            self._log("Trying remaining servers...", xbmc.LOGINFO)
            
            for idx, server in enumerate(servers[MAX_SERVERS_TO_TEST:], start=MAX_SERVERS_TO_TEST):
                if idx == cached_server_index:
                    continue
                
                embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
                if not embed_url:
                    continue
                
                embed_url = self._fix_url(embed_url)
                stream_url = self._resolve_server(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    verified_servers.append({
                        'name': f"Server {idx + 1}",
                        'url': stream_url,
                        'quality': self._guess_quality(stream_url)
                    })
                    
                    self.cache.set_server_index(cache_key, idx)
                    break
        
        return verified_servers


