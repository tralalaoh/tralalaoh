# -*- coding: utf-8 -*-
"""
Minimal TMDB Lookup
For getting series names only
"""

import requests

try:
    import xbmc
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGINFO = 1
        LOGDEBUG = 0
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"[TMDB] {msg}")


class TMDBLookup:
    """Minimal TMDB client for name lookups only"""
    
    API_BASE = "https://api.themoviedb.org/3"
    
    def __init__(self, api_key):
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'User-Agent': 'Kodi-Turkish-Player/1.1'
        })
    
    def get_original_name(self, tmdb_id):
        """
        Get TMDB original name (for Qrmzi verification)
        
        Returns:
            str: Original name or None
        """
        
        url = f"{self.API_BASE}/tv/{tmdb_id}"
        
        try:
            response = self.session.get(url, params={
                'api_key': self.api_key
            }, timeout=10)
            
            response.raise_for_status()
            data = response.json()
            
            return data.get('original_name')
            
        except Exception as e:
            self._log(f"TMDB API error: {e}", xbmc.LOGERROR)
            return None
    
    def get_all_names(self, tmdb_id):
        """
        Get ALL name variants for a series
        
        Returns:
            List of names in priority order:
              - Arabic variants first (if any)
              - Then Turkish/English variants
        """
        
        url = f"{self.API_BASE}/tv/{tmdb_id}"
        
        try:
            response = self.session.get(url, params={
                'api_key': self.api_key,
                'append_to_response': 'alternative_titles,translations'
            }, timeout=10)
            
            response.raise_for_status()
            data = response.json()
            
        except Exception as e:
            self._log(f"TMDB API error: {e}", xbmc.LOGERROR)
            return []
        
        names = []
        
        # Original name
        if data.get('original_name'):
            names.append(data['original_name'])
        
        # Primary name
        if data.get('name') and data['name'] != data.get('original_name'):
            names.append(data['name'])
        
        # Translations (prioritize Arabic)
        translations = data.get('translations', {}).get('translations', [])
        
        # Arabic translations first
        for trans in translations:
            if trans.get('iso_639_1') == 'ar':
                trans_name = trans.get('data', {}).get('name', '')
                if trans_name and trans_name not in names:
                    names.append(trans_name)
        
        # Then Turkish/English
        for trans in translations:
            iso = trans.get('iso_639_1', '')
            if iso in ['tr', 'en']:
                trans_name = trans.get('data', {}).get('name', '')
                if trans_name and trans_name not in names:
                    names.append(trans_name)
        
        # Alternative titles
        for alt in data.get('alternative_titles', {}).get('results', []):
            title = alt.get('title', '')
            if title and title not in names:
                names.append(title)
        
        self._log(f"Got {len(names)} name variants for TMDB {tmdb_id}", xbmc.LOGINFO)
        
        return names
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message"""
        if KODI_ENV:
            xbmc.log(f"TMDBLookup: {message}", level)
        else:
            print(f"[TMDBLookup] {message}")
