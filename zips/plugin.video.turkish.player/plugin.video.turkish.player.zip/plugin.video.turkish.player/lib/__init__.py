# -*- coding: utf-8 -*-
"""
Turkish Series Player - Library Module
"""

__version__ = '1.1.0'
