# -*- coding: utf-8 -*-
"""
Fast Resolver - Multi-Provider Stream Selection
Shows ALL streams from enabled providers in a dialog
"""

import re
import requests

try:
    import xbmc
    import xbmcgui
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGDEBUG = 0
        LOGINFO = 1
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"[Resolver] {msg}")
    class xbmcgui:
        class Dialog:
            def select(self, title, items):
                print(f"\n{title}")
                for i, item in enumerate(items):
                    print(f"{i+1}. {item}")
                return 0

from .engines import Engine3SK, EngineQrmzi, EngineTurkish123
from .unified_cache import UnifiedSeriesCache
from .tmdb_lookup import TMDBLookup


class FastResolver:
    """
    Multi-provider resolver with stream selection dialog
    
    Strategy:
      - Gather streams from ALL enabled providers
      - Show selection dialog with provider labels
      - User picks preferred stream
    """
    
    def __init__(self, cache_dir, addon):
        """Initialize resolver"""
        self.addon = addon
        self.cache = UnifiedSeriesCache(cache_dir)
        
        # Memory cache for slugs/names
        self.memory_cache = {}
        
        # Initialize engines
        self.engine_3sk = Engine3SK()
        self.engine_qrmzi = EngineQrmzi()
        self.engine_turkish123 = EngineTurkish123()
        
        # Initialize TMDB lookup
        api_key = addon.getSetting('tmdb_api_key') or "c8578981f94591042c8a9b9837571314"
        self.tmdb = TMDBLookup(api_key)
        
        self._log("FastResolver initialized", xbmc.LOGINFO)
    
    def resolve(self, tmdb_id, season, episode):
        """
        Main resolver entry point - Now with multi-provider selection
        
        Returns:
            dict: {'url': '...', 'headers': {...}, 'quality': '...', 'engine': '...'}
            or None if failed
        """
        
        self._log(f"=== FAST RESOLVER (Multi-Provider) ===", xbmc.LOGINFO)
        self._log(f"TMDB: {tmdb_id}, S{season:02d}E{episode:02d}", xbmc.LOGINFO)
        
        # Check which providers are enabled
        use_3sk = self.addon.getSetting('use_3sk') != 'false'
        use_qrmzi = self.addon.getSetting('use_qrmzi') != 'false'
        use_turkish123 = self.addon.getSetting('use_turkish123') != 'false'
        
        self._log(f"Enabled providers: 3SK={use_3sk}, Qrmzi={use_qrmzi}, Turkish123={use_turkish123}", xbmc.LOGINFO)
        
        # Collect ALL streams from enabled providers
        all_streams = []
        
        # Try Arabic providers (3SK + Qrmzi)
        if use_3sk or use_qrmzi:
            self._log("=== TRYING ARABIC PROVIDERS ===", xbmc.LOGINFO)
            arabic_streams = self._get_arabic_streams(tmdb_id, season, episode, use_3sk, use_qrmzi)
            all_streams.extend(arabic_streams)
        
        # Try English provider (Turkish123)
        if use_turkish123:
            self._log("=== TRYING ENGLISH PROVIDER ===", xbmc.LOGINFO)
            english_streams = self._get_turkish123_streams(tmdb_id, season, episode)
            all_streams.extend(english_streams)
        
        # If no streams found
        if not all_streams:
            self._log("No streams found from any provider", xbmc.LOGERROR)
            return None
        
        self._log(f"Found {len(all_streams)} total streams", xbmc.LOGINFO)
        
        # If only one stream, use it automatically
        if len(all_streams) == 1:
            self._log("Only one stream found, using automatically", xbmc.LOGINFO)
            return all_streams[0]
        
        # Show selection dialog
        if KODI_ENV:
            selected_stream = self._show_stream_selection_dialog(all_streams)
            if not selected_stream:
                self._log("User cancelled stream selection", xbmc.LOGWARNING)
                return None
            return selected_stream
        else:
            # Non-Kodi: return first stream
            return all_streams[0]
    
    # =========================================================================
    # STREAM SELECTION DIALOG
    # =========================================================================
    
    def _show_stream_selection_dialog(self, streams):
        """
        Show dialog with all available streams
        
        Format: [Provider] Stream Name (Audio)
        Example:
          [3SK] Server 1 (Arabic Audio)
          [Qrmzi] HD Stream (Arabic Audio)
          [Turkish123] Server 1 (English Subs)
        """
        
        dialog = xbmcgui.Dialog()
        
        # Build display items
        display_items = []
        for stream in streams:
            provider = stream.get('engine', 'Unknown').upper()
            name = stream.get('name', 'Stream')
            audio = stream.get('audio', 'Unknown')
            quality = stream.get('quality', '')
            
            # Format: [3SK] Server 1 - HD (Arabic Audio)
            display_text = f"[{provider}] {name}"
            if quality:
                display_text += f" - {quality}"
            display_text += f" ({audio})"
            
            display_items.append(display_text)
        
        # Show dialog
        selected_index = dialog.select(
            'Select Stream / اختر المصدر',
            display_items
        )
        
        if selected_index < 0:
            return None
        
        selected_stream = streams[selected_index]
        self._log(f"User selected: {display_items[selected_index]}", xbmc.LOGINFO)
        
        return selected_stream
    
    # =========================================================================
    # ARABIC PROVIDERS (3SK + QRMZI)
    # =========================================================================
    
    def _get_arabic_streams(self, tmdb_id, season, episode, use_3sk, use_qrmzi):
        """
        Get streams from Arabic providers
        
        Returns list of stream dicts
        """
        
        streams = []
        
        # Get Arabic names
        arabic_names = self._get_arabic_names(tmdb_id)
        
        if not arabic_names:
            self._log("No Arabic names found", xbmc.LOGWARNING)
            return streams
        
        # Try Qrmzi first (automatic, verified)
        if use_qrmzi:
            self._log("=== TRYING QRMZI (Verified) ===", xbmc.LOGINFO)
            qrmzi_stream = self._resolve_qrmzi(tmdb_id, season, episode, arabic_names)
            if qrmzi_stream:
                streams.append(qrmzi_stream)
        
        # Try 3SK (may return multiple servers)
        if use_3sk:
            self._log("=== TRYING 3SK ===", xbmc.LOGINFO)
            three_sk_streams = self._resolve_3sk(tmdb_id, season, episode, arabic_names)
            streams.extend(three_sk_streams)
        
        return streams
    
    def _resolve_qrmzi(self, tmdb_id, season, episode, arabic_names):
        """
        Qrmzi resolver with forensic verification
        
        Returns single stream dict or None
        """
        
        # Get TMDB original name for verification
        original_name = self._get_tmdb_original_name(tmdb_id)
        
        if not original_name:
            self._log("No TMDB original name for verification", xbmc.LOGWARNING)
            return None
        
        # Try each Arabic name with verification
        for idx, arabic_name in enumerate(arabic_names, 1):
            self._log(f"Trying name {idx}/{len(arabic_names)}: {arabic_name[:30]}...", xbmc.LOGINFO)
            
            result = self.engine_qrmzi.resolve_episode(
                arabic_name=arabic_name,
                episode=episode,
                season=season,
                tmdb_original_name=original_name
            )
            
            if result:
                self._log(f"✓ Verified with: {arabic_name[:30]}", xbmc.LOGINFO)
                
                return {
                    'url': result['url'],
                    'quality': result.get('quality', 'HD'),
                    'engine': 'qrmzi',
                    'name': 'Qrmzi Stream',
                    'audio': 'Arabic Audio',
                    'headers': {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Referer': 'https://www.qrmzi.tv/',
                        'Accept': '*/*'
                    }
                }
        
        self._log("No verified match found in Qrmzi", xbmc.LOGWARNING)
        return None
    
    def _resolve_3sk(self, tmdb_id, season, episode, arabic_names):
        """
        3SK resolver - may return multiple servers
        
        Returns list of stream dicts
        """
        
        streams = []
        
        # Collect ALL matching episodes from all names
        all_matches = []
        
        for idx, arabic_name in enumerate(arabic_names, 1):
            self._log(f"Searching 3SK with name {idx}/{len(arabic_names)}: {arabic_name[:30]}...", xbmc.LOGINFO)
            
            # Search for this episode with this name
            episode_url = self._search_3sk_episode(arabic_name, episode)
            
            if episode_url:
                all_matches.append({
                    'url': episode_url,
                    'name': arabic_name,
                    'display': f"{arabic_name} - الحلقة {episode}"
                })
                self._log(f"✓ Found match: {arabic_name[:30]}", xbmc.LOGINFO)
        
        if not all_matches:
            self._log("No matches found with any Arabic name", xbmc.LOGWARNING)
            return streams
        
        self._log(f"Found {len(all_matches)} total 3SK matches", xbmc.LOGINFO)
        
        # Get streams from each match
        for idx, match in enumerate(all_matches, 1):
            episode_landing_url = match['url']
            
            # Construct /see/ URL
            if not episode_landing_url.endswith('/'):
                episode_landing_url += '/'
            
            see_page_url = episode_landing_url + 'see/'
            
            # Decode URL for use as Referer
            from urllib.parse import unquote
            see_page_url_decoded = unquote(see_page_url)
            
            self._log(f"Getting 3SK streams from match {idx}/{len(all_matches)}", xbmc.LOGINFO)
            
            # Get stream(s) from this episode
            episode_streams = self.engine_3sk.get_stream_url_from_video_page(see_page_url_decoded)
            
            if episode_streams:
                # Extract origin from URL
                from urllib.parse import urlparse
                parsed_url = urlparse(see_page_url_decoded)
                origin = f"{parsed_url.scheme}://{parsed_url.netloc}"
                
                # Add each stream with proper labeling
                for stream_idx, stream in enumerate(episode_streams, 1):
                    streams.append({
                        'url': stream['url'],
                        'quality': stream.get('quality', 'Auto'),
                        'engine': '3sk',
                        'name': f"{match['name'][:20]}... - {stream.get('name', 'Server')}",
                        'audio': 'Arabic Audio',
                        'headers': {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                            'Referer': see_page_url_decoded,
                            'Origin': origin,
                            'Accept': '*/*'
                        }
                    })
        
        self._log(f"Got {len(streams)} total streams from 3SK", xbmc.LOGINFO)
        return streams
    
    def _search_3sk_episode(self, arabic_name, episode_num):
        """
        Search 3SK for specific episode
        
        Returns:
            Landing page URL or None
        """
        from urllib.parse import quote_plus
        from bs4 import BeautifulSoup
        
        # Search query
        query = f"مسلسل {arabic_name} الحلقة {episode_num} مترجم"
        search_url = f"{self.engine_3sk.base_url}/?s={quote_plus(query)}"
        
        self._log(f"Search: {query[:50]}...", xbmc.LOGDEBUG)
        
        try:
            response = self.engine_3sk._request(search_url)
            if not response:
                return None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            articles = soup.select('article.post')[:10]
            
            if not articles:
                return None
            
            # Find first matching episode number
            for article in articles:
                ep_num_tag = article.select_one('.episodeNum')
                link = article.select_one('a')
                
                if not ep_num_tag or not link:
                    continue
                
                # Extract episode number
                num_text = ep_num_tag.text.strip()
                ep_match = re.search(r'(\d+)', num_text)
                
                if ep_match and int(ep_match.group(1)) == episode_num:
                    landing_url = link.get('href', '')
                    
                    if landing_url:
                        landing_url = self.engine_3sk._fix_url(landing_url)
                        return landing_url
            
            return None
            
        except Exception as e:
            self._log(f"Search error: {e}", xbmc.LOGERROR)
            return None
    
    # =========================================================================
    # TURKISH123 PROVIDER (ENGLISH SUBS)
    # =========================================================================
    
    def _get_turkish123_streams(self, tmdb_id, season, episode):
        """
        Get streams from Turkish123 (English subtitles)
        
        Returns list of stream dicts
        """
        
        streams = []
        
        # Get slug from cache
        slug = self._get_turkish123_slug(tmdb_id)
        
        # Try direct URL
        if slug:
            direct_url = f"https://www2.turkish123.org/{slug}-episode-{episode}/"
            
            self._log(f"Trying Turkish123 direct URL: {direct_url}", xbmc.LOGINFO)
            
            if self._url_exists(direct_url):
                self._log("✓ Direct URL exists!", xbmc.LOGINFO)
                
                episode_streams = self.engine_turkish123.get_stream_url(direct_url)
                
                if episode_streams:
                    for stream in episode_streams:
                        streams.append({
                            'url': stream['url'],
                            'quality': stream.get('quality', 'Auto'),
                            'engine': 'turkish123',
                            'name': stream.get('name', 'Turkish123 Stream'),
                            'audio': 'English Subs',
                            'headers': {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                'Referer': 'https://www2.turkish123.org/',
                                'Accept': '*/*'
                            }
                        })
                    
                    self._log(f"Got {len(streams)} streams from Turkish123", xbmc.LOGINFO)
                    return streams
        
        # Fallback - search series and cache slug
        self._log("Direct URL failed, searching Turkish123...", xbmc.LOGINFO)
        
        turkish_name = self._get_turkish_name(tmdb_id)
        
        if not turkish_name:
            self._log("No Turkish/English name found", xbmc.LOGWARNING)
            return streams
        
        search_results = self.engine_turkish123.search([turkish_name])
        
        if not search_results or len(search_results) == 0:
            self._log("No Turkish123 search results", xbmc.LOGWARNING)
            return streams
        
        series_url = search_results[0]['url']
        
        # Extract and cache slug
        slug = series_url.rstrip('/').split('/')[-1]
        self._cache_turkish123_slug(tmdb_id, slug)
        
        # Try direct URL again
        episode_url = f"https://www2.turkish123.org/{slug}-episode-{episode}/"
        
        episode_streams = self.engine_turkish123.get_stream_url(episode_url)
        
        if episode_streams:
            for stream in episode_streams:
                streams.append({
                    'url': stream['url'],
                    'quality': stream.get('quality', 'Auto'),
                    'engine': 'turkish123',
                    'name': stream.get('name', 'Turkish123 Stream'),
                    'audio': 'English Subs',
                    'headers': {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Referer': 'https://www2.turkish123.org/',
                        'Accept': '*/*'
                    }
                })
        
        self._log(f"Got {len(streams)} streams from Turkish123", xbmc.LOGINFO)
        return streams
    
    # =========================================================================
    # UTILITIES
    # =========================================================================
    
    def _get_arabic_names(self, tmdb_id):
        """Get Arabic name variants from TMDB"""
        all_names = self.tmdb.get_all_names(tmdb_id)
        
        arabic_names = []
        for name in all_names:
            if self._is_arabic(name):
                arabic_names.append(name)
        
        return arabic_names
    
    def _get_turkish_name(self, tmdb_id):
        """Get Turkish or English name from TMDB"""
        all_names = self.tmdb.get_all_names(tmdb_id)
        
        for name in all_names:
            if not self._is_arabic(name):
                normalized = self.engine_turkish123.normalize_for_search(name)
                return normalized
        
        return None
    
    def _get_tmdb_original_name(self, tmdb_id):
        """Get TMDB original name for verification"""
        return self.tmdb.get_original_name(tmdb_id)
    
    def _get_turkish123_slug(self, tmdb_id):
        """Get cached Turkish123 slug"""
        cache_key = f'turkish123_slug_{tmdb_id}'
        return self.memory_cache.get(cache_key)
    
    def _cache_turkish123_slug(self, tmdb_id, slug):
        """Cache Turkish123 slug"""
        cache_key = f'turkish123_slug_{tmdb_id}'
        self.memory_cache[cache_key] = slug
    
    def _url_exists(self, url):
        """Check if URL exists"""
        try:
            response = requests.head(url, timeout=3, allow_redirects=True)
            return response.status_code < 400
        except:
            return False
    
    def _is_arabic(self, text):
        """Check if text contains Arabic characters"""
        if not text:
            return False
        return any('\u0600' <= c <= '\u06FF' or '\u0750' <= c <= '\u077F' for c in text)
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message"""
        if KODI_ENV:
            xbmc.log(f"FastResolver: {message}", level)
        else:
            print(f"[FastResolver] {message}")
