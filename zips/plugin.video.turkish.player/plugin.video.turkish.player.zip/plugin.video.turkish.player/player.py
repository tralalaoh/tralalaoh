# -*- coding: utf-8 -*-
"""
Turkish Series Player - TMDb Helper Integration
Main entry point for stream resolution
"""

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Import resolver
from lib.resolver import FastResolver

# Constants
_handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_url = sys.argv[0] if len(sys.argv) > 0 else ""
addon = xbmcaddon.Addon()

def log(message, level=xbmc.LOGINFO):
    """Log message"""
    xbmc.log(f"TurkishPlayer: {message}", level)

def get_params():
    """Parse URL parameters"""
    if len(sys.argv) < 3:
        return {}
    return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

def play_episode(params):
    """
    Resolve and play episode
    Called by TMDb Helper
    """
    
    try:
        tmdb_id = int(params.get('tmdb_id', 0))
        season = int(params.get('season', 1))
        episode = int(params.get('episode', 1))
        title = params.get('title', 'Unknown')
        
        if not tmdb_id:
            log("Missing TMDB ID", xbmc.LOGERROR)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
        
        log(f"=== RESOLVING STREAM ===", xbmc.LOGINFO)
        log(f"Title: {title}", xbmc.LOGINFO)
        log(f"TMDB ID: {tmdb_id}", xbmc.LOGINFO)
        log(f"Episode: S{season:02d}E{episode:02d}", xbmc.LOGINFO)
        
        # Show progress dialog
        progress = xbmcgui.DialogProgress()
        progress.create('Turkish Series Player', f'{title}\nS{season:02d}E{episode:02d}')
        progress.update(10, 'Initializing resolver...')
        
        # Initialize resolver
        cache_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        resolver = FastResolver(cache_dir, addon)
        
        progress.update(30, 'Searching for stream...')
        
        # Resolve stream
        result = resolver.resolve(tmdb_id, season, episode)
        
        progress.close()
        
        if not result:
            log("No stream found", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                'Turkish Series Player',
                'No stream found for this episode',
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
        
        # Create playable item
        stream_url = result['url']
        
        log(f"Stream URL: {stream_url[:80]}...", xbmc.LOGINFO)
        log(f"Engine: {result.get('engine', 'unknown')}", xbmc.LOGINFO)
        log(f"Quality: {result.get('quality', 'unknown')}", xbmc.LOGINFO)
        
        # Format headers for HLS
        headers = result.get('headers', {})
        if headers and '.m3u8' in stream_url.lower():
            header_string = '&'.join([f'{k}={v}' for k, v in headers.items()])
            stream_url_with_headers = f"{stream_url}|{header_string}"
            play_item = xbmcgui.ListItem(path=stream_url_with_headers)
            
            # Enable inputstream.adaptive for HLS
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        else:
            play_item = xbmcgui.ListItem(path=stream_url)
        
        # Set video info
        play_item.setInfo('video', {
            'title': f'{title} - S{season:02d}E{episode:02d}',
            'episode': episode,
            'season': season,
            'tvshowtitle': title,
            'mediatype': 'episode'
        })
        
        play_item.setProperty('IsPlayable', 'true')
        
        if '.m3u8' in stream_url.lower():
            play_item.setMimeType('application/vnd.apple.mpegurl')
            play_item.setContentLookup(False)
        
        # Start playback
        xbmcplugin.setResolvedUrl(_handle, True, play_item)
        
        log("Playback started successfully", xbmc.LOGINFO)
        
    except Exception as e:
        log(f"Playback error: {e}", xbmc.LOGERROR)
        import traceback
        log(traceback.format_exc(), xbmc.LOGERROR)
        
        xbmcgui.Dialog().notification(
            'Turkish Series Player',
            f'Error: {str(e)}',
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def router():
    """Route to appropriate function"""
    params = get_params()
    
    action = params.get('action', '')
    
    if action == 'play':
        play_episode(params)
    else:
        log(f"Unknown action: {action}", xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

if __name__ == '__main__':
    log("=== TURKISH SERIES PLAYER STARTED ===", xbmc.LOGINFO)
    
    try:
        router()
    except Exception as e:
        log(f"Router error: {e}", xbmc.LOGERROR)
        import traceback
        log(traceback.format_exc(), xbmc.LOGERROR)
    
    log("=== TURKISH SERIES PLAYER FINISHED ===", xbmc.LOGINFO)
