import sqlite3
import xbmc
import xbmcvfs
import time
import os
from resources.lib.settings import Settings


class Database:
    """SQLite database for tracking progress"""
    
    def __init__(self):
        self.settings = Settings()
        
        # Database path in addon data
        addon_data = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.upt/')
        if not xbmcvfs.exists(addon_data):
            xbmcvfs.mkdirs(addon_data)
        
        self.db_path = os.path.join(addon_data, 'upt.db')
        self.conn = None
        self.cursor = None
        self._connect()
        self._create_tables()
    
    def _connect(self):
        """Connect to database"""
        try:
            self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self.conn.row_factory = sqlite3.Row
            self.cursor = self.conn.cursor()
            self.log("Database connected")
        except Exception as e:
            self.log(f"Database connection error: {e}", xbmc.LOGERROR)
    
    def _create_tables(self):
        """Create tables if they don't exist"""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS tracked_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                
                -- The plugin URL (unique identifier)
                plugin_url TEXT UNIQUE NOT NULL,
                
                -- Display metadata
                title TEXT NOT NULL,
                poster TEXT,
                
                -- Episode info (NULL for movies)
                season INTEGER,
                episode INTEGER,
                episode_title TEXT,
                
                -- Media type
                mediatype TEXT,
                
                -- Progress tracking
                current_time INTEGER DEFAULT 0,
                total_time INTEGER DEFAULT 0,
                
                -- Timestamps
                date_added INTEGER NOT NULL,
                last_watched INTEGER NOT NULL,
                watch_count INTEGER DEFAULT 1
            )
        ''')
        
        # Create index for faster queries
        self.cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_last_watched 
            ON tracked_items(last_watched DESC)
        ''')
        
        self.conn.commit()
        self.log("Database tables ready")
    
    def add_or_update_item(self, item_data):
        """Add new item or update existing"""
        try:
            plugin_url = item_data['plugin_url']
            current_timestamp = int(time.time())
            
            # Check if exists
            existing = self.cursor.execute(
                'SELECT id, current_time, watch_count FROM tracked_items WHERE plugin_url = ?',
                (plugin_url,)
            ).fetchone()
            
            if existing:
                # Update existing
                self.cursor.execute('''
                    UPDATE tracked_items 
                    SET last_watched = ?,
                        watch_count = watch_count + 1,
                        total_time = ?,
                        title = ?,
                        poster = ?,
                        season = ?,
                        episode = ?,
                        episode_title = ?,
                        mediatype = ?
                    WHERE plugin_url = ?
                ''', (
                    current_timestamp,
                    item_data.get('total_time', 0),
                    item_data['title'],
                    item_data.get('poster', ''),
                    item_data.get('season'),
                    item_data.get('episode'),
                    item_data.get('episode_title'),
                    item_data.get('mediatype', 'movie'),
                    plugin_url
                ))
                self.log(f"Updated: {item_data['title']}")
            else:
                # Insert new
                self.cursor.execute('''
                    INSERT INTO tracked_items 
                    (plugin_url, title, poster, season, episode, episode_title,
                     mediatype, total_time, current_time, date_added, last_watched)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    plugin_url,
                    item_data['title'],
                    item_data.get('poster', ''),
                    item_data.get('season'),
                    item_data.get('episode'),
                    item_data.get('episode_title'),
                    item_data.get('mediatype', 'movie'),
                    item_data.get('total_time', 0),
                    0,  # current_time starts at 0
                    current_timestamp,
                    current_timestamp
                ))
                self.log(f"Added: {item_data['title']}")
            
            self.conn.commit()
            return True
            
        except Exception as e:
            self.log(f"Error adding/updating item: {e}", xbmc.LOGERROR)
            return False
    
    def update_progress(self, plugin_url, current_time):
        """Update playback progress"""
        try:
            self.cursor.execute('''
                UPDATE tracked_items 
                SET current_time = ?, 
                    last_watched = ?
                WHERE plugin_url = ?
            ''', (int(current_time), int(time.time()), plugin_url))
            
            self.conn.commit()
            return True
        except Exception as e:
            self.log(f"Error updating progress: {e}", xbmc.LOGERROR)
            return False
    
    def get_continue_watching_items(self):
        """Get items for continue watching menu"""
        try:
            min_time = self.settings.get('minimum_resume_time', 30)
            watched_threshold = self.settings.get('watched_threshold', 90)
            max_items = self.settings.get('max_items_display', 50)
            hide_watched = self.settings.get('hide_watched', True)
            sort_by = self.settings.get('sort_by', 0)
            
            # Build query
            query = '''
                SELECT * FROM tracked_items
                WHERE current_time >= ?
                AND total_time > 0
            '''
            
            params = [min_time]
            
            # Filter watched items
            if hide_watched:
                query += ' AND (current_time * 100.0 / total_time) < ?'
                params.append(watched_threshold)
            
            # Sort order
            if sort_by == 0:  # Last Watched
                query += ' ORDER BY last_watched DESC'
            elif sort_by == 1:  # Date Added
                query += ' ORDER BY date_added DESC'
            elif sort_by == 2:  # Title
                query += ' ORDER BY title ASC'
            
            query += ' LIMIT ?'
            params.append(max_items)
            
            self.cursor.execute(query, params)
            items = [dict(row) for row in self.cursor.fetchall()]
            
            self.log(f"Retrieved {len(items)} continue watching items")
            return items
            
        except Exception as e:
            self.log(f"Error getting continue watching items: {e}", xbmc.LOGERROR)
            return []
    
    def get_item_by_url(self, plugin_url):
        """Get single item by plugin URL"""
        try:
            self.cursor.execute(
                'SELECT * FROM tracked_items WHERE plugin_url = ?',
                (plugin_url,)
            )
            row = self.cursor.fetchone()
            return dict(row) if row else None
        except Exception as e:
            self.log(f"Error getting item: {e}", xbmc.LOGERROR)
            return None
    
    def remove_item(self, item_id):
        """Remove item from tracking"""
        try:
            self.cursor.execute('DELETE FROM tracked_items WHERE id = ?', (item_id,))
            self.conn.commit()
            self.log(f"Removed item ID: {item_id}")
            return True
        except Exception as e:
            self.log(f"Error removing item: {e}", xbmc.LOGERROR)
            return False
    
    def clear_all(self):
        """Clear all tracked items"""
        try:
            self.cursor.execute('DELETE FROM tracked_items')
            self.conn.commit()
            self.log("All items cleared")
            return True
        except Exception as e:
            self.log(f"Error clearing items: {e}", xbmc.LOGERROR)
            return False
    
    def cleanup_old_items(self):
        """Remove old items based on settings"""
        try:
            if not self.settings.get('auto_cleanup', True):
                return 0
            
            cache_days = self.settings.get('cache_days', 60)
            max_items = self.settings.get('max_items', 500)
            
            cutoff_time = int(time.time()) - (cache_days * 86400)
            
            # Remove old items
            self.cursor.execute(
                'DELETE FROM tracked_items WHERE last_watched < ?',
                (cutoff_time,)
            )
            deleted = self.cursor.rowcount
            
            # Remove excess items (keep most recent)
            self.cursor.execute('''
                DELETE FROM tracked_items 
                WHERE id NOT IN (
                    SELECT id FROM tracked_items 
                    ORDER BY last_watched DESC 
                    LIMIT ?
                )
            ''', (max_items,))
            deleted += self.cursor.rowcount
            
            self.conn.commit()
            
            if deleted > 0:
                self.log(f"Cleanup: removed {deleted} old items")
            
            return deleted
            
        except Exception as e:
            self.log(f"Error during cleanup: {e}", xbmc.LOGERROR)
            return 0
    
    def get_stats(self):
        """Get database statistics"""
        try:
            self.cursor.execute('SELECT COUNT(*) as total FROM tracked_items')
            total = self.cursor.fetchone()['total']
            
            self.cursor.execute('''
                SELECT COUNT(*) as in_progress FROM tracked_items 
                WHERE current_time > 0 
                AND (current_time * 100.0 / total_time) < 90
            ''')
            in_progress = self.cursor.fetchone()['in_progress']
            
            return {
                'total': total,
                'in_progress': in_progress
            }
        except Exception as e:
            self.log(f"Error getting stats: {e}", xbmc.LOGERROR)
            return {'total': 0, 'in_progress': 0}
    
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            self.log("Database connection closed")
    
    def log(self, msg, level=xbmc.LOGDEBUG):
        """Log with database prefix"""
        if self.settings.get('debug_logging', False) or level >= xbmc.LOGINFO:
            xbmc.log(f"[UPT Database] {msg}", level)
