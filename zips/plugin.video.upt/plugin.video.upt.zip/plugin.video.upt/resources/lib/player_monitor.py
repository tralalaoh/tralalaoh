import xbmc
import time
import threading
import json
from resources.lib.database import Database
from resources.lib.settings import Settings


class PrePlayCache:
    """
    Cache for storing metadata before playback starts.
    Captures data from Kodi notifications BEFORE setResolvedUrl() clears it.
    """
    
    def __init__(self):
        self.cache = {}
        self.lock = threading.Lock()
        self.max_age = 60  # Cache entries expire after 60 seconds
    
    def store(self, metadata):
        """Store metadata with timestamp as key"""
        with self.lock:
            timestamp = int(time.time())
            self.cache[timestamp] = {
                'metadata': metadata,
                'timestamp': time.time()
            }
            # Cleanup old entries
            self._cleanup()
    
    def get_latest(self):
        """Get the most recently added metadata"""
        with self.lock:
            self._cleanup()
            if not self.cache:
                return None
            
            # Get most recent entry
            latest_key = max(self.cache.keys())
            return self.cache[latest_key]['metadata']
    
    def _cleanup(self):
        """Remove expired entries"""
        current_time = time.time()
        expired = [key for key, data in self.cache.items() 
                   if current_time - data['timestamp'] > self.max_age]
        for key in expired:
            del self.cache[key]
    
    def clear(self):
        """Clear all cached metadata"""
        with self.lock:
            self.cache.clear()


class UPTNotificationMonitor(xbmc.Monitor):
    """
    Monitor Kodi notifications to capture metadata BEFORE playback starts.
    This captures title, show name, season, episode, and art.
    """
    
    def __init__(self, preplay_cache):
        xbmc.Monitor.__init__(self)
        self.preplay_cache = preplay_cache
        self.log("Notification monitor initialized", xbmc.LOGINFO)
    
    def log(self, msg, level=xbmc.LOGDEBUG):
        xbmc.log(f"[UPT Notification] {msg}", level)
    
    def onNotification(self, sender, method, data):
        """
        Called when Kodi sends a notification.
        We're looking for Player.OnPlay which fires BEFORE playback with metadata.
        """
        try:
            # We want Player.OnPlay - fires when user clicks play
            if method == 'Player.OnPlay':
                self.log("Player.OnPlay notification received!", xbmc.LOGINFO)
                
                # Parse the notification data
                notification_data = json.loads(data)
                
                # Extract item data
                item = notification_data.get('item', {})
                
                self.log(f"Notification data: {item}", xbmc.LOGINFO)
                
                # Extract metadata (title, show, season, episode, art)
                metadata = {
                    'title': item.get('title', ''),
                    'showtitle': item.get('showtitle', ''),
                    'tvshowtitle': item.get('tvshowtitle', ''),
                    'season': item.get('season', -1),
                    'episode': item.get('episode', -1),
                    'type': item.get('type', ''),
                    'label': item.get('label', ''),
                    'art': item.get('art', {}),
                }
                
                self.log("=== PRE-PLAY METADATA CAPTURED ===", xbmc.LOGINFO)
                self.log(f"  Title: {metadata['title']}", xbmc.LOGINFO)
                self.log(f"  Show: {metadata['showtitle'] or metadata['tvshowtitle']}", xbmc.LOGINFO)
                self.log(f"  Season: {metadata['season']}, Episode: {metadata['episode']}", xbmc.LOGINFO)
                self.log(f"  Type: {metadata['type']}", xbmc.LOGINFO)
                
                # Store in pre-play cache (no URL needed, just metadata)
                self.preplay_cache.store(metadata)
                self.log("✓ Metadata stored in pre-play cache", xbmc.LOGINFO)
                
        except Exception as e:
            self.log(f"Error in onNotification: {e}", xbmc.LOGERROR)
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)


class UPTPlayerMonitor(xbmc.Player):
    """Monitor player and automatically track progress"""
    
    def __init__(self, preplay_cache):
        xbmc.Player.__init__(self)
        self.db = Database()
        self.settings = Settings()
        
        # Pre-play metadata cache (shared with notification monitor)
        self.preplay_cache = preplay_cache
        
        # Tracking state
        self.current_plugin_url = None
        self.tracking_timer = None
        self.is_tracking = False
        
        # Register for settings changes
        self.settings.register_callback(self.on_settings_changed)
        
        self.log("Player monitor initialized", xbmc.LOGINFO)
    
    def on_settings_changed(self, changed):
        """Handle settings changes"""
        self.log(f"Settings updated: {list(changed.keys())}")
        
        # If tracking precision changed, restart timer
        if 'track_precision' in changed and self.is_tracking:
            self.log("Track precision changed - restarting timer")
            self.stop_tracking_timer()
            self.start_tracking_timer()
    
    def onPlayBackStarted(self):
        """
        Compatibility callback for older Kodi versions
        This will call onAVStarted for consistency
        """
        self.log("onPlayBackStarted callback fired!", xbmc.LOGINFO)
        self.onAVStarted()
    
    def onAVStarted(self):
        """Called when playback starts"""
        self.log("onAVStarted callback fired!", xbmc.LOGINFO)
        
        try:
            # Wait a bit for video to actually start
            for attempt in range(3):
                if self.isPlayingVideo():
                    self.log(f"Video playing confirmed (attempt {attempt + 1})", xbmc.LOGINFO)
                    break
                self.log(f"Not playing yet, waiting... (attempt {attempt + 1})", xbmc.LOGINFO)
                xbmc.sleep(500)
            else:
                self.log("Not playing video after 3 attempts - skipping", xbmc.LOGINFO)
                return
            
            self.log("Video playback detected - extracting metadata...", xbmc.LOGINFO)
            
            # Wait a moment for metadata to load
            xbmc.sleep(1000)
            
            # Extract metadata
            item_data = self.extract_metadata()
            
            if not item_data:
                self.log("No valid metadata - skipping tracking", xbmc.LOGINFO)
                return
            
            # Check if should track
            if not self.should_track(item_data):
                self.log(f"Not tracking: {item_data.get('title', 'Unknown')}", xbmc.LOGINFO)
                return
            
            # Store in database
            self.log("Storing item in database...", xbmc.LOGINFO)
            self.db.add_or_update_item(item_data)
            self.current_plugin_url = item_data['plugin_url']
            
            # Start tracking
            self.start_tracking_timer()
            self.log(f"✓ NOW TRACKING: {item_data['title']}", xbmc.LOGINFO)
            
            if self.settings.get('enable_notifications', True):
                xbmc.executebuiltin(f'Notification(UPT, Now tracking: {item_data["title"]}, 3000)')
            
        except Exception as e:
            self.log(f"CRITICAL ERROR in onAVStarted: {e}", xbmc.LOGERROR)
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
    
    def onPlayBackStopped(self):
        """Called when playback is stopped"""
        self.log("onPlayBackStopped callback fired!", xbmc.LOGINFO)
        try:
            if self.is_tracking:
                self.save_current_progress()
                self.stop_tracking_timer()
                self.log("Playback stopped - progress saved", xbmc.LOGINFO)
        except Exception as e:
            self.log(f"Error in onPlayBackStopped: {e}", xbmc.LOGERROR)
    
    def onPlayBackEnded(self):
        """Called when playback ends naturally"""
        self.log("onPlayBackEnded callback fired!", xbmc.LOGINFO)
        try:
            if self.is_tracking:
                # Mark as fully watched
                if self.current_plugin_url:
                    item = self.db.get_item_by_url(self.current_plugin_url)
                    if item:
                        # Set to 100%
                        self.db.update_progress(self.current_plugin_url, item['total_time'])
                        self.log(f"Marked as watched: {item['title']}", xbmc.LOGINFO)
                
                self.stop_tracking_timer()
        except Exception as e:
            self.log(f"Error in onPlayBackEnded: {e}", xbmc.LOGERROR)
    
    def extract_metadata(self):
        """Extract metadata from currently playing item"""
        self.log("=== EXTRACTING METADATA ===", xbmc.LOGINFO)
        
        try:
            # STEP 1: Get the REAL plugin URL (what the user clicked)
            plugin_url = None
            
            # Method A: Player.Filenameandpath (most reliable for plugin URLs)
            try:
                filepath = xbmc.getInfoLabel('Player.Filenameandpath')
                self.log(f"Player.Filenameandpath: '{filepath[:100] if filepath else 'Empty'}'", xbmc.LOGINFO)
                if filepath and filepath.startswith('plugin://'):
                    plugin_url = filepath
                    self.log(f"✓ Got plugin URL from Player.Filenameandpath", xbmc.LOGINFO)
            except Exception as e:
                self.log(f"Error getting Player.Filenameandpath: {e}", xbmc.LOGINFO)
            
            # Method B: ListItem.FolderPath (fallback)
            if not plugin_url:
                try:
                    folderpath = xbmc.getInfoLabel('ListItem.FolderPath')
                    self.log(f"ListItem.FolderPath: '{folderpath[:100] if folderpath else 'Empty'}'", xbmc.LOGINFO)
                    if folderpath and folderpath.startswith('plugin://'):
                        plugin_url = folderpath
                        self.log(f"✓ Got plugin URL from ListItem.FolderPath", xbmc.LOGINFO)
                except Exception as e:
                    self.log(f"Error getting ListItem.FolderPath: {e}", xbmc.LOGINFO)
            
            # Method C: ListItem.Path
            if not plugin_url:
                try:
                    path = xbmc.getInfoLabel('ListItem.Path')
                    self.log(f"ListItem.Path: '{path[:100] if path else 'Empty'}'", xbmc.LOGINFO)
                    if path and path.startswith('plugin://'):
                        plugin_url = path
                        self.log(f"✓ Got plugin URL from ListItem.Path", xbmc.LOGINFO)
                except Exception as e:
                    self.log(f"Error getting ListItem.Path: {e}", xbmc.LOGINFO)
            
            # Method D: Use getPlayingFile() and check if it's a plugin URL
            if not plugin_url:
                try:
                    playing_file = self.getPlayingFile()
                    self.log(f"getPlayingFile(): '{playing_file[:100] if playing_file else 'Empty'}'", xbmc.LOGINFO)
                    if playing_file and playing_file.startswith('plugin://'):
                        plugin_url = playing_file
                        self.log(f"✓ Got plugin URL from getPlayingFile()", xbmc.LOGINFO)
                except Exception as e:
                    self.log(f"Error getting PlayingFile: {e}", xbmc.LOGINFO)
            
            # CRITICAL CHECK: Do we have a valid plugin URL?
            if not plugin_url or not plugin_url.startswith('plugin://'):
                self.log(f"REJECT: No valid plugin URL found (got: '{plugin_url}')", xbmc.LOGINFO)
                self.log("This is likely not a plugin-based video - skipping", xbmc.LOGINFO)
                return None
            
            self.log(f"=== PLUGIN URL CAPTURED: {plugin_url[:100]}... ===", xbmc.LOGINFO)
            
            # STEP 2: Get metadata from pre-play cache
            cached_metadata = self.preplay_cache.get_latest()
            
            if cached_metadata:
                self.log("✓ Using cached metadata from notification", xbmc.LOGINFO)
                title = cached_metadata.get('title', '')
                showtitle = cached_metadata.get('showtitle') or cached_metadata.get('tvshowtitle', '')
                season = cached_metadata.get('season', -1)
                episode = cached_metadata.get('episode', -1)
                mediatype = cached_metadata.get('type', '')
                
                # Get poster from art (cached from notification)
                art = cached_metadata.get('art', {})
                poster = art.get('tvshow.poster', '') or art.get('poster', '') or art.get('thumb', '')
                
                self.log(f"  Cached title: {title}", xbmc.LOGINFO)
                self.log(f"  Cached show: {showtitle}", xbmc.LOGINFO)
                self.log(f"  Cached S{season}E{episode}", xbmc.LOGINFO)
                self.log(f"  Cached poster: {'YES' if poster else 'NO'}", xbmc.LOGINFO)
            else:
                # Fallback to InfoTag
                self.log("⚠ No cached metadata, using InfoTag fallback", xbmc.LOGINFO)
                info_tag = self.getVideoInfoTag()
                mediatype = info_tag.getMediaType()
                title = info_tag.getTitle()
                showtitle = info_tag.getTVShowTitle()
                season = info_tag.getSeason()
                episode = info_tag.getEpisode()
                
                # Try multiple poster sources
                poster = ''
                art_types = ['tvshow.poster', 'poster', 'thumb', 'fanart']
                for art_type in art_types:
                    art_value = xbmc.getInfoLabel(f'ListItem.Art({art_type})')
                    if art_value and not poster:
                        poster = art_value
                        break
                
                # Fallback to InfoLabels if VideoInfoTag is empty
                if not title:
                    title = xbmc.getInfoLabel('ListItem.Title')
                if not showtitle:
                    showtitle = xbmc.getInfoLabel('ListItem.TVShowTitle')
                if not mediatype:
                    mediatype = xbmc.getInfoLabel('ListItem.DBTYPE')
            
            # POSTER ENHANCEMENT: If no poster yet, query plugin URL via JSON-RPC
            if not poster and plugin_url:
                self.log("⚠ No poster from InfoLabels - querying plugin URL via JSON-RPC...", xbmc.LOGINFO)
                poster = self.fetch_poster_from_plugin(plugin_url)
                if poster:
                    self.log(f"✓ JSON-RPC poster fetched: {poster[:60]}...", xbmc.LOGINFO)
                else:
                    self.log("✗ Could not fetch poster via JSON-RPC - trying TMDB fallback", xbmc.LOGINFO)
                    # Fallback: Try to get poster from TMDB API
                    poster = self.fetch_poster_from_tmdb(plugin_url, mediatype or 'tv')
                    if poster:
                        self.log(f"✓ TMDB poster fetched: {poster[:60]}...", xbmc.LOGINFO)
            
            # STEP 3: Build item_data using PLUGIN URL as primary key
            if mediatype == 'episode' or (season and season > 0):
                item_data = {
                    'plugin_url': plugin_url,
                    'title': showtitle or title,
                    'poster': poster,
                    'season': season if season > 0 else None,
                    'episode': episode if episode > 0 else None,
                    'episode_title': title,
                    'mediatype': 'episode'
                }
            else:
                item_data = {
                    'plugin_url': plugin_url,
                    'title': title,
                    'poster': poster,
                    'season': None,
                    'episode': None,
                    'episode_title': None,
                    'mediatype': mediatype or 'movie'
                }
            
            # STEP 4: Get duration
            try:
                total_time = int(self.getTotalTime())
                item_data['total_time'] = total_time
                self.log(f"Total time: {total_time}s", xbmc.LOGINFO)
            except Exception as e:
                item_data['total_time'] = 0
                self.log(f"Could not get total time: {e}", xbmc.LOGINFO)
            
            item_data['current_time'] = 0
            
            self.log(f"=== METADATA EXTRACTED ===", xbmc.LOGINFO)
            self.log(f"  Plugin URL: {item_data['plugin_url'][:80]}...", xbmc.LOGINFO)
            self.log(f"  Title: {item_data['title']}", xbmc.LOGINFO)
            self.log(f"  Type: {item_data['mediatype']}", xbmc.LOGINFO)
            self.log(f"  Duration: {item_data['total_time']}s", xbmc.LOGINFO)
            if item_data.get('season'):
                self.log(f"  Season: {item_data['season']}, Episode: {item_data['episode']}", xbmc.LOGINFO)
            
            return item_data
            
        except Exception as e:
            self.log(f"CRITICAL ERROR extracting metadata: {e}", xbmc.LOGERROR)
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return None
    
    def fetch_poster_from_plugin(self, plugin_url):
        """
        Fetch poster by querying the plugin URL via Kodi JSON-RPC.
        This gets the EXACT metadata that Kodi has for this URL!
        """
        try:
            # Build JSON-RPC query
            query = {
                "jsonrpc": "2.0",
                "method": "Files.GetFileDetails",
                "params": {
                    "file": plugin_url,
                    "media": "video",
                    "properties": ["art", "thumbnail", "fanart"]
                },
                "id": 1
            }
            
            self.log(f"JSON-RPC query: Files.GetFileDetails for {plugin_url[:60]}...", xbmc.LOGINFO)
            
            # Execute JSON-RPC call
            response = xbmc.executeJSONRPC(json.dumps(query))
            data = json.loads(response)
            
            # Check for errors
            if 'error' in data:
                self.log(f"JSON-RPC error: {data['error']}", xbmc.LOGINFO)
                return None
            
            # Extract art
            filedetails = data.get('result', {}).get('filedetails', {})
            art = filedetails.get('art', {})
            
            self.log(f"JSON-RPC response art keys: {list(art.keys())}", xbmc.LOGINFO)
            
            # Try different art types in priority order
            poster = (
                art.get('tvshow.poster', '') or
                art.get('poster', '') or
                art.get('thumb', '') or
                art.get('fanart', '') or
                filedetails.get('thumbnail', '')
            )
            
            if poster:
                self.log(f"✓ Found poster in JSON-RPC response", xbmc.LOGINFO)
                return poster
            else:
                self.log("No poster found in JSON-RPC response", xbmc.LOGINFO)
                return None
                
        except Exception as e:
            self.log(f"Error in JSON-RPC poster fetch: {e}", xbmc.LOGERROR)
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return None
    
    def fetch_poster_from_tmdb(self, plugin_url, mediatype='tv'):
        """
        Fallback: Fetch poster from TMDB API when JSON-RPC fails.
        Parses tmdb_id from plugin URL.
        """
        try:
            # Get API key from settings
            api_key = self.settings.get('tmdb_api_key', '').strip()
            
            if not api_key:
                self.log("No TMDB API key in settings - cannot fetch poster", xbmc.LOGINFO)
                self.log("Please add your TMDB API key in UPT Settings → Advanced", xbmc.LOGINFO)
                return None
            
            # Extract TMDB ID from URL
            import re
            from urllib.parse import urlparse, parse_qs
            
            parsed = urlparse(plugin_url)
            params = parse_qs(parsed.query)
            
            tmdb_id = None
            if 'tmdb_id' in params:
                tmdb_id = params['tmdb_id'][0]
            elif 'id' in params:
                try:
                    tmdb_id = int(params['id'][0])
                except:
                    pass
            
            if not tmdb_id:
                self.log("No TMDB ID found in plugin URL", xbmc.LOGINFO)
                return None
            
            self.log(f"Extracted TMDB ID: {tmdb_id}", xbmc.LOGINFO)
            
            # Build TMDB API URL
            if mediatype == 'episode' or mediatype == 'tv':
                api_url = f"https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={api_key}"
            else:
                api_url = f"https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={api_key}"
            
            self.log(f"Fetching from TMDB: {api_url[:80]}...", xbmc.LOGINFO)
            
            # Make request
            try:
                from urllib.request import urlopen, Request
            except ImportError:
                from urllib2 import urlopen, Request
            
            req = Request(api_url)
            req.add_header('User-Agent', 'Kodi/UPT')
            
            response = urlopen(req, timeout=5)
            tmdb_data = json.loads(response.read().decode('utf-8'))
            
            # Extract poster
            poster_path = tmdb_data.get('poster_path')
            if poster_path:
                poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}"
                self.log(f"✓ TMDB poster found", xbmc.LOGINFO)
                return poster_url
            else:
                self.log("No poster_path in TMDB response", xbmc.LOGINFO)
                return None
                
        except Exception as e:
            self.log(f"Error fetching TMDB poster: {e}", xbmc.LOGERROR)
            return None
    
    def should_track(self, item_data):
        """Determine if item should be tracked"""
        self.log(f"=== SHOULD_TRACK CHECK ===", xbmc.LOGINFO)
        
        if not item_data:
            self.log("REJECT: No item_data provided", xbmc.LOGINFO)
            return False
        
        # Must have a plugin URL
        if not item_data.get('plugin_url'):
            self.log(f"REJECT: No plugin_url", xbmc.LOGINFO)
            return False
        
        # Must have a title
        if not item_data.get('title'):
            self.log(f"REJECT: No title", xbmc.LOGINFO)
            return False
        
        # Check minimum duration
        min_duration = self.settings.get('minimum_resume_time', 30)
        total_time = item_data.get('total_time', 0)
        
        self.log(f"Duration check: {total_time}s (minimum: {min_duration}s)", xbmc.LOGINFO)
        
        if total_time < min_duration:
            self.log(f"REJECT: Duration too short: {total_time}s < {min_duration}s", xbmc.LOGINFO)
            return False
        
        self.log(f"ACCEPT: Will track '{item_data.get('title')}'", xbmc.LOGINFO)
        return True
    
    def start_tracking_timer(self):
        """Start periodic progress tracking"""
        self.is_tracking = True
        self.schedule_next_save()
    
    def schedule_next_save(self):
        """Schedule next progress save"""
        if not self.is_tracking:
            return
        
        interval = self.settings.get('track_precision', 15)
        self.tracking_timer = threading.Timer(interval, self.periodic_save)
        self.tracking_timer.daemon = True
        self.tracking_timer.start()
    
    def periodic_save(self):
        """Save progress periodically"""
        try:
            if self.isPlaying() and self.current_plugin_url:
                self.save_current_progress()
                # Schedule next save
                self.schedule_next_save()
        except Exception as e:
            self.log(f"Error in periodic save: {e}", xbmc.LOGERROR)
    
    def save_current_progress(self):
        """Save current playback position"""
        try:
            if not self.current_plugin_url:
                return
            
            current_time = int(self.getTime())
            self.db.update_progress(self.current_plugin_url, current_time)
            
            if self.settings.get('debug_logging', False):
                self.log(f"Progress saved: {current_time}s")
                
        except Exception as e:
            self.log(f"Error saving progress: {e}", xbmc.LOGERROR)
    
    def stop_tracking_timer(self):
        """Stop the tracking timer"""
        self.is_tracking = False
        if self.tracking_timer:
            self.tracking_timer.cancel()
            self.tracking_timer = None
        self.current_plugin_url = None
    
    def cleanup(self):
        """Cleanup resources"""
        self.stop_tracking_timer()
        self.settings.unregister_callback(self.on_settings_changed)
        self.db.close()
    
    def log(self, msg, level=xbmc.LOGDEBUG):
        """Log with player monitor prefix"""
        if level >= xbmc.LOGINFO or self.settings.get('debug_logging', False):
            xbmc.log(f"[UPT PlayerMonitor] {msg}", level)
