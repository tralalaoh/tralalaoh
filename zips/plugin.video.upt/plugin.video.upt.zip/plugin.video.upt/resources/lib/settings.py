import xbmcaddon
import xbmc
import threading


class Settings:
    """Settings helper with change detection and hot-reload"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, '_initialized'):
            self.addon = xbmcaddon.Addon('plugin.video.upt')
            self._cache = {}
            self._callbacks = []
            self._last_modified = 0
            self._initialized = True
            self._load_settings()
    
    def _load_settings(self):
        """Load all settings into cache"""
        self._cache = {
            # Tracking
            'track_precision': self.addon.getSettingInt('track_precision'),
            'minimum_resume_time': self.addon.getSettingInt('minimum_resume_time'),
            'watched_threshold': self.addon.getSettingInt('watched_threshold'),
            
            # Continue Watching
            'show_resume_dialog': self.addon.getSettingBool('show_resume_dialog'),
            'hide_watched': self.addon.getSettingBool('hide_watched'),
            'sort_by': self.addon.getSettingInt('sort_by'),
            'max_items_display': self.addon.getSettingInt('max_items_display'),
            
            # Cache
            'cache_days': self.addon.getSettingInt('cache_days'),
            'max_items': self.addon.getSettingInt('max_items'),
            'auto_cleanup': self.addon.getSettingBool('auto_cleanup'),
            
            # Advanced
            'enable_notifications': self.addon.getSettingBool('enable_notifications'),
            'debug_logging': self.addon.getSettingBool('debug_logging'),
            'tmdb_api_key': self.addon.getSettingString('tmdb_api_key'),
        }
        self.log("Settings loaded/reloaded")
    
    def reload(self):
        """Force reload settings from disk"""
        old_cache = self._cache.copy()
        self._load_settings()
        
        # Check what changed and notify callbacks
        changed = {}
        for key, value in self._cache.items():
            if old_cache.get(key) != value:
                changed[key] = {'old': old_cache.get(key), 'new': value}
        
        if changed:
            self.log(f"Settings changed: {changed}")
            self._notify_callbacks(changed)
    
    def get(self, key, default=None):
        """Get setting value from cache"""
        return self._cache.get(key, default)
    
    def register_callback(self, callback):
        """Register callback for setting changes"""
        if callback not in self._callbacks:
            self._callbacks.append(callback)
    
    def unregister_callback(self, callback):
        """Unregister callback"""
        if callback in self._callbacks:
            self._callbacks.remove(callback)
    
    def _notify_callbacks(self, changed):
        """Notify all registered callbacks of changes"""
        for callback in self._callbacks:
            try:
                callback(changed)
            except Exception as e:
                self.log(f"Error in settings callback: {e}", xbmc.LOGERROR)
    
    def log(self, msg, level=xbmc.LOGDEBUG):
        """Log with addon prefix"""
        if self._cache.get('debug_logging', False) or level >= xbmc.LOGINFO:
            xbmc.log(f"[UPT Settings] {msg}", level)


class SettingsMonitor(xbmc.Monitor):
    """Monitor for settings changes"""
    
    def __init__(self):
        super().__init__()
        self.settings = Settings()
        self.log("Settings monitor started")
    
    def onSettingsChanged(self):
        """Called when addon settings are changed"""
        self.log("Settings changed - reloading")
        self.settings.reload()
    
    def log(self, msg, level=xbmc.LOGDEBUG):
        """Log with addon prefix"""
        xbmc.log(f"[UPT SettingsMonitor] {msg}", level)
