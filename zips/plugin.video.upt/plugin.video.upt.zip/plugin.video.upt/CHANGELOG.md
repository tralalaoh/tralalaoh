# CHANGELOG

## [2.0.2] - 2026-01-03

### 🔧 Critical Bug Fixes

#### Fixed: Empty Notification Bug
**Problem:** The `Player.OnPlay` notification often fires with empty metadata when using plugin-based addons. This resulted in:
- `file_path` being empty
- Fallback to `unknown_<timestamp>` URLs
- Resume failing because URLs didn't match

**Solution:** Separated URL capture from metadata capture:
1. **Metadata** comes from notification (title, season, episode, art)
2. **Plugin URL** comes from InfoLabels during playback
3. Both are combined in `extract_metadata()`

**Files Changed:**
- `resources/lib/player_monitor.py` - Complete rewrite of plugin URL capture

#### Improved: Plugin URL Capture Strategy

**New priority order in `extract_metadata()`:**

```python
# Method A: Player.Filenameandpath (BEST)
xbmc.getInfoLabel('Player.Filenameandpath')
→ Returns: plugin://plugin.video.tmdb.turkish/?action=play&tmdb_id=298629...

# Method B: ListItem.FolderPath
xbmc.getInfoLabel('ListItem.FolderPath')

# Method C: ListItem.Path
xbmc.getInfoLabel('ListItem.Path')

# Method D: getPlayingFile()
self.getPlayingFile()
```

**Key insight:** InfoLabels remain populated even after `setResolvedUrl()` is called. The original plugin URL is still accessible!

### 📦 PrePlayCache Simplification

**Before:**
```python
def store(self, url, metadata):
    self.cache[url] = metadata

def get(self, url):
    # Complex URL matching logic
    # Partial matches
    # Latest fallback
```

**After:**
```python
def store(self, metadata):
    timestamp = int(time.time())
    self.cache[timestamp] = metadata

def get_latest(self):
    latest_key = max(self.cache.keys())
    return self.cache[latest_key]['metadata']
```

**Rationale:** We don't know the plugin URL when the notification fires, so don't try to use it as a key. Just store metadata and retrieve the latest entry (which will be from the current playback).

### 🗄️ Database Schema (Unchanged)

Still using `plugin_url` as the unique identifier (UNIQUE constraint):
```sql
CREATE TABLE tracked_items (
    plugin_url TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    season INTEGER,
    episode INTEGER,
    ...
)
```

This is correct! Plugin URLs are stable and perfect for tracking.

### 🎯 Architecture Changes

**Notification Monitor** (`UPTNotificationMonitor`)
- **Role:** Capture metadata ONLY
- **Trigger:** `Player.OnPlay` notification
- **Captures:** title, show name, season, episode, art
- **Stores:** In PrePlayCache (no URL needed)

**Player Monitor** (`UPTPlayerMonitor`)
- **Role:** Capture plugin URL + combine with metadata
- **Trigger:** `onAVStarted()` callback
- **Captures:** Plugin URL from InfoLabels
- **Retrieves:** Metadata from PrePlayCache
- **Stores:** Complete item in database

### 📝 Code Quality Improvements

1. **Better error handling:**
   - Try/except around each InfoLabel method
   - Graceful fallback if plugin URL not found
   - Skip tracking for non-plugin content

2. **Enhanced logging:**
   - Log all 4 plugin URL capture attempts
   - Show which method succeeded
   - Clear success/failure indicators

3. **Validation:**
   - Must start with `plugin://`
   - Must have a title
   - Must meet minimum duration

### 🧪 Testing Notes

**Test Case 1: First Playback**
```
User plays: Halef S01E01
Expected: Item tracked with plugin URL
Result: ✅ PASS
```

**Test Case 2: Resume**
```
User selects from Continue Watching
Expected: Resume dialog appears
Result: ✅ PASS (previously ❌ FAIL)
```

**Test Case 3: Stream URL Playback**
```
User plays direct stream (non-plugin)
Expected: Gracefully skip tracking
Result: ✅ PASS
```

### 🐛 Known Issues

None! The plugin URL capture is now rock-solid.

### 📊 Performance Impact

- **Minimal:** Only added InfoLabel lookups (4 string retrievals)
- **Cache:** In-memory dictionary with automatic cleanup
- **Database:** Same as before, using indexed plugin_url

### 🔮 Future Improvements

1. **Add export functionality** - Currently stubbed in `default.py`
2. **Add import functionality** - Restore progress from backup
3. **Deduplication** - Handle same content from different addons
4. **TMDB matching** - Use tmdb_id if available in URL params

### 📚 Technical Details

**Why InfoLabels Work:**

When a plugin-based addon resolves a URL:
```python
# 1. User clicks item
plugin_url = "plugin://addon/?action=play&id=123"

# 2. Addon code runs
def play_video():
    stream_url = scrape_stream()
    li = xbmcgui.ListItem()
    xbmcplugin.setResolvedUrl(handle, True, li)
    # ↑ This CHANGES the playing file

# 3. But Kodi remembers!
Player.Filenameandpath = "plugin://addon/?action=play&id=123"  # Original!
Player.PlayingFile = "https://cdn.example.com/stream.m3u8"      # Resolved!
```

So we get BOTH:
- Original plugin URL (for tracking)
- Resolved stream URL (for playback)

Perfect! 🎉

---

## [1.0.0] - 2026-01-03

### Initial Release

- Automatic playback tracking
- Continue Watching menu
- Resume functionality (broken with plugins)
- SQLite database backend
- Settings with hot-reload
- Notification system

## [2.0.3] - 2026-01-03

### 🖼️ Poster Enhancement

#### Added: TMDB Poster Fetching

**Problem:** Plugin notifications don't include poster art (Art: {})

**Solution:** Three-tier poster strategy:
1. **Try cached art from notification** (instant, but often empty)
2. **Try InfoLabels during playback** (ListItem.Art)
3. **Fetch from TMDB API** (parse tmdb_id from plugin URL)

**New Module:** `resources/lib/tmdb_helper.py`
- Extracts TMDB ID from plugin URLs
- Fetches poster from TMDB API
- Returns high-quality poster URLs

**Example:**
```
Plugin URL: plugin://plugin.video.tmdb.turkish/?tmdb_id=298629...
↓
Parse: tmdb_id=298629
↓
Fetch: https://api.themoviedb.org/3/tv/298629
↓
Poster: https://image.tmdb.org/t/p/w500/abc123.jpg
```

**Files Changed:**
- Added: `resources/lib/tmdb_helper.py` (new module)
- Modified: `resources/lib/player_monitor.py` (integrated TMDB fetcher)

### 🔍 How It Works

```python
# Step 1: Try cached/InfoLabels
poster = cached_metadata.get('art', {}).get('poster', '')

# Step 2: If empty, parse TMDB ID and fetch
if not poster:
    poster = TMDBPosterFetcher.get_poster_for_url(plugin_url, mediatype)
```

**Benefit:** Always get high-quality posters, even when addons don't provide them!

## [2.0.4] - 2026-01-03

### 🎯 BRILLIANT IMPROVEMENT: JSON-RPC Poster Fetching

**Big thanks to user suggestion!** Instead of calling TMDB API, we now use Kodi's built-in JSON-RPC to query the plugin URL directly!

#### What Changed

**OLD (v2.0.3):**
- Parse TMDB ID from URL
- Call external TMDB API
- Fetch poster from internet

**NEW (v2.0.4):**
- Query plugin URL via `Files.GetFileDetails`
- Get poster that Kodi already has
- No external API needed!

#### Advantages

✅ **Faster** - No network call to TMDB  
✅ **Offline** - Works without internet  
✅ **Universal** - Works with ANY addon (not just TMDB-based)  
✅ **Exact** - Gets the exact poster the addon provides  
✅ **Simple** - Just one JSON-RPC call  

#### How It Works

```python
# Query the plugin URL directly via Kodi JSON-RPC
query = {
    "method": "Files.GetFileDetails",
    "params": {
        "file": "plugin://plugin.video.tmdb.turkish/?action=play&tmdb_id=298629&...",
        "properties": ["art", "thumbnail", "fanart"]
    }
}

response = xbmc.executeJSONRPC(json.dumps(query))
data = json.loads(response)

# Extract poster
poster = data['result']['filedetails']['art']['poster']
```

**Result:** We get the poster directly from Kodi's cache of what the addon provided!

#### Files Changed

- **Removed:** `resources/lib/tmdb_helper.py` (no longer needed!)
- **Modified:** `resources/lib/player_monitor.py` (now uses JSON-RPC)

#### Performance

- **Zero external network calls**
- **Works offline**
- **Instant response**
- **Universal compatibility**

This is the PERFECT solution! 🎉
