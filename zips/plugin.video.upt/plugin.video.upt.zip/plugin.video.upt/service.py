import xbmc
import xbmcaddon
import time
from resources.lib.player_monitor import UPTPlayerMonitor, UPTNotificationMonitor, PrePlayCache
from resources.lib.settings import SettingsMonitor
from resources.lib.database import Database


class UPTService(xbmc.Monitor):
    """Background service for UPT"""
    
    def __init__(self):
        super().__init__()
        self.addon = xbmcaddon.Addon()
        self.player_monitor = None
        self.notification_monitor = None
        self.settings_monitor = None
        self.db = None
        self.preplay_cache = None
        
        self.log("UPT Service initializing...", xbmc.LOGINFO)
        self.start()
    
    def start(self):
        """Start all monitors"""
        try:
            # Initialize database
            self.db = Database()
            
            # Create shared pre-play cache
            self.preplay_cache = PrePlayCache()
            self.log("Pre-play cache created", xbmc.LOGINFO)
            
            # Start notification monitor (captures metadata BEFORE playback)
            self.notification_monitor = UPTNotificationMonitor(self.preplay_cache)
            self.log("Notification monitor created - listening for Player.OnPlay", xbmc.LOGINFO)
            
            # Start settings monitor (for instant settings application)
            self.settings_monitor = SettingsMonitor()
            
            # Start player monitor (uses cached metadata + captures plugin URL)
            self.player_monitor = UPTPlayerMonitor(self.preplay_cache)
            
            self.log("UPT Service started successfully", xbmc.LOGINFO)
            self.log("=== MONITORING SYSTEM ACTIVE ===", xbmc.LOGINFO)
            self.log("  1. Notification Monitor: Capturing metadata from Player.OnPlay", xbmc.LOGINFO)
            self.log("  2. Player Monitor: Capturing plugin URL + tracking progress", xbmc.LOGINFO)
            
        except Exception as e:
            self.log(f"Error starting service: {e}", xbmc.LOGERROR)
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
    
    def run(self):
        """Main service loop"""
        # Periodic cleanup
        last_cleanup = 0
        last_heartbeat = 0
        cleanup_interval = 3600  # 1 hour
        heartbeat_interval = 300  # 5 minutes
        
        self.log("Service run loop started", xbmc.LOGINFO)
        
        while not self.abortRequested():
            current_time = time.time()
            
            # Heartbeat log every 5 minutes to confirm service is alive
            if current_time - last_heartbeat > heartbeat_interval:
                cache_size = len(self.preplay_cache.cache) if self.preplay_cache else 0
                self.log(f"Service heartbeat - Monitors: Active, Cache: {cache_size} items", xbmc.LOGINFO)
                last_heartbeat = current_time
            
            # Check if cleanup needed
            if current_time - last_cleanup > cleanup_interval:
                try:
                    deleted = self.db.cleanup_old_items()
                    if deleted > 0:
                        self.log(f"Auto-cleanup: removed {deleted} items", xbmc.LOGINFO)
                    last_cleanup = current_time
                except Exception as e:
                    self.log(f"Error during cleanup: {e}", xbmc.LOGERROR)
            
            # Sleep for 10 seconds
            if self.waitForAbort(10):
                break
        
        # Cleanup on exit
        self.cleanup()
    
    def cleanup(self):
        """Cleanup on service stop"""
        try:
            self.log("UPT Service stopping...", xbmc.LOGINFO)
            
            if self.player_monitor:
                self.player_monitor.cleanup()
            
            if self.preplay_cache:
                self.preplay_cache.clear()
            
            if self.db:
                self.db.close()
            
            self.log("UPT Service stopped", xbmc.LOGINFO)
            
        except Exception as e:
            self.log(f"Error during cleanup: {e}", xbmc.LOGERROR)
    
    def log(self, msg, level=xbmc.LOGDEBUG):
        """Log with service prefix"""
        xbmc.log(f"[UPT Service] {msg}", level)


if __name__ == '__main__':
    service = UPTService()
    service.run()
