# UPT Installation & Testing Guide

## 📦 Installation

### Method 1: Manual Installation (Recommended for Testing)

1. **Locate your Kodi addons directory:**
   - **Windows:** `%APPDATA%\Kodi\addons\`
   - **Linux:** `~/.kodi/addons/`
   - **Android:** `/sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons/`

2. **Copy the addon:**
   ```bash
   # Copy the entire plugin.video.upt folder to your addons directory
   cp -r plugin.video.upt /path/to/kodi/addons/
   ```

3. **Restart Kodi:**
   - Completely close and reopen Kodi
   - Or use: Settings → System → Restart Kodi

4. **Verify installation:**
   - Go to: Add-ons → My add-ons → Video add-ons
   - You should see "Universal Progress Tracker"
   - Enable it if not already enabled

5. **Check service status:**
   - Open Kodi log file
   - Look for: `[UPT Service] UPT Service started successfully`
   - You should see: `[UPT Service] === MONITORING SYSTEM ACTIVE ===`

### Method 2: ZIP Installation

1. **Create a ZIP file:**
   ```bash
   cd /path/to/parent/directory
   zip -r plugin.video.upt-2.0.2.zip plugin.video.upt/
   ```

2. **Install from ZIP in Kodi:**
   - Settings → Add-ons → Install from zip file
   - Select the ZIP file
   - Wait for "Add-on installed" notification

## 🧪 Testing Guide

### Test 1: First Playback (Tracking)

**Goal:** Verify UPT captures plugin URL and metadata

**Steps:**
1. Enable debug logging:
   - UPT Settings → Advanced → Enable debug logging → ON

2. Play an episode from your Turkish addon:
   - Browse to any series
   - Click on Episode 1

3. Watch for ~30 seconds, then stop

4. Check the log file for:
   ```
   [UPT Notification] Player.OnPlay notification received!
   [UPT Notification] === PRE-PLAY METADATA CAPTURED ===
   [UPT Notification]   Title: Episode 1
   [UPT Notification]   Show: Halef
   [UPT Notification]   Season: 1, Episode: 1
   
   [UPT PlayerMonitor] onAVStarted callback fired!
   [UPT PlayerMonitor] ✓ Got plugin URL from Player.Filenameandpath
   [UPT PlayerMonitor] === PLUGIN URL CAPTURED: plugin://plugin.video.tmdb.turkish/... ===
   [UPT PlayerMonitor] ✓ Using cached metadata from notification
   [UPT PlayerMonitor] ✓ NOW TRACKING: Halef
   ```

**Expected Result:** ✅ Item appears in database with plugin URL as key

**Troubleshooting:**
- If you see `REJECT: No valid plugin URL found`
  → Check which InfoLabel has the plugin URL
  → Post logs for analysis

### Test 2: Continue Watching Menu

**Goal:** Verify tracked items appear correctly

**Steps:**
1. Open UPT addon:
   - Add-ons → Video add-ons → Universal Progress Tracker
   - Select "Continue Watching"

2. Verify the item appears:
   - Should show: "Halef - S01E01 - Episode 1"
   - Should show progress: "00:30 / 2:21:04 (0%)"
   - Should show poster (if available)

**Expected Result:** ✅ Item displayed with correct metadata and progress

### Test 3: Resume Playback (THE BIG ONE!)

**Goal:** Verify Stremio-style resume works

**Steps:**
1. From Continue Watching menu, click on the tracked item

2. **Check log immediately:**
   ```
   [UPT Addon] === RESUME PLAYBACK ===
   [UPT Addon] Title: Halef
   [UPT Addon] Plugin URL: plugin://plugin.video.tmdb.turkish/?action=play&tmdb_id=298629...
   [UPT Addon] Resume from: 30s
   [UPT Addon] Playing plugin URL: plugin://plugin.video.tmdb.turkish/...
   [UPT Addon] ✓ Playback started
   ```

3. **Expected behavior:**
   - If auto_resume is OFF: Kodi shows resume dialog
   - If auto_resume is ON: Starts from saved position automatically

4. **Verify it's working:**
   - Video should start from where you left off (30 seconds in)
   - NOT from the beginning!

**Expected Result:** ✅ Resume dialog appears OR auto-resumes from correct position

**This is the CRITICAL test that was failing before!**

### Test 4: Progress Updates

**Goal:** Verify progress saves periodically

**Steps:**
1. Resume the video
2. Watch for 2 minutes
3. Check log every 15 seconds (default tracking precision):
   ```
   [UPT PlayerMonitor] Progress saved: 45s
   [UPT PlayerMonitor] Progress saved: 60s
   [UPT PlayerMonitor] Progress saved: 75s
   ```

4. Stop playback
5. Check Continue Watching again
   - Progress should be updated

**Expected Result:** ✅ Progress updates every 15 seconds

### Test 5: Non-Plugin Content

**Goal:** Verify UPT doesn't break regular files

**Steps:**
1. Play a local video file (not from a plugin)
2. Check log:
   ```
   [UPT PlayerMonitor] REJECT: No valid plugin URL found
   [UPT PlayerMonitor] This is likely not a plugin-based video - skipping
   ```

**Expected Result:** ✅ UPT gracefully skips, no errors

## 🐛 Troubleshooting

### Issue: "No valid plugin URL found"

**Check:**
```
[UPT PlayerMonitor] Player.Filenameandpath: 'Empty'
[UPT PlayerMonitor] ListItem.FolderPath: 'Empty'
[UPT PlayerMonitor] ListItem.Path: 'Empty'
[UPT PlayerMonitor] getPlayingFile(): 'https://cdn3.turboviplay.com/...'
```

**Solution:** Your addon might be using a different method. Check which InfoLabel contains the plugin URL:
```python
# Temporary debug code
xbmc.log(f"TEST - Player.Filenameandpath: {xbmc.getInfoLabel('Player.Filenameandpath')}")
xbmc.log(f"TEST - Player.Filename: {xbmc.getInfoLabel('Player.Filename')}")
xbmc.log(f"TEST - Player.Folderpath: {xbmc.getInfoLabel('Player.Folderpath')}")
```

### Issue: Resume Dialog Doesn't Appear

**Check:**
1. Is the item in the database?
   ```bash
   sqlite3 ~/.kodi/userdata/addon_data/plugin.video.upt/upt.db
   SELECT * FROM tracked_items;
   ```

2. Does the plugin_url match?
   - Compare the URL in database with what's being played
   - Should be identical!

3. Are resume properties set?
   ```
   [UPT Addon] Manual resume - setting ResumeTime/TotalTime
   ```

### Issue: Service Not Starting

**Check:**
```bash
# Look for service startup
grep "UPT Service" ~/.kodi/temp/kodi.log

# Should see:
[UPT Service] UPT Service initializing...
[UPT Service] === MONITORING SYSTEM ACTIVE ===
```

**Solution:** Check for Python errors in the log

## 📊 Debug Checklist

Before reporting issues, collect this info:

1. **Kodi version:**
   ```
   Settings → System → System information
   ```

2. **UPT version:**
   ```
   Add-ons → My add-ons → Video add-ons → Universal Progress Tracker
   ```

3. **Log excerpt:**
   ```bash
   # Get last 200 lines with UPT in them
   grep "UPT" ~/.kodi/temp/kodi.log | tail -200
   ```

4. **Database contents:**
   ```bash
   sqlite3 ~/.kodi/userdata/addon_data/plugin.video.upt/upt.db \
     "SELECT plugin_url, title, current_time, total_time FROM tracked_items LIMIT 5;"
   ```

5. **Test addon used:**
   - Name and version
   - Plugin ID (e.g., plugin.video.tmdb.turkish)

## ✅ Success Indicators

You'll know UPT is working perfectly when:

1. ✅ Log shows: `✓ Got plugin URL from Player.Filenameandpath`
2. ✅ Log shows: `✓ NOW TRACKING: <title>`
3. ✅ Items appear in Continue Watching
4. ✅ Resume dialog appears when clicking items
5. ✅ Video resumes from correct position
6. ✅ Progress updates every 15 seconds
7. ✅ No errors in Kodi log

## 🎉 If Everything Works

Congratulations! You now have Stremio-style resume functionality in Kodi!

**Next steps:**
- Customize settings (tracking precision, auto-resume, etc.)
- Try with different addons
- Enjoy seamless content tracking!

## 📝 Notes

- First playback always starts from beginning (no resume data yet)
- Progress saves every 15 seconds by default (configurable)
- Items auto-hide when watched >90% (configurable)
- Database auto-cleans old items after 60 days (configurable)

---

**Need help?** Post your debug logs and the steps you followed!
