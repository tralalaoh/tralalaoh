import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import parse_qsl, urlencode
from resources.lib.database import Database
from resources.lib.settings import Settings


class UPTAddon:
    """Main addon handler"""
    
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.addon_handle = int(sys.argv[1])
        self.base_url = sys.argv[0]
        self.db = Database()
        self.settings = Settings()
        
        # Parse parameters
        self.params = dict(parse_qsl(sys.argv[2][1:]))
        self.action = self.params.get('action', 'main_menu')
    
    def run(self):
        """Route to appropriate action"""
        try:
            if self.action == 'main_menu':
                self.show_main_menu()
            elif self.action == 'continue_watching':
                self.show_continue_watching()
            elif self.action == 'play_resume':
                self.play_with_resume()
            elif self.action == 'remove_item':
                self.remove_item()
            elif self.action == 'clear_cache':
                self.clear_cache()
            elif self.action == 'export_data':
                self.export_data()
            else:
                self.show_main_menu()
        except Exception as e:
            self.log(f"Error in action '{self.action}': {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('UPT Error', str(e), xbmcgui.NOTIFICATION_ERROR)
    
    def show_main_menu(self):
        """Show main addon menu"""
        # Continue Watching
        li = xbmcgui.ListItem('Continue Watching')
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        url = self.build_url({'action': 'continue_watching'})
        xbmcplugin.addDirectoryItem(self.addon_handle, url, li, True)
        
        # Statistics
        stats = self.db.get_stats()
        li = xbmcgui.ListItem(f'Statistics ({stats["in_progress"]} in progress)')
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': f'Total tracked: {stats["total"]}\nIn progress: {stats["in_progress"]}'})
        xbmcplugin.addDirectoryItem(self.addon_handle, '', li, False)
        
        # Clear Cache
        li = xbmcgui.ListItem('Clear All Cache')
        li.setArt({'icon': 'DefaultAddonService.png'})
        url = self.build_url({'action': 'clear_cache'})
        xbmcplugin.addDirectoryItem(self.addon_handle, url, li, False)
        
        xbmcplugin.endOfDirectory(self.addon_handle)
    
    def show_continue_watching(self):
        """Show continue watching menu with resume"""
        items = self.db.get_continue_watching_items()
        
        if not items:
            # Empty list
            li = xbmcgui.ListItem('No items to continue watching')
            li.setArt({'icon': 'DefaultVideo.png'})
            xbmcplugin.addDirectoryItem(self.addon_handle, '', li, False)
        else:
            for item in items:
                # Build display title
                if item['mediatype'] == 'episode' and item['season'] and item['episode']:
                    # Just show: "Show Name - S01E01" (don't add episode title - redundant)
                    display_title = f"{item['title']} - S{item['season']:02d}E{item['episode']:02d}"
                else:
                    display_title = item['title']
                
                # Create list item
                li = xbmcgui.ListItem(display_title)
                
                # Set poster art
                if item['poster']:
                    li.setArt({'poster': item['poster'], 'thumb': item['poster']})
                
                # Calculate progress
                if item['total_time'] > 0:
                    watch_percentage = (item['current_time'] / item['total_time']) * 100
                else:
                    watch_percentage = 0
                
                # Set video info
                info = {
                    'title': display_title,
                    'mediatype': item['mediatype'],
                    'playcount': 0,  # Mark as unwatched (in progress)
                }
                
                if item['mediatype'] == 'episode':
                    info['season'] = item['season']
                    info['episode'] = item['episode']
                
                li.setInfo('video', info)
                
                # Don't set ResumeTime/TotalTime here - it would trigger Kodi's dialog
                # We'll show our own custom dialog in play_with_resume()
                
                # Set progress for display - this shows the progress bar under poster!
                li.setProperty('PercentPlayed', str(int(watch_percentage)))
                
                # Also set as overlay for better visibility
                if watch_percentage > 0:
                    li.setProperty('TotalTime', str(item['total_time']))
                    li.setProperty('ResumeTime', str(item['current_time']))
                    # Set overlay to show it's resumable (but won't trigger dialog)
                    li.setProperty('IsPlayable', 'true')
                
                # Add progress to label for list view
                progress_str = self.format_time(item['current_time'])
                total_str = self.format_time(item['total_time'])
                li.setLabel2(f"{progress_str} / {total_str} ({int(watch_percentage)}%)")
                
                # Create playable URL
                url = self.build_url({
                    'action': 'play_resume',
                    'id': item['id']
                })
                
                # Build show page URL (for TV shows)
                show_page_url = None
                if item['mediatype'] == 'episode' and item['plugin_url']:
                    # Extract base plugin URL without season/episode params
                    # For Turkish addon: plugin://plugin.video.tmdb.turkish/?action=episodes&tmdb_id=298629
                    import re
                    from urllib.parse import urlparse, parse_qs, urlencode
                    
                    try:
                        parsed = urlparse(item['plugin_url'])
                        params = parse_qs(parsed.query)
                        
                        if 'tmdb_id' in params:
                            # Rebuild URL for show page (episodes list)
                            show_params = {
                                'action': 'episodes',
                                'tmdb_id': params['tmdb_id'][0]
                            }
                            show_page_url = f"{parsed.scheme}://{parsed.netloc}/{parsed.path}?{urlencode(show_params)}"
                    except:
                        pass
                
                # Professional context menu (only UPT-specific actions)
                commands = []
                
                # Kodi automatically adds:
                # - "Resume from XX:XX" 
                # - "Play from beginning"
                # So we only add UPT-specific actions here!
                
                # Navigation (if TV show)
                if show_page_url:
                    commands.append(
                        ('Open Show Page', f'Container.Update({show_page_url})')
                    )
                
                # Management actions
                commands.append(
                    ('Remove from Continue Watching', f'RunPlugin({self.build_url({"action": "remove_item", "id": item["id"]})})')
                )
                
                li.addContextMenuItems(commands)
                
                xbmcplugin.addDirectoryItem(
                    self.addon_handle,
                    url,
                    li,
                    False
                )
        
        # Set view type
        xbmcplugin.setContent(self.addon_handle, 'movies')
        xbmcplugin.endOfDirectory(self.addon_handle)
    
    def play_with_resume(self):
        """Play item with resume capability - supports auto-resume and manual modes"""
        try:
            item_id = int(self.params.get('id', 0))
            mode = self.params.get('mode', 'default')  # 'default', 'fresh', 'ask'
            
            # Get item from database
            item = self.db.cursor.execute(
                'SELECT * FROM tracked_items WHERE id = ?',
                (item_id,)
            ).fetchone()
            
            if not item:
                xbmcgui.Dialog().notification('UPT', 'Item not found', xbmcgui.NOTIFICATION_ERROR)
                return
            
            item = dict(item)
            
            self.log(f"=== RESUME PLAYBACK ===", xbmc.LOGINFO)
            self.log(f"Title: {item['title']}", xbmc.LOGINFO)
            self.log(f"Plugin URL: {item['plugin_url'][:80]}...", xbmc.LOGINFO)
            self.log(f"Resume from: {item['current_time']}s", xbmc.LOGINFO)
            self.log(f"Mode: {mode}", xbmc.LOGINFO)
            
            # Determine behavior
            show_resume_dialog = self.settings.get('show_resume_dialog', False)
            
            if mode == 'fresh':
                # Context menu: Play from beginning
                self.log("Mode: Play from beginning (context menu)", xbmc.LOGINFO)
                self.play_fresh(item)
                
            elif mode == 'ask' or show_resume_dialog:
                # User wants dialog, or setting enabled
                self.log("Mode: Show resume dialog", xbmc.LOGINFO)
                self.show_resume_dialog(item)
                
            else:
                # Default: Auto-resume
                self.log("Mode: Auto-resume (default)", xbmc.LOGINFO)
                self.auto_resume(item)
            
        except Exception as e:
            self.log(f"Error playing item: {e}", xbmc.LOGERROR)
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('UPT', f'Playback error: {e}', xbmcgui.NOTIFICATION_ERROR)
    
    def auto_resume(self, item):
        """Auto-resume playback without dialog"""
        self.log(f"Auto-resuming from {item['current_time']}s", xbmc.LOGINFO)
        
        # Play the plugin URL
        xbmc.executebuiltin(f'PlayMedia({item["plugin_url"]})')
        
        # Wait for playback to start, then seek
        player = xbmc.Player()
        for i in range(20):  # Wait up to 10 seconds
            if player.isPlayingVideo():
                xbmc.sleep(1000)  # Wait 1 second for stream to stabilize
                try:
                    player.seekTime(item['current_time'])
                    self.log(f"✓ Auto-resumed to {item['current_time']}s", xbmc.LOGINFO)
                except Exception as e:
                    self.log(f"Error seeking: {e}", xbmc.LOGERROR)
                break
            xbmc.sleep(500)
        
        self.log("✓ Playback initiated", xbmc.LOGINFO)
    
    def play_fresh(self, item):
        """Play from beginning without dialog"""
        self.log("Playing from beginning (no resume)", xbmc.LOGINFO)
        
        # Just play the plugin URL without seeking
        xbmc.executebuiltin(f'PlayMedia({item["plugin_url"]})')
        
        self.log("✓ Playback started from beginning", xbmc.LOGINFO)
    
    def show_resume_dialog(self, item):
        """Show resume dialog and handle user choice"""
        resume_time = item['current_time']
        total_time = item['total_time']
        
        # Calculate percentage
        if total_time > 0:
            percent = int((resume_time / total_time) * 100)
        else:
            percent = 0
        
        # Format time for display
        resume_str = self.format_time(resume_time)
        
        # Create dialog with options
        dialog = xbmcgui.Dialog()
        choice = dialog.contextmenu([
            f'Resume from {resume_str} ({percent}%)',
            'Start from beginning'
        ])
        
        if choice == 0:
            # Resume
            self.log(f"User chose to resume from {resume_time}s", xbmc.LOGINFO)
            
            # Play the plugin URL
            xbmc.executebuiltin(f'PlayMedia({item["plugin_url"]})')
            
            # Wait for playback to start, then seek
            player = xbmc.Player()
            for i in range(20):  # Wait up to 10 seconds
                if player.isPlayingVideo():
                    xbmc.sleep(1000)  # Wait 1 second for stream to stabilize
                    try:
                        player.seekTime(resume_time)
                        self.log(f"✓ Resumed to {resume_time}s", xbmc.LOGINFO)
                    except Exception as e:
                        self.log(f"Error seeking: {e}", xbmc.LOGERROR)
                    break
                xbmc.sleep(500)
                    
        elif choice == 1:
            # Start from beginning
            self.log("User chose to start from beginning", xbmc.LOGINFO)
            xbmc.executebuiltin(f'PlayMedia({item["plugin_url"]})')
        else:
            # User cancelled
            self.log("User cancelled playback", xbmc.LOGINFO)
            return
        
        self.log("✓ Playback initiated", xbmc.LOGINFO)
    
    def remove_item(self):
        """Remove item from continue watching"""
        try:
            item_id = int(self.params.get('id', 0))
            
            if self.db.remove_item(item_id):
                xbmc.executebuiltin('Container.Refresh')
                if self.settings.get('enable_notifications', True):
                    xbmcgui.Dialog().notification('UPT', 'Item removed', xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            self.log(f"Error removing item: {e}", xbmc.LOGERROR)
    
    def clear_cache(self):
        """Clear all cached data"""
        if xbmcgui.Dialog().yesno('Clear All Cache', 'This will remove all tracked items.', 'This cannot be undone!'):
            if self.db.clear_all():
                xbmcgui.Dialog().notification('UPT', 'Cache cleared', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification('UPT', 'Error clearing cache', xbmcgui.NOTIFICATION_ERROR)
    
    def export_data(self):
        """Export tracking data"""
        # TODO: Implement data export
        xbmcgui.Dialog().notification('UPT', 'Export feature coming soon', xbmcgui.NOTIFICATION_INFO)
    
    def build_url(self, query):
        """Build addon URL"""
        return f'{self.base_url}?{urlencode(query)}'
    
    def format_time(self, seconds):
        """Format seconds to HH:MM:SS or MM:SS"""
        if seconds <= 0:
            return "00:00"
        
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        else:
            return f"{minutes:02d}:{secs:02d}"
    
    def log(self, msg, level=xbmc.LOGDEBUG):
        """Log with addon prefix"""
        if self.settings.get('debug_logging', False) or level >= xbmc.LOGINFO:
            xbmc.log(f"[UPT Addon] {msg}", level)


if __name__ == '__main__':
    addon = UPTAddon()
    addon.run()
