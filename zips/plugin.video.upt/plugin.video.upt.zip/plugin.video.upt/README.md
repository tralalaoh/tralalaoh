# Universal Progress Tracker (UPT) - v2.0.2
## Improved Plugin URL Capture System

### 🎯 Key Improvements

This version fixes the critical "empty notification" bug that prevented proper resume functionality.

### 🔧 What Changed

#### **1. Plugin URL Capture (CRITICAL FIX)**

**OLD METHOD (Broken):**
```python
# Relied on notification data which was often empty
file_path = notification_data.get('item', {}).get('file', '')
# Result: "unknown_1767456127" - useless for resume!
```

**NEW METHOD (Fixed):**
```python
# Priority A: Player.Filenameandpath (most reliable)
filepath = xbmc.getInfoLabel('Player.Filenameandpath')

# Priority B: ListItem.FolderPath (fallback)
folderpath = xbmc.getInfoLabel('ListItem.FolderPath')

# Priority C: ListItem.Path
path = xbmc.getInfoLabel('ListItem.Path')

# Priority D: getPlayingFile() if it's a plugin URL
playing_file = self.getPlayingFile()
```

**Result:** Correctly captures `plugin://plugin.video.tmdb.turkish/?action=play&tmdb_id=298629&season=1&episode=1`

#### **2. Simplified PrePlayCache**

**OLD:** Tried to store URL as key (which we didn't have)
**NEW:** Just stores metadata with timestamp, retrieves latest entry

```python
def store(self, metadata):
    """Store metadata with timestamp as key"""
    timestamp = int(time.time())
    self.cache[timestamp] = {
        'metadata': metadata,
        'timestamp': time.time()
    }

def get_latest(self):
    """Get the most recently added metadata"""
    latest_key = max(self.cache.keys())
    return self.cache[latest_key]['metadata']
```

#### **3. Two-Stage Data Capture**

**Stage 1: Notification (Player.OnPlay)**
- Captures: title, show name, season, episode, art
- Stores in: PrePlayCache
- Timing: BEFORE setResolvedUrl()

**Stage 2: Player Monitor (onAVStarted)**
- Captures: plugin URL from InfoLabels
- Retrieves: metadata from cache
- Combines: both into complete item_data
- Stores in: Database with plugin URL as primary key

### 📊 How It Works Now

```
User clicks Episode 1 of "Halef"
         ↓
[Player.OnPlay Notification]
  ✓ Captures: title="Episode 1", show="Halef", S01E01
  ✓ Stores in cache
         ↓
[Turkish Addon Resolves Stream]
  → Calls setResolvedUrl()
  → Notification data would be cleared here (but we already cached it!)
         ↓
[onAVStarted Callback]
  ✓ Gets plugin URL: "plugin://plugin.video.tmdb.turkish/?action=play&tmdb_id=298629&season=1&episode=1"
  ✓ Gets cached metadata: "Halef - S01E01"
  ✓ Combines both
         ↓
[Database Storage]
  PRIMARY KEY: plugin://plugin.video.tmdb.turkish/?action=play&tmdb_id=298629&season=1&episode=1
  Title: Halef
  Season: 1, Episode: 1
  Current Time: 0
         ↓
[User Resumes from Continue Watching]
  ✓ UPT plays: plugin://plugin.video.tmdb.turkish/?action=play&tmdb_id=298629&season=1&episode=1
  ✓ Database lookup: MATCH FOUND!
  ✓ Sets ResumeTime property
  ✓ Kodi shows resume dialog
  ✓ User clicks "Resume"
  ✓ WORKS PERFECTLY! 🎉
```

### 🐛 Bug Fixed: The "Unknown URL" Problem

**Before:**
```
[UPT Notification] Using file path: unknown_1767456127
[UPT PlayerMonitor] Playing file: https://cdn3.turboviplay.com/data1/...
[UPT PlayerMonitor] Using latest cache entry (no URL match)
❌ Can't resume - URLs don't match!
```

**After:**
```
[UPT Notification] Metadata cached: Halef S01E01
[UPT PlayerMonitor] Plugin URL: plugin://plugin.video.tmdb.turkish/?action=play&tmdb_id=298629&season=1&episode=1
[UPT PlayerMonitor] Using latest cache entry for metadata
✓ Database stores with plugin URL as key
✓ Resume works perfectly!
```

### 🚀 Installation

1. Copy `plugin.video.upt` folder to your Kodi addons directory
2. Restart Kodi
3. Enable UPT in Add-ons → Video add-ons
4. The service will start automatically

### 📁 File Structure

```
plugin.video.upt/
├── addon.xml                 # Addon metadata
├── default.py               # Main addon entry point
├── service.py               # Background service
├── icon.png                 # Addon icon
├── fanart.jpg              # Addon fanart
└── resources/
    ├── __init__.py
    ├── settings.xml         # Addon settings
    ├── language/
    │   └── resource.language.en_gb/
    │       └── strings.po   # English strings
    └── lib/
        ├── __init__.py
        ├── player_monitor.py    # ⭐ IMPROVED: Plugin URL capture
        ├── database.py          # SQLite tracking database
        └── settings.py          # Settings management
```

### 🔍 Debug Logging

Enable debug logging in settings to see detailed logs:

```
Settings → Advanced → Enable debug logging
```

This will show:
- Plugin URL capture attempts (all 4 methods)
- Metadata cache hits/misses
- Database operations
- Resume operations

### 💡 Tips

1. **Plugin URLs are stable** - They never change for the same episode
2. **Stream URLs change** - CDN URLs are different each time
3. **Always use plugin URL** as the primary key for tracking
4. **Metadata from notifications** - Get title, season, episode from Player.OnPlay
5. **Plugin URL from InfoLabels** - Get from Player.Filenameandpath during playback

### 🎬 Tested With

- ✅ Turkish TMDB Addon (plugin.video.tmdb.turkish)
- ✅ Works with any plugin-based addon
- ✅ Handles episodes and movies
- ✅ Resume dialog works perfectly
- ✅ Auto-resume option available

### 📝 Version History

**v2.0.2 (2026-01-03)**
- Fixed: Plugin URL capture using InfoLabels instead of empty notifications
- Fixed: Simplified PrePlayCache to use timestamps instead of URLs
- Fixed: Resume now works perfectly with plugin-based addons
- Improved: Better error handling and debug logging

**v1.0.0 (2026-01-03)**
- Initial release
