"""Premium source selection dialog for Little Tigre."""

import re
import xbmcgui
from urllib.parse import unquote_plus
from resources.lib.logger import log, log_debug


class SourceSelectDialog(xbmcgui.WindowXMLDialog):
    """
    Premium stream selection dialog.

    Item properties set per stream:
      cached_status  — "instant" | "cached" | "uncached"  (drives accent bar color)
      resolution     — "2160p" | "1080p" | "720p" | "480p" | "SD"
      title_clean    — release name stripped of tags/emoji
      meta_line      — "Provider  ·  Source  ·  Codec  ·  Audio"
      detail_line    — "Lang  ·  HDR  ·  [Debrid]" or "S:N"
      size_text      — "15.24 GB" or ""
      speed_text     — "INSTANT" | "FAST" | "OK" | "SLOW"
      icon           — path to status icon
      url            — playback URL

    Window properties:
      item.title      — content title
      item.year_rating — "2024  |  8.5 / 10"
      item.plot       — synopsis
      item.poster     — poster URL
      item.fanart     — fanart URL
      stream_count    — "23 streams"
    """

    def __init__(self, xml_file, addon_path, item_information=None, sources=None):
        super(SourceSelectDialog, self).__init__()
        self.item_information = item_information or {}
        self.sources = sources or []
        self.selected_url = None
        self.display_list = None
        log(f"SourceSelectDialog: {len(self.sources)} streams")

    def onInit(self):
        try:
            self.display_list = self.getControl(1000)
            self._set_item_information()
            self._populate_sources()
            if self.display_list.size() > 0:
                self.setFocusId(1000)
        except Exception as e:
            import traceback
            log(f"onInit error: {e}\n{traceback.format_exc()}")

    def onAction(self, action):
        if action in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU, 10):
            self.close()

    def onClick(self, control_id):
        if control_id == 1000:
            try:
                item = self.display_list.getSelectedItem()
                self.selected_url = item.getProperty("url")
                log(f"Selected: {self.selected_url[:80]}")
                self.close()
            except Exception as e:
                log(f"onClick error: {e}")
        elif control_id == 2999:
            self.close()

    def doModal(self):
        super(SourceSelectDialog, self).doModal()
        return self.selected_url

    # ─────────────────────────────────────────────────────────────────────────
    # RIGHT PANEL — item information
    # ─────────────────────────────────────────────────────────────────────────

    def _set_item_information(self):
        info = self.item_information

        # Title
        title = info.get('title', 'Unknown')
        if info.get('type') == 'episode':
            season = info.get('season', '')
            episode = info.get('episode', '')
            showtitle = info.get('showtitle', title)
            if season and episode:
                title = f"{showtitle}  S{str(season).zfill(2)}E{str(episode).zfill(2)}"
            else:
                title = showtitle
        self.setProperty("item.title", title)

        # Year + Rating combined
        year = str(info.get('year', '')).strip()
        rating_raw = info.get('rating', '')
        rating = ''
        if rating_raw:
            try:
                rating = f"{float(rating_raw):.1f}"
            except (ValueError, TypeError):
                rating = str(rating_raw).strip()

        if year and rating:
            self.setProperty("item.year_rating", f"{year}   |   {rating} / 10")
        elif year:
            self.setProperty("item.year_rating", year)
        elif rating:
            self.setProperty("item.year_rating", f"{rating} / 10")
        else:
            self.setProperty("item.year_rating", "")

        # Plot
        plot = info.get('plot', '')
        if plot:
            self.setProperty("item.plot", unquote_plus(plot))

        # Artwork
        poster = unquote_plus(info.get('poster', ''))
        fanart = unquote_plus(info.get('fanart', ''))
        thumb  = unquote_plus(info.get('thumbnail', info.get('thumb', '')))

        self.setProperty("item.poster", poster or thumb or fanart)
        if fanart:
            self.setProperty("item.fanart", fanart)

    # ─────────────────────────────────────────────────────────────────────────
    # LEFT PANEL — stream list
    # ─────────────────────────────────────────────────────────────────────────

    def _populate_sources(self):
        log(f"Populating {len(self.sources)} sources")
        self.display_list.reset()

        try:
            from resources.lib.stream_scorer import StreamScorer
            sorted_sources = StreamScorer().sort_streams(self.sources, sort_by='resolution')
        except Exception as e:
            log(f"Sort failed ({e}), using fallback")
            sorted_sources = sorted(
                self.sources,
                key=lambda s: (0 if s.get('cached', False) else 1, -s.get('confidence_score', 0))
            )

        self.setProperty("stream_count", f"{len(sorted_sources)} streams")

        added = 0
        for idx, source in enumerate(sorted_sources):
            try:
                url   = source.get('url', '')
                title = source.get('title', 'Unknown')

                cached_status = self._cached_status(source)
                resolution    = self._resolution(title)
                title_clean   = self._clean_title(title)
                meta_line     = self._meta_line(source, title)
                detail_line   = self._detail_line(source, title)
                size_text     = self._size_text(source)
                speed_text    = self._speed_text(source)
                icon          = self._icon_path(source)

                item = xbmcgui.ListItem(label=title_clean)
                item.setProperty("url",          url)
                item.setProperty("cached_status", cached_status)
                item.setProperty("resolution",    resolution)
                item.setProperty("title_clean",   title_clean)
                item.setProperty("meta_line",     meta_line)
                item.setProperty("detail_line",   detail_line)
                item.setProperty("size_text",     size_text)
                item.setProperty("speed_text",    speed_text)
                item.setProperty("icon",          icon)

                self.display_list.addItem(item)
                added += 1
                log_debug(f"[{cached_status:8s}] [{resolution:5s}] {title_clean[:60]}")

            except Exception as e:
                import traceback
                log(f"Error at source {idx}: {e}\n{traceback.format_exc()}")
                continue

        log(f"Added {added}/{len(self.sources)} items")

    # ─────────────────────────────────────────────────────────────────────────
    # Per-stream property builders
    # ─────────────────────────────────────────────────────────────────────────

    def _cached_status(self, source):
        """Return 'instant', 'cached', or 'uncached' — drives left accent bar color."""
        if not source.get('cached', False):
            return 'uncached'
        return 'instant' if source.get('playback_speed') == 'instant' else 'cached'

    def _resolution(self, title):
        t = title.lower()
        if '2160p' in t or '4k' in t or 'uhd' in t:
            return '2160p'
        if '1080p' in t or 'fhd' in t:
            return '1080p'
        if '720p' in t:
            return '720p'
        if '480p' in t:
            return '480p'
        return 'SD'

    def _meta_line(self, source, title):
        """Provider  ·  Source  ·  Codec  ·  Audio"""
        parts = [source.get('addon', 'Unknown')]
        t = title.lower()

        # Source type
        if 'remux' in t or 'bdremux' in t:
            parts.append('REMUX')
        elif 'bluray' in t or 'blu-ray' in t or 'brrip' in t:
            parts.append('BluRay')
        elif 'web-dl' in t or 'webdl' in t:
            parts.append('WEB-DL')
        elif 'webrip' in t or 'web-rip' in t:
            parts.append('WEBRip')
        elif 'hdtv' in t:
            parts.append('HDTV')

        # Video codec
        if 'hevc' in t or 'x265' in t or 'h265' in t or 'h.265' in t:
            parts.append('HEVC')
        elif 'x264' in t or 'h264' in t or 'h.264' in t:
            parts.append('H.264')
        elif 'av1' in t:
            parts.append('AV1')

        # Audio
        if 'atmos' in t:
            parts.append('Atmos')
        elif 'truehd' in t:
            parts.append('TrueHD')
        elif 'dts-hd ma' in t or 'dtshd ma' in t:
            parts.append('DTS-HD MA')
        elif 'dts-hd' in t or 'dtshd' in t:
            parts.append('DTS-HD')
        elif 'dts:x' in t or 'dtsx' in t:
            parts.append('DTS:X')
        elif 'dts' in t:
            parts.append('DTS')
        elif 'dd+' in t or 'ddp' in t or 'eac3' in t:
            parts.append('DD+')
        elif 'dd5.1' in t or 'dd 5.1' in t:
            parts.append('DD5.1')
        elif 'aac' in t:
            parts.append('AAC')

        return '  \u00b7  '.join(parts)  # ·

    def _detail_line(self, source, title):
        """Lang  ·  HDR  ·  [Debrid tag] or S:N"""
        parts = []
        t = title.lower()

        # Language
        if 'multi' in t:
            parts.append('Multi')
        elif 'english' in t or ' eng' in t or '.eng.' in t:
            parts.append('EN')

        # HDR
        hdr = []
        if 'dolby vision' in t or '.dv.' in t or ' dv ' in t:
            hdr.append('DV')
        if 'hdr10+' in t:
            hdr.append('HDR10+')
        elif 'hdr10' in t:
            hdr.append('HDR10')
        elif 'hdr' in t:
            hdr.append('HDR')
        if hdr:
            parts.append('/'.join(hdr))

        # Debrid / cached status
        cached = source.get('cached', False)
        debrid = self._debrid_tag(source)
        if cached and debrid:
            parts.append(f'[{debrid} CACHED]')
        elif cached:
            parts.append('[CACHED]')
        else:
            seeders = source.get('seeders', 0)
            parts.append(f'S:{seeders}' if seeders > 0 else 'TORRENT')

        return '  \u00b7  '.join(parts)  # ·

    def _size_text(self, source):
        size = source.get('size_gb', 0)
        if size >= 1:
            return f'{size:.2f} GB'
        if size > 0:
            return f'{size * 1024:.0f} MB'
        return ''

    def _speed_text(self, source):
        return {'instant': 'INSTANT', 'fast': 'FAST', 'medium': 'OK', 'slow': 'SLOW'}.get(
            source.get('playback_speed', 'medium'), 'OK'
        )

    def _icon_path(self, source):
        base = 'special://home/addons/plugin.video.littletigre/resources/media/icons/'
        if not source.get('cached', False):
            return base + 'uncached.png'
        if source.get('playback_speed') == 'instant':
            return base + 'instant.png'
        return base + 'cached.png'

    def _debrid_tag(self, source):
        """Return short debrid tag like 'RD', 'TB', etc., or None."""
        svc = source.get('debrid_service', '')
        tag_map = {'realdebrid': 'RD', 'torbox': 'TB', 'premiumize': 'PM', 'alldebrid': 'AD'}
        if svc in tag_map:
            return tag_map[svc]

        url   = source.get('url', '').lower()
        title = source.get('title', '').lower()
        for check, tag in [
            ('real-debrid.com', 'RD'), ('download.real-debrid.com', 'RD'),
            ('torbox.app', 'TB'), ('tb-cdn.st', 'TB'),
            ('premiumize.me', 'PM'), ('alldebrid.com', 'AD'),
        ]:
            if check in url:
                return tag
        for check, tag in [
            ('[rd', 'RD'), ('real-debrid', 'RD'),
            ('[tb', 'TB'), ('torbox', 'TB'),
            ('[pm', 'PM'), ('premiumize', 'PM'),
            ('[ad', 'AD'), ('alldebrid', 'AD'),
        ]:
            if check in title:
                return tag
        return None

    def _clean_title(self, title):
        """Strip emoji, debrid tags, size, seeders from release name."""
        # Remove unicode emoji
        emoji_re = re.compile(
            "["
            "\U0001F600-\U0001F64F"
            "\U0001F300-\U0001F5FF"
            "\U0001F680-\U0001F6FF"
            "\U0001F1E0-\U0001F1FF"
            "\U00002600-\U000027BF"
            "\U0001F900-\U0001F9FF"
            "\U00002702-\U000027B0"
            "\U000024C2-\U0001F251"
            "\U0000231A-\U0000231B"
            "\U000025AA-\U000025FE"
            "\U00002B50\U00002B55"
            "]+",
            flags=re.UNICODE
        )
        s = emoji_re.sub('', title)
        s = s.replace('\u25a1', '')  # strip stray box char □
        s = re.sub(r'\[(RD|TB|PM|AD|MF|ST|TR)[^\]]*\]', '', s, flags=re.IGNORECASE)
        s = re.sub(r'\[S:\s*\d+\]', '', s)
        s = re.sub(r'\d+\.?\d*\s*(GB|MB)', '', s, flags=re.IGNORECASE)
        return ' '.join(s.split()).strip()
