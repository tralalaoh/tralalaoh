"""Beautiful source selection dialog for Little Tigre - CLEAN 3-LINE FORMAT."""

import xbmcgui
from urllib.parse import unquote_plus
from resources.lib.logger import log, log_debug


class SourceSelectDialog(xbmcgui.WindowXMLDialog):
    """
    Beautiful source selection dialog with CLEAN 3-LINE FORMAT.

    Line 1: [DEBRID] EMOJI Title                                    Resolution
    Line 2: Provider | Status                                       Quality | Audio
    Line 3: Size | Lang | Subs                                      Type | Speed
    """

    def __init__(self, xml_file, addon_path, item_information=None, sources=None):
        """Initialize dialog."""
        super(SourceSelectDialog, self).__init__()
        self.item_information = item_information or {}
        self.sources = sources or []
        self.selected_url = None
        self.display_list = None

        log(f"🎨 Source Select initialized with {len(self.sources)} streams")

    def onInit(self):
        """Called when dialog is initialized."""
        try:
            # Get list control
            self.display_list = self.getControl(1000)

            # Set item information for right panel
            self._set_item_information()

            # Populate source list
            self._populate_sources()

            # Set focus to list (after items are added!)
            if self.display_list.size() > 0:
                self.setFocusId(1000)
                log(f"✓ Focus set to list with {self.display_list.size()} items")
            else:
                log("⚠️ No sources added to list!")

        except Exception as e:
            log(f"Error initializing source select: {e}")
            import traceback
            log(f"Traceback: {traceback.format_exc()}")

    def onAction(self, action):
        """Handle user actions."""
        # Close actions
        if action in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU, 10):
            self.close()

    def onClick(self, control_id):
        """Handle clicks on controls."""
        if control_id == 1000:  # List item clicked
            try:
                selected_item = self.display_list.getSelectedItem()
                self.selected_url = selected_item.getProperty("url")
                log(f"✓ User selected URL: {self.selected_url[:50]}...")
                self.close()
            except Exception as e:
                log(f"Error handling click: {e}")
        elif control_id == 2999:  # Close button
            self.close()

    def doModal(self):
        """Show dialog and return selected URL."""
        super(SourceSelectDialog, self).doModal()
        return self.selected_url

    def _set_item_information(self):
        """Set movie/show information for the right panel."""
        info = self.item_information

        # Title
        title = info.get('title', 'Unknown')
        if info.get('type') == 'episode':
            season = info.get('season', '')
            episode = info.get('episode', '')
            showtitle = info.get('showtitle', title)
            if season and episode:
                title = f"{showtitle} S{season}E{episode}"

        self.setProperty("item.title", title)

        # Year
        year = info.get('year', '')
        if year:
            self.setProperty("item.year", str(year))

        # Plot - DECODE URL encoding!
        plot = info.get('plot', '')
        if plot:
            plot_decoded = unquote_plus(plot)
            self.setProperty("item.plot", plot_decoded)
            log_debug(f"Plot decoded: {plot_decoded[:100]}")

        # Rating
        rating = info.get('rating', '')
        if rating:
            try:
                rating_float = float(rating)
                self.setProperty("item.rating", f"{rating_float:.1f}")
            except (ValueError, TypeError):
                self.setProperty("item.rating", str(rating))
        else:
            self.setProperty("item.rating", "")

        # Artwork - DECODE URL encoding!
        poster = info.get('poster', '')
        fanart = info.get('fanart', '')
        thumb = info.get('thumbnail', info.get('thumb', ''))

        # Decode URLs
        if poster:
            poster = unquote_plus(poster)
        if fanart:
            fanart = unquote_plus(fanart)
        if thumb:
            thumb = unquote_plus(thumb)

        # Priority: poster > thumb > fanart
        if poster:
            self.setProperty("item.poster", poster)
        elif thumb:
            self.setProperty("item.poster", thumb)
        elif fanart:
            self.setProperty("item.poster", fanart)

        if fanart:
            self.setProperty("item.fanart", fanart)

    def _populate_sources(self):
        """Populate with NEW 3-LINE FORMAT."""
        log(f"📋 Starting to populate {len(self.sources)} sources")
        self.display_list.reset()

        # Import stream_scorer for sorting
        try:
            from resources.lib.stream_scorer import StreamScorer
            scorer = StreamScorer()
            # Use resolution-first sorting (NO AIO PRIORITY!)
            sorted_sources = scorer.sort_streams(self.sources, sort_by='resolution')
            log(f"✓ Sorted by resolution (5-level hierarchical)")
        except Exception as e:
            log(f"⚠️ StreamScorer not available: {e}, using fallback sort")
            sorted_sources = sorted(self.sources, key=lambda s: (
                0 if s.get('cached', False) else 1,
                -s.get('confidence_score', 0)
            ))

        items_added = 0
        for idx, source in enumerate(sorted_sources):
            try:
                # Get data
                url = source.get('url', '')
                title = source.get('title', 'Unknown')
                provider = source.get('addon', 'Unknown')
                cached = source.get('cached', False)

                # Get debrid service
                debrid_service = self._detect_debrid_service(source)
                debrid_tag = self._get_debrid_tag(debrid_service, cached)

                # Get icon path (instead of emoji)
                icon_path = self._get_icon_path(source)

                # Get resolution
                resolution = self._extract_resolution(title)

                # Clean title (remove tags)
                clean_title = self._clean_title(title)

                # === LINE 1: [DEBRID] Title (NO EMOJI) → Resolution ===
                line1_left = f"{debrid_tag} {clean_title}"
                line1_right = resolution

                # === LINE 2: Provider | Status → Quality | Audio ===
                status = "CACHED" if cached else "UNCACHED"
                line2_left = f"{provider} | {status}"

                # Get quality and audio
                quality_audio = self._get_quality_audio(title)
                line2_right = quality_audio

                # === LINE 3: Size | Lang | Subs → Type | Speed ===
                size_lang_subs = self._get_size_lang_subs(source, title)
                line3_left = size_lang_subs

                # Get type and speed
                stream_type = source.get('stream_type', self._detect_stream_type(url))
                speed = source.get('playback_speed', 'medium').upper()
                line3_right = f"{stream_type} | {speed}"

                # Create list item
                list_item = xbmcgui.ListItem(label=clean_title)
                list_item.setProperty("url", url)

                # Set icon path
                list_item.setProperty("icon", icon_path)

                # Set NEW 3-line properties
                list_item.setProperty("line1_left", line1_left)
                list_item.setProperty("line1_right", line1_right)
                list_item.setProperty("line2_left", line2_left)
                list_item.setProperty("line2_right", line2_right)
                list_item.setProperty("line3_left", line3_left)
                list_item.setProperty("line3_right", line3_right)

                # Add to list
                self.display_list.addItem(list_item)
                items_added += 1

                log_debug(f"✓ Added: {provider} - {clean_title[:40]}")

            except Exception as e:
                log(f"⚠️ Error adding source {idx}: {e}")
                import traceback
                log(traceback.format_exc())
                continue

        log(f"✓ Successfully added {items_added}/{len(self.sources)} sources")

    def _get_debrid_tag(self, debrid_service, cached):
        """Get [DEBRID] tag."""
        if not cached:
            return "[--]"

        tag_map = {
            'realdebrid': '[RD]',
            'torbox': '[TB]',
            'premiumize': '[PM]',
            'alldebrid': '[AD]',
            'RD': '[RD]',
            'TB': '[TB]',
            'PM': '[PM]',
            'AD': '[AD]',
        }

        return tag_map.get(debrid_service, '[??]')

    def _get_icon_path(self, source):
        """
        Get icon path based on stream status.

        Icons should be placed in: resources/media/icons/
        - instant.png (⚡) - Instant cached streams
        - cached.png (✓) - Regular cached streams
        - uncached.png (⬇) - Uncached torrents
        """
        cached = source.get('cached', False)

        if not cached:
            return 'special://home/addons/plugin.video.littletigre/resources/media/icons/uncached.png'

        speed = source.get('playback_speed', 'medium')

        if speed == 'instant':
            return 'special://home/addons/plugin.video.littletigre/resources/media/icons/instant.png'
        else:
            return 'special://home/addons/plugin.video.littletigre/resources/media/icons/cached.png'

    def _extract_resolution(self, title):
        """Extract resolution from title."""
        title_lower = title.lower()

        if '2160p' in title_lower or '4k' in title_lower:
            return '2160p'
        elif '1080p' in title_lower:
            return '1080p'
        elif '720p' in title_lower:
            return '720p'
        elif '480p' in title_lower:
            return '480p'
        else:
            return 'SD'

    def _clean_title(self, title):
        """
        Clean title from ALL tags, emojis, and encoded characters.

        CRITICAL: Remove ALL emojis and boxes (□)
        """
        import re

        # Remove unicode emojis FIRST
        emoji_pattern = re.compile(
            "["
            u"\U0001F600-\U0001F64F"  # emoticons
            u"\U0001F300-\U0001F5FF"  # symbols & pictographs
            u"\U0001F680-\U0001F6FF"  # transport & map
            u"\U0001F1E0-\U0001F1FF"  # flags
            u"\U00002600-\U000027BF"  # misc symbols
            u"\U0001F900-\U0001F9FF"  # supplemental
            u"\U00002702-\U000027B0"
            u"\U000024C2-\U0001F251"
            u"\U0000231A-\U0000231B"
            u"\U000023E9-\U000023FA"
            u"\U000025AA-\U000025FE"
            u"\U00002B50"
            u"\U00002B55"
            "]+",
            flags=re.UNICODE
        )

        cleaned = emoji_pattern.sub('', title)

        # Remove encoded emoji boxes
        cleaned = cleaned.replace('□', '')
        cleaned = cleaned.replace('â–¡', '')

        # Remove debrid tags
        cleaned = re.sub(r'\[(RD|TB|PM|AD|MF|ST|TR)[^\]]*\]', '', cleaned, flags=re.IGNORECASE)

        # Remove seeders
        cleaned = re.sub(r'\[S:\s*\d+\]', '', cleaned)

        # Remove size
        cleaned = re.sub(r'\d+\.?\d*\s*(GB|MB)', '', cleaned, flags=re.IGNORECASE)

        # Clean whitespace
        cleaned = ' '.join(cleaned.split())

        return cleaned.strip()

    def _get_quality_audio(self, title):
        """Get quality and audio info."""
        title_lower = title.lower()
        parts = []

        # Source type
        if 'remux' in title_lower:
            parts.append('REMUX')
        elif 'bluray' in title_lower or 'blu-ray' in title_lower:
            parts.append('BluRay')
        elif 'web-dl' in title_lower or 'webdl' in title_lower:
            parts.append('WEB-DL')
        elif 'webrip' in title_lower:
            parts.append('WEBRip')
        elif 'hdtv' in title_lower:
            parts.append('HDTV')

        # Audio codec
        if 'atmos' in title_lower:
            parts.append('Atmos')
        elif 'truehd' in title_lower:
            parts.append('TrueHD')
        elif 'dts-hd' in title_lower or 'dtshd' in title_lower:
            parts.append('DTS-HD')
        elif 'dts' in title_lower:
            parts.append('DTS')
        elif 'dd+' in title_lower or 'ddp' in title_lower or 'eac3' in title_lower:
            parts.append('DD+')
        elif 'dd5.1' in title_lower or 'dd 5.1' in title_lower:
            parts.append('DD5.1')
        elif 'aac' in title_lower:
            parts.append('AAC')

        return ' | '.join(parts) if parts else 'N/A'

    def _get_size_lang_subs(self, source, title):
        """Get size, lang, subs info."""
        parts = []

        # Size
        size_gb = source.get('size_gb', 0)
        if size_gb > 0:
            parts.append(f"SIZE: {size_gb:.1f}GB")

        # Language
        title_lower = title.lower()
        if 'multi' in title_lower:
            parts.append("LANG: Multi")
        elif 'eng' in title_lower or 'english' in title_lower:
            parts.append("LANG: EN")

        # Subs
        if 'sub' in title_lower or 'subtitle' in title_lower:
            parts.append("SUBS: Yes")

        return ' | '.join(parts) if parts else 'N/A'

    def _detect_stream_type(self, url):
        """Detect DIRECT or TORRENT."""
        url_lower = url.lower()

        if any(pattern in url_lower for pattern in ['tb-cdn.st', 'download.real-debrid.com', '/download/', '.mp4', '.mkv']):
            return 'DIRECT'
        elif url.startswith('magnet:'):
            return 'TORRENT'
        else:
            return 'TORRENT'

    def _detect_debrid_service(self, source):
        """Detect debrid service."""
        # Check explicit field
        if 'debrid_service' in source and source['debrid_service']:
            service_map = {
                'realdebrid': 'RD',
                'torbox': 'TB',
                'premiumize': 'PM',
                'alldebrid': 'AD'
            }
            return service_map.get(source['debrid_service'], source['debrid_service'].upper()[:2])

        # Detect from URL
        url = source.get('url', '').lower()
        if 'real-debrid.com' in url or 'download.real-debrid.com' in url:
            return 'RD'
        elif 'torbox.app' in url or 'tb-cdn.st' in url:
            return 'TB'
        elif 'premiumize.me' in url:
            return 'PM'
        elif 'alldebrid.com' in url:
            return 'AD'

        # Detect from title
        title = source.get('title', '').lower()
        if 'real-debrid' in title or '[rd' in title:
            return 'RD'
        elif 'torbox' in title or '[tb' in title:
            return 'TB'
        elif 'premiumize' in title or '[pm' in title:
            return 'PM'
        elif 'alldebrid' in title or '[ad' in title:
            return 'AD'

        return None
