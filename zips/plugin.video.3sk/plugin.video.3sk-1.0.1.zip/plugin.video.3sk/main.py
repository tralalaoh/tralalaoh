import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import time
import json
import os
from datetime import datetime

# IMPORTANT: Import requests with error handling
try:
    import requests
except ImportError as e:
    xbmc.log("ERROR: requests module not found: {}".format(e), xbmc.LOGERROR)
    sys.exit(1)

# IMPORTANT: BeautifulSoup import for Kodi
try:
    from bs4 import BeautifulSoup
except ImportError as e:
    xbmc.log("ERROR: BeautifulSoup4 module not found: {}".format(e), xbmc.LOGERROR)
    sys.exit(1)

# ==============================================================================
# CONFIGURATION
# ==============================================================================

DEV_MODE = False
DEV_URL = "http://0.0.0.0:5000"

# Android TV optimizations with SMART SERVER INDEX CACHE
CACHE_DURATION = 600  # 10 minutes pour l'URL
SERVER_INDEX_CACHE_DURATION = 86400  # 24 heures pour l'index du serveur!
MAX_SERVERS_TO_TEST = 3
ITEMS_PER_PAGE = 24

SITE_CONFIG = {
    "DOMAINS": [
        "https://esheaq.onl",
        "https://x.esheaq.onl",
        "https://3sk.media",
        "https://u.3sk.media"
    ],
    "SELECTORS": {
        "series_container": "article.postEp",
        "series_title": "div.title",
        "series_url": "a",
        "series_img_selector": ".imgBg img",
        "series_img_attr": "data-image",

        "episode_list_container": "#epiList",
        "episode_item": "article.postEp",
        "episode_num": "div.episodeNum span:nth-of-type(2)",
        "episode_link": "a",

        "server_list": "ul.serversList li",
        "server_attr": "data-src"
    }
}

# ==============================================================================
# SMART CACHE WITH SERVER INDEX
# ==============================================================================

class ServerIndexCache:
    """
    Cache intelligent en 2 niveaux:
    
    Niveau 1 (court): URL du stream (10 min)
    Niveau 2 (long): INDEX du serveur qui marche (24h)
    
    Si l'URL expire, on teste d'abord le serveur qui marchait avant!
    """
    def __init__(self, session):
        self.url_cache = {}        # {episode: {"url": "...", "timestamp": ...}}
        self.server_cache = {}     # {episode: {"index": 2, "timestamp": ...}}
        self.session = session
        self.stats = {
            'url_hits': 0,
            'url_misses': 0,
            'server_hits': 0,
            'url_invalidated': 0
        }
    
    def get_url(self, key, validate=True):
        """
        Get cached URL with validation
        """
        if key not in self.url_cache:
            self.stats['url_misses'] += 1
            return None
        
        url, timestamp = self.url_cache[key]
        
        # Check expiration
        if time.time() - timestamp > CACHE_DURATION:
            xbmc.log("URL cache expired for: {}".format(key[:50]), xbmc.LOGDEBUG)
            del self.url_cache[key]
            self.stats['url_misses'] += 1
            return None
        
        # Validate if requested
        if validate:
            if self._quick_validate(url):
                xbmc.log("URL CACHE HIT (validated): {}".format(key[:50]), xbmc.LOGINFO)
                self.stats['url_hits'] += 1
                return url
            else:
                xbmc.log("URL INVALIDATED (dead link): {}".format(key[:50]), xbmc.LOGWARNING)
                del self.url_cache[key]
                self.stats['url_invalidated'] += 1
                return None
        else:
            self.stats['url_hits'] += 1
            return url
    
    def get_server_index(self, key):
        """
        Get cached server index (quel serveur marchait avant)
        Cache beaucoup plus long (24h) car l'index change rarement
        """
        if key not in self.server_cache:
            return None
        
        server_index, timestamp = self.server_cache[key]
        
        # Check expiration (24h)
        if time.time() - timestamp > SERVER_INDEX_CACHE_DURATION:
            xbmc.log("Server index cache expired: {}".format(key[:50]), xbmc.LOGDEBUG)
            del self.server_cache[key]
            return None
        
        xbmc.log("SERVER INDEX CACHE HIT: Episode {} -> Test server {} first!".format(
            key[:50], server_index
        ), xbmc.LOGINFO)
        self.stats['server_hits'] += 1
        return server_index
    
    def set_url(self, key, url):
        """Cache URL"""
        self.url_cache[key] = (url, time.time())
        xbmc.log("CACHED URL: {}".format(key[:50]), xbmc.LOGDEBUG)
    
    def set_server_index(self, key, server_index):
        """Cache server index (trÃ¨s important!)"""
        self.server_cache[key] = (server_index, time.time())
        xbmc.log("CACHED SERVER INDEX: Episode {} -> Server {} works!".format(
            key[:50], server_index
        ), xbmc.LOGINFO)
    
    def _quick_validate(self, url):
        """Quick URL validation (2 seconds max)"""
        try:
            response = self.session.head(url, timeout=2, allow_redirects=True)
            return response.status_code in [200, 206, 301, 302, 303, 307, 308]
        except:
            return False
    
    def clear_old(self):
        """Clear expired entries"""
        now = time.time()
        
        # Clear expired URLs (10 min)
        expired_urls = [k for k, (_, t) in self.url_cache.items() 
                       if now - t > CACHE_DURATION]
        for k in expired_urls:
            del self.url_cache[k]
        
        # Clear expired server indexes (24h)
        expired_servers = [k for k, (_, t) in self.server_cache.items() 
                          if now - t > SERVER_INDEX_CACHE_DURATION]
        for k in expired_servers:
            del self.server_cache[k]
        
        if expired_urls or expired_servers:
            xbmc.log("Cleared {} expired URLs, {} expired server indexes".format(
                len(expired_urls), len(expired_servers)
            ), xbmc.LOGINFO)
    
    def get_stats(self):
        """Get cache statistics"""
        total_url = self.stats['url_hits'] + self.stats['url_misses']
        if total_url > 0:
            url_hit_rate = (self.stats['url_hits'] / total_url) * 100
        else:
            url_hit_rate = 0
        
        return {
            'url_hits': self.stats['url_hits'],
            'url_misses': self.stats['url_misses'],
            'server_hits': self.stats['server_hits'],
            'url_invalidated': self.stats['url_invalidated'],
            'url_hit_rate': url_hit_rate,
            'url_cache_size': len(self.url_cache),
            'server_cache_size': len(self.server_cache)
        }

# ==============================================================================
# USER DATA MANAGER - Favorites & Watch History
# ==============================================================================

class UserDataManager:
    """
    Manages user data:
    - Favorites (bookmarked series)
    - Watch History (track watched episodes and continue watching)
    """
    def __init__(self, addon):
        self.addon = addon
        # Get addon data directory
        self.data_dir = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        
        # Ensure directory exists
        if not xbmcvfs.exists(self.data_dir):
            xbmcvfs.mkdirs(self.data_dir)
        
        self.favorites_file = os.path.join(self.data_dir, 'favorites.json')
        self.history_file = os.path.join(self.data_dir, 'watch_history.json')
        
        xbmc.log("UserDataManager initialized: {}".format(self.data_dir), xbmc.LOGINFO)
    
    # ==================== FAVORITES ====================
    
    def load_favorites(self):
        """Load favorites from storage"""
        try:
            if xbmcvfs.exists(self.favorites_file):
                with open(self.favorites_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('favorites', [])
        except Exception as e:
            xbmc.log("Error loading favorites: {}".format(e), xbmc.LOGERROR)
        return []
    
    def save_favorites(self, favorites):
        """Save favorites to storage"""
        try:
            with open(self.favorites_file, 'w', encoding='utf-8') as f:
                json.dump({'favorites': favorites}, f, ensure_ascii=False, indent=2)
            xbmc.log("Saved {} favorites".format(len(favorites)), xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log("Error saving favorites: {}".format(e), xbmc.LOGERROR)
            return False
    
    def add_favorite(self, series_url, series_title, poster=""):
        """Add series to favorites"""
        favorites = self.load_favorites()
        
        # Check if already in favorites
        if any(f['series_url'] == series_url for f in favorites):
            xbmc.log("Series already in favorites: {}".format(series_title), xbmc.LOGINFO)
            return False
        
        favorites.append({
            'series_url': series_url,
            'series_title': series_title,
            'poster': poster,
            'added_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
        
        self.save_favorites(favorites)
        xbmc.log("Added to favorites: {}".format(series_title), xbmc.LOGINFO)
        return True
    
    def remove_favorite(self, series_url):
        """Remove series from favorites"""
        favorites = self.load_favorites()
        original_count = len(favorites)
        
        favorites = [f for f in favorites if f['series_url'] != series_url]
        
        if len(favorites) < original_count:
            self.save_favorites(favorites)
            xbmc.log("Removed from favorites: {}".format(series_url), xbmc.LOGINFO)
            return True
        return False
    
    def is_favorite(self, series_url):
        """Check if series is in favorites"""
        favorites = self.load_favorites()
        return any(f['series_url'] == series_url for f in favorites)
    
    # ==================== WATCH HISTORY ====================
    
    def load_history(self):
        """Load watch history from storage"""
        try:
            if xbmcvfs.exists(self.history_file):
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('history', {})
        except Exception as e:
            xbmc.log("Error loading history: {}".format(e), xbmc.LOGERROR)
        return {}
    
    def save_history(self, history):
        """Save watch history to storage"""
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump({'history': history}, f, ensure_ascii=False, indent=2)
            xbmc.log("Saved watch history ({} series)".format(len(history)), xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log("Error saving history: {}".format(e), xbmc.LOGERROR)
            return False
    
    def update_watch_progress(self, series_url, series_title, episode_url, episode_num, season=1, total_episodes=0, poster=""):
        """Update watch progress for a series"""
        history = self.load_history()
        
        # Get or create series entry
        if series_url not in history:
            history[series_url] = {
                'series_title': series_title,
                'poster': poster,
                'watched_episodes': [],
                'total_episodes': total_episodes,
                'resume_positions': {}  # Store playback positions
            }
        
        series_data = history[series_url]
        
        # Update latest episode
        series_data['last_watched_url'] = episode_url
        series_data['last_watched_episode'] = episode_num
        series_data['last_watched_season'] = season
        series_data['last_watched_date'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Update total episodes if provided
        if total_episodes > 0:
            series_data['total_episodes'] = total_episodes
        
        # Add to watched episodes list if not already there
        episode_id = "S{}E{}".format(season, episode_num)
        if episode_id not in series_data['watched_episodes']:
            series_data['watched_episodes'].append(episode_id)
        
        # Initialize resume_positions if not exists
        if 'resume_positions' not in series_data:
            series_data['resume_positions'] = {}
        
        self.save_history(history)
        xbmc.log("Updated watch progress: {} - S{}E{}".format(series_title, season, episode_num), xbmc.LOGINFO)
    
    def save_resume_position(self, episode_url, position_seconds, duration_seconds):
        """Save playback position for an episode"""
        history = self.load_history()
        
        # Find which series this episode belongs to
        for series_url, series_data in history.items():
            if series_data.get('last_watched_url') == episode_url:
                if 'resume_positions' not in series_data:
                    series_data['resume_positions'] = {}
                
                # Only save if not near the end (less than 95% watched)
                if position_seconds < (duration_seconds * 0.95):
                    series_data['resume_positions'][episode_url] = {
                        'position': position_seconds,
                        'duration': duration_seconds,
                        'percentage': int((position_seconds / duration_seconds) * 100) if duration_seconds > 0 else 0,
                        'saved_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    }
                    xbmc.log("Saved resume position: {} at {}s ({}%)".format(
                        episode_url[:50], position_seconds, 
                        series_data['resume_positions'][episode_url]['percentage']
                    ), xbmc.LOGINFO)
                else:
                    # Remove resume position if finished
                    if episode_url in series_data['resume_positions']:
                        del series_data['resume_positions'][episode_url]
                        xbmc.log("Removed resume position (finished): {}".format(episode_url[:50]), xbmc.LOGINFO)
                
                self.save_history(history)
                return
    
    def get_resume_position(self, episode_url):
        """Get saved playback position for an episode"""
        history = self.load_history()
        
        for series_url, series_data in history.items():
            resume_positions = series_data.get('resume_positions', {})
            if episode_url in resume_positions:
                return resume_positions[episode_url]
        
        return None
    
    def get_continue_watching(self, limit=10):
        """Get list of series to continue watching (sorted by most recent)"""
        history = self.load_history()
        
        # Convert to list and sort by last watched date
        continue_watching = []
        for series_url, data in history.items():
            if 'last_watched_date' in data:
                continue_watching.append({
                    'series_url': series_url,
                    'series_title': data['series_title'],
                    'poster': data.get('poster', ''),
                    'last_episode': data['last_watched_episode'],
                    'last_season': data['last_watched_season'],
                    'last_watched_url': data['last_watched_url'],
                    'last_watched_date': data['last_watched_date'],
                    'watched_count': len(data.get('watched_episodes', [])),
                    'total_episodes': data.get('total_episodes', 0)
                })
        
        # Sort by most recent first
        continue_watching.sort(key=lambda x: x['last_watched_date'], reverse=True)
        
        return continue_watching[:limit]
    
    def is_episode_watched(self, series_url, season, episode_num):
        """Check if an episode has been watched"""
        history = self.load_history()
        
        if series_url not in history:
            return False
        
        episode_id = "S{}E{}".format(season, episode_num)
        return episode_id in history[series_url].get('watched_episodes', [])
    
    def get_watch_progress(self, series_url):
        """Get watch progress for a series"""
        history = self.load_history()
        return history.get(series_url, None)

# ==============================================================================
# PLAYBACK MONITOR - Track position & handle next episode
# ==============================================================================

class PlaybackMonitor(xbmc.Player):
    """
    Monitor playback to:
    1. Save resume position when user stops
    2. Auto-play next episode when current finishes
    """
    def __init__(self, user_data_manager):
        super(PlaybackMonitor, self).__init__()
        self.user_data = user_data_manager
        self.current_episode_url = None
        self.current_position = 0
        self.total_duration = 0
        self.next_episode_data = None
        xbmc.log("PlaybackMonitor initialized", xbmc.LOGINFO)
    
    def set_episode_info(self, episode_url, next_episode_data=None):
        """Set current episode info for tracking"""
        self.current_episode_url = episode_url
        self.next_episode_data = next_episode_data
        xbmc.log("Set episode info: {}".format(episode_url[:50]), xbmc.LOGINFO)
    
    def onPlayBackStarted(self):
        """Called when playback starts"""
        if self.isPlaying():
            self.total_duration = self.getTotalTime()
            xbmc.log("Playback started - Duration: {}s".format(self.total_duration), xbmc.LOGINFO)
    
    def onPlayBackStopped(self):
        """Called when user stops playback"""
        self._save_position()
        xbmc.log("Playback stopped by user", xbmc.LOGINFO)
    
    def onPlayBackEnded(self):
        """Called when playback finishes naturally"""
        xbmc.log("Playback ended naturally", xbmc.LOGINFO)
        self._save_position()
        
        # Ask to play next episode
        if self.next_episode_data:
            self._prompt_next_episode()
    
    def onPlayBackError(self):
        """Called when playback error occurs"""
        xbmc.log("Playback error occurred", xbmc.LOGERROR)
        self._save_position()
    
    def _save_position(self):
        """Save current playback position"""
        if self.current_episode_url and self.isPlaying():
            try:
                self.current_position = self.getTime()
                self.total_duration = self.getTotalTime()
                
                self.user_data.save_resume_position(
                    self.current_episode_url,
                    self.current_position,
                    self.total_duration
                )
                xbmc.log("Saved position: {}s / {}s".format(
                    self.current_position, self.total_duration
                ), xbmc.LOGINFO)
            except Exception as e:
                xbmc.log("Error saving position: {}".format(e), xbmc.LOGERROR)
    
    def _prompt_next_episode(self):
        """Ask user if they want to play next episode"""
        if not self.next_episode_data:
            return
        
        next_ep = self.next_episode_data
        
        # Show dialog for 10 seconds
        dialog = xbmcgui.Dialog()
        play_next = dialog.yesno(
            'Next Episode',
            'Play next episode?[CR]S{}E{}: {}'.format(
                next_ep['season'],
                next_ep['number'],
                next_ep['title'][:40]
            ),
            nolabel='No',
            yeslabel='Play Next',
            autoclose=10000  # Auto-close after 10 seconds
        )
        
        if play_next:
            xbmc.log("User chose to play next episode", xbmc.LOGINFO)
            # Play the next episode
            xbmc.executebuiltin('PlayMedia({})'.format(next_ep['play_url']))

# Global player monitor instance
player_monitor = None

# ==============================================================================
# UTILITY FUNCTIONS
# ==============================================================================

def unpack_js(packed_code):
    try:
        match = re.search(r"}\('(.*)',(\d+),(\d+),'([^']*)'\.split\('\|'\)", packed_code)
        if not match: return None
        payload, radix, count, symtab = match.groups()
        radix = int(radix)
        symbols = symtab.split('|')
        def lookup(match):
            value = int(match.group(0), radix)
            return symbols[value] if value < len(symbols) and symbols[value] else match.group(0)
        return re.sub(r'\b\w+\b', lookup, payload)
    except: return None

# ==============================================================================
# THE SCRAPER CLASS
# ==============================================================================

class ThreeSkScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://google.com/'
        })

        if DEV_MODE:
            xbmc.log("DEV MODE ACTIVE: Intercepting requests to {}".format(DEV_URL), xbmc.LOGINFO)
            self.base_url = DEV_URL
        else:
            self.base_url = self._find_active_domain()
        
        # Initialize smart cache with server index tracking
        self.cache = ServerIndexCache(self.session)

    def _find_active_domain(self):
        xbmc.log("Checking domains...", xbmc.LOGINFO)
        for domain in SITE_CONFIG["DOMAINS"]:
            try:
                r = self.session.head(domain, timeout=5, allow_redirects=True)
                if r.status_code < 400:
                    return domain
            except: continue
        return SITE_CONFIG["DOMAINS"][0]

    def _request(self, url):
        target_url = url

        if DEV_MODE:
            for domain in SITE_CONFIG["DOMAINS"]:
                if domain in url:
                    target_url = url.replace(domain, DEV_URL)
                    break

            if target_url.startswith("/"):
                target_url = urllib.parse.urljoin(DEV_URL, target_url)

        xbmc.log("Requesting: {}".format(target_url), xbmc.LOGDEBUG)
        try:
            return self.session.get(target_url, timeout=30, allow_redirects=True)
        except Exception as e:
            xbmc.log("Connection Failed: {}".format(e), xbmc.LOGERROR)
            return None

    def _fix_url(self, url):
        if url.startswith("http"): return url
        return urllib.parse.urljoin(self.base_url, url)
    
    def _test_stream_url(self, url):
        """Quick test if URL is accessible"""
        try:
            head_response = self.session.head(url, timeout=3, allow_redirects=True)
            
            if head_response.status_code == 200:
                return True
            elif head_response.status_code in [301, 302, 303, 307, 308]:
                return True
            elif head_response.status_code == 403:
                get_response = self.session.get(url, headers={'Range': 'bytes=0-512'}, timeout=3)
                return get_response.status_code in [200, 206]
            
            return False
        except:
            return False
    
    def _extract_stream_from_html(self, html_content):
        """Extract stream URL using test_vidroba.py patterns"""
        if 'eval(function(p,a,c,k,e,d)' in html_content:
            unpacked = unpack_js(html_content)
            if unpacked:
                html_content = unpacked
        
        patterns = [
            ('JWPlayer file (double quotes)', r'"file"\s*:\s*"([^"]+)"'),
            ('JWPlayer file (single quotes)', r"'file'\s*:\s*'([^']+)'"),
            ('sources array', r'"sources"\s*:\s*\[\s*"([^"]+)"'),
            ('Direct m3u8', r'(https?://[^\s"\'<>]+\.m3u8(?:\?[^\s"\'<>]+)?)'),
            ('Direct mp4', r'(https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]+)?)')
        ]
        
        for name, pattern in patterns:
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                url = match.group(1)
                url = url.replace('\\/', '/').replace('\\u0026', '&').replace('&amp;', '&')
                
                if url.startswith('http') and any(ext in url.lower() for ext in ['.m3u8', '.mp4', '.mkv']):
                    xbmc.log("Extracted via {}: {}".format(name, url[:100]), xbmc.LOGINFO)
                    return url
        
        return None
    
    def _resolve_iframe(self, iframe_url, max_depth=3):
        """Resolve iframe to find stream"""
        if max_depth <= 0:
            return None
            
        xbmc.log("Resolving iframe: {}".format(iframe_url[:80]), xbmc.LOGDEBUG)
        
        try:
            response = self._request(iframe_url)
            if not response:
                return None
            
            html_content = response.text
            
            # OK.RU specific
            if 'ok.ru' in iframe_url or 'ok.ru' in html_content:
                # Method 1: hlsManifestUrl
                hls_match = re.search(r'"hlsManifestUrl"\s*:\s*"([^"]+)"', html_content)
                if hls_match:
                    url = hls_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if url.startswith('http'):
                        return url
                
                # Method 2: Videos array
                videos_match = re.search(r'"videos"\s*:\s*\[([^\]]+)\]', html_content)
                if videos_match:
                    for quality in ['hd', 'sd', 'low']:
                        q_match = re.search(
                            r'"name"\s*:\s*"{}"\s*,\s*"url"\s*:\s*"([^"]+)"'.format(quality),
                            videos_match.group(1)
                        )
                        if q_match:
                            url = q_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                            if url.startswith('http'):
                                return url
                
                # Method 3: Direct okcdn URL
                okcdn_match = re.search(r'"(https://[^"]+okcdn\.ru[^"]+\.m3u8[^"]*)"', html_content)
                if okcdn_match:
                    url = okcdn_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if '&quot;' not in url and url.startswith('http'):
                        return url
            
            # Generic extraction
            stream_url = self._extract_stream_from_html(html_content)
            if stream_url:
                return stream_url
            
            # Nested iframe
            nested = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html_content)
            if nested:
                next_url = nested.group(1)
                if not next_url.startswith('http'):
                    next_url = urllib.parse.urljoin(iframe_url, next_url)
                
                if not next_url.startswith('about:') and not next_url.startswith('javascript:'):
                    return self._resolve_iframe(next_url, max_depth - 1)
            
            return None
            
        except Exception as e:
            xbmc.log("Error resolving iframe: {}".format(e), xbmc.LOGERROR)
            return None

    def get_series(self, page=1):
        """Get series list with pagination"""
        if page == 1:
            url = "{}/e3blk2h43q/".format(self.base_url)
        else:
            url = "{}/e3blk2h43q/page/{}/".format(self.base_url, page)
        
        xbmc.log("Scraping Series page {}: {}".format(page, url), xbmc.LOGINFO)

        response = self._request(url)
        if not response: return []

        soup = BeautifulSoup(response.text, 'html.parser')
        series_list = []
        items = soup.select(SITE_CONFIG["SELECTORS"]["series_container"])
        xbmc.log("Found {} items on page {}".format(len(items), page), xbmc.LOGINFO)

        for article in items:
            try:
                title = article.select_one(SITE_CONFIG["SELECTORS"]["series_title"]).text.strip()
                link = self._fix_url(article.select_one(SITE_CONFIG["SELECTORS"]["series_url"])['href'])
                img_tag = article.select_one(SITE_CONFIG["SELECTORS"]["series_img_selector"])
                poster = img_tag.get(SITE_CONFIG["SELECTORS"]["series_img_attr"]) or img_tag.get('src')

                series_list.append({'title': title, 'url': link, 'poster': poster})
            except: 
                continue

        return series_list

    def get_episodes(self, series_url):
        """
        Scrape episodes from series page or landing page.
        Handles both:
        - Series pages with #epiList (article.postEp)
        - Landing pages with related episodes (article.post)
        """
        xbmc.log("=== get_episodes ===", xbmc.LOGINFO)
        xbmc.log("URL: {}".format(series_url), xbmc.LOGINFO)
        
        response = self._request(series_url)
        if not response: return []

        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Detect page type
        epi_list = soup.select_one('#epiList')
        is_series_page = epi_list is not None
        xbmc.log("Page type: {}".format("SERIES PAGE" if is_series_page else "LANDING PAGE"), xbmc.LOGINFO)
        
        episodes = []
        
        if is_series_page:
            # SERIES PAGE - Use standard extraction
            xbmc.log("Extracting from series page (#epiList)", xbmc.LOGINFO)
            items = epi_list.select('article.postEp')
            xbmc.log("Found {} episodes in #epiList".format(len(items)), xbmc.LOGINFO)
        else:
            # LANDING PAGE - Extract related episodes
            xbmc.log("Extracting from landing page", xbmc.LOGINFO)
            
            # Try different selectors
            items = soup.select('article.postEp')
            if not items:
                items = soup.select('article.post')
            if not items:
                items = soup.select('article')
            
            xbmc.log("Found {} episodes on landing page".format(len(items)), xbmc.LOGINFO)
            
            # If still no items, try extracting from /watch/ links
            if not items:
                xbmc.log("No articles found, extracting from /watch/ links...", xbmc.LOGWARNING)
                watch_links = soup.select('a[href*="/watch/"]')
                xbmc.log("Found {} /watch/ links".format(len(watch_links)), xbmc.LOGINFO)
                
                for link in watch_links:
                    href = link.get('href', '')
                    if not href or '/see/' in href:
                        continue
                    
                    ep_url = self._fix_url(href)
                    text = link.text.strip()
                    
                    # Extract episode number
                    ep_match = re.search(r'(\d+)', text) or re.search(r'(\d+)', href)
                    ep_num = int(ep_match.group(1)) if ep_match else len(episodes) + 1
                    
                    # Extract season if present
                    season_match = re.search(r'(?:موسم|Season)\s*(\d+)', text, re.IGNORECASE)
                    season = int(season_match.group(1)) if season_match else 1
                    
                    episodes.append({
                        'number': ep_num,
                        'url': ep_url,
                        'title': text if text else "Episode {}".format(ep_num),
                        'season': season
                    })
                
                xbmc.log("Extracted {} episodes from /watch/ links".format(len(episodes)), xbmc.LOGINFO)
                return episodes
        
        # Process article items
        for idx, item in enumerate(items):
            try:
                # Get link
                a_tag = item.select_one('a') or item.find('a')
                if not a_tag:
                    continue
                
                ep_url = self._fix_url(a_tag['href'])
                
                # Get title
                title_div = item.select_one('.title')
                title = title_div.text.strip() if title_div else ""
                
                # Extract episode number
                num_tag = item.select_one('.episodeNum')
                if num_tag:
                    num_text = num_tag.text.strip()
                    # Try to extract number from Arabic or English
                    ep_match = re.search(r'(\d+)', num_text)
                    ep_num = int(ep_match.group(1)) if ep_match else (len(items) - idx)
                else:
                    # Try from title or URL
                    ep_match = re.search(r'(?:الحلقة|Episode|حلقة|Ep)\s*(\d+)', title, re.IGNORECASE)
                    if not ep_match:
                        ep_match = re.search(r'(\d+)', title)
                    ep_num = int(ep_match.group(1)) if ep_match else (len(items) - idx)
                
                # Extract season if present
                season_match = re.search(r'(?:موسم|Season|الموسم)\s*(\d+)', title, re.IGNORECASE)
                season = int(season_match.group(1)) if season_match else 1
                
                # Build episode title
                if not title:
                    title = "Episode {}".format(ep_num)
                
                episodes.append({
                    'number': ep_num,
                    'url': ep_url,
                    'title': title,
                    'season': season
                })
                
            except Exception as e:
                xbmc.log("Error parsing episode {}: {}".format(idx, e), xbmc.LOGERROR)
                continue
        
        # Sort by season and episode number
        episodes.sort(key=lambda x: (x.get('season', 1), -x['number']))
        
        xbmc.log("Total episodes extracted: {}".format(len(episodes)), xbmc.LOGINFO)
        
        # If landing page has too many episodes (>30), it might be showing all results
        # Try to filter to same series
        if not is_series_page and len(episodes) > 30:
            xbmc.log("Landing page has {} episodes - might need filtering".format(len(episodes)), xbmc.LOGWARNING)
            # Extract series name from first episode
            if episodes:
                first_title = episodes[0].get('title', '')
                # Try to extract series name (everything before episode number)
                series_name_match = re.match(r'(.+?)(?:الحلقة|Episode|حلقة|Ep)\s*\d+', first_title, re.IGNORECASE)
                if series_name_match:
                    series_name = series_name_match.group(1).strip()
                    xbmc.log("Detected series name: {}".format(series_name), xbmc.LOGINFO)
                    
                    # Filter episodes that match this series
                    filtered = [ep for ep in episodes if series_name in ep.get('title', '')]
                    if len(filtered) < len(episodes):
                        xbmc.log("Filtered to {} episodes matching series name".format(len(filtered)), xbmc.LOGINFO)
                        episodes = filtered
        
        return episodes
    
    def search(self, query):
        """Search for episodes"""
        search_url = "{}/?s={}".format(self.base_url, urllib.parse.quote(query))
        xbmc.log("Searching: {}".format(search_url), xbmc.LOGINFO)
        
        response = self._request(search_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        articles = soup.select('article.post')
        xbmc.log("Found {} search results".format(len(articles)), xbmc.LOGINFO)
        
        results = []
        for article in articles:
            try:
                # Get the episode link
                link = article.find('a')
                if not link:
                    continue
                
                # Get raw href - do NOT encode it here
                # The URL might be in Unicode or already percent-encoded
                # get_url() will handle the encoding when creating the plugin URL
                episode_url_raw = link.get('href', '')
                
                if not episode_url_raw:
                    continue
                
                # Fix relative URLs
                if not episode_url_raw.startswith('http'):
                    episode_url = self._fix_url(episode_url_raw)
                else:
                    episode_url = episode_url_raw
                
                xbmc.log("Raw search result URL: {}".format(repr(episode_url)), xbmc.LOGINFO)
                
                # Get title
                title_div = article.select_one('.title')
                title = title_div.text.strip() if title_div else "Unknown"
                
                # Get episode number if available
                ep_num_div = article.select_one('.episodeNum')
                ep_num_text = ep_num_div.text.strip() if ep_num_div else ""
                
                # Extract numeric episode number
                ep_match = re.search(r'(\d+)', ep_num_text)
                ep_num = int(ep_match.group(1)) if ep_match else 0
                
                # Get image
                img = article.select_one('img')
                poster = ""
                if img:
                    poster = img.get('data-image') or img.get('src') or ""
                
                results.append({
                    'title': title,
                    'episode_url': episode_url,  # Store as-is
                    'episode_number': ep_num,
                    'poster': poster
                })
            except Exception as e:
                xbmc.log("Error parsing search result: {}".format(e), xbmc.LOGERROR)
                import traceback
                xbmc.log("Traceback: {}".format(traceback.format_exc()), xbmc.LOGERROR)
                continue
        
        return results
    
    def get_parent_series_url(self, episode_url):
        """
        Get the parent series URL from an episode page.
        Returns the episode_url itself if it's a landing page with episodes,
        or tries to find an actual series page.
        """
        xbmc.log("=== FINDING PARENT SERIES ===", xbmc.LOGINFO)
        xbmc.log("Episode URL: {}".format(episode_url), xbmc.LOGINFO)
        
        response = self._request(episode_url)
        if not response:
            xbmc.log("Failed to fetch episode page!", xbmc.LOGERROR)
            return None
        
        xbmc.log("Episode page fetched successfully, parsing HTML...", xbmc.LOGINFO)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # STRATEGY 1: Check if this page has a proper episode list (series page)
        epi_list = soup.select_one('#epiList')
        if epi_list and len(epi_list.select('article')) > 0:
            xbmc.log("This page IS a series page with #epiList! Using it directly.", xbmc.LOGINFO)
            return episode_url
        
        # STRATEGY 2: Check if this page has episodes (landing page with related episodes)
        # Landing pages often have article.post or article.postEp with other episodes
        articles = soup.select('article.post') or soup.select('article.postEp')
        if len(articles) > 0:
            xbmc.log("This is a landing page with {} related episodes. Will use it.".format(len(articles)), xbmc.LOGINFO)
            # Return the landing page itself - we'll extract episodes from it
            return episode_url
        
        # STRATEGY 3: Try to find a series link in the page
        base_domain = self.base_url.split('//')[1]
        all_links = soup.select('a[href*="{}"]'.format(base_domain))
        xbmc.log("Found {} total links on episode page".format(len(all_links)), xbmc.LOGINFO)
        
        series_candidates = []
        for link in all_links:
            href = link.get('href', '')
            
            # Filter out non-series links
            if any(pattern in href for pattern in [
                '/watch/', '/see/', '/category/', '/actor/', '/genre/', '/tag/',
                '/page/', '/?s=', '/e3blk2h43q/', '/4hkgj1dtrw/'
            ]):
                continue
            
            # Match pattern like https://x.esheaq.onl/XXXXX/
            if re.match(r'https?://[^/]+/[a-z0-9]+/$', href):
                series_candidates.append(href)
                xbmc.log("Series candidate: {}".format(href), xbmc.LOGINFO)
        
        xbmc.log("Found {} series candidates".format(len(series_candidates)), xbmc.LOGINFO)
        
        if series_candidates:
            series_url = series_candidates[0]
            xbmc.log("Selected parent series URL: {}".format(series_url), xbmc.LOGINFO)
            return series_url
        
        xbmc.log("No series page found, but landing page has episodes - will use landing page", xbmc.LOGWARNING)
        # Return the landing page itself as fallback
        return episode_url

    def get_stream_url(self, episode_url, force_refresh=False):
        """
        SMART SERVER INDEX CACHE:
        1. Check URL cache (validated)
        2. If expired, check SERVER INDEX cache
        3. Test cached server FIRST (huge time saver!)
        4. Fallback to other servers if needed
        """
        cache_key = episode_url
        
        # Step 1: Check URL cache (with validation)
        if not force_refresh:
            cached_url = self.cache.get_url(cache_key, validate=True)
            if cached_url:
                xbmc.log("URL cache hit! Using validated URL", xbmc.LOGINFO)
                return [{'name': 'Cached Server', 'url': cached_url, 'quality': 'Auto'}]
        
        # Step 2: Get all available servers
        response = self._request(episode_url)
        if not response: return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        see_link = soup.find('a', href=re.compile(r'/see/$'))
        if see_link:
            video_page_url = self._fix_url(see_link['href'])
        else:
            video_page_url = episode_url.rstrip('/') + '/see/'
        
        response = self._request(video_page_url)
        if not response: return []

        soup = BeautifulSoup(response.text, 'html.parser')
        servers = soup.select(SITE_CONFIG["SELECTORS"]["server_list"])
        xbmc.log("Found {} server options".format(len(servers)), xbmc.LOGINFO)
        
        # Step 3: Check SERVER INDEX cache (which server worked before)
        cached_server_index = self.cache.get_server_index(cache_key)
        
        verified_servers = []
        
        # SMART: If we know which server worked before, TEST IT FIRST!
        if cached_server_index is not None and cached_server_index < len(servers):
            xbmc.log("Testing CACHED server {} first (worked before!)".format(
                cached_server_index + 1
            ), xbmc.LOGINFO)
            
            server = servers[cached_server_index]
            embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
            
            if embed_url:
                embed_url = self._fix_url(embed_url)
                stream_url = self._resolve_server(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    xbmc.log("SUCCESS! Cached server {} still works!".format(
                        cached_server_index + 1
                    ), xbmc.LOGINFO)
                    
                    quality = self._guess_quality(stream_url)
                    verified_servers.append({
                        'name': "Server {} (Cached)".format(cached_server_index + 1),
                        'url': stream_url,
                        'quality': quality
                    })
                    
                    # Update caches
                    self.cache.set_url(cache_key, stream_url)
                    self.cache.set_server_index(cache_key, cached_server_index)
                    
                    # Return immediately (Android TV optimization)
                    return verified_servers
                else:
                    xbmc.log("Cached server {} now dead, trying others...".format(
                        cached_server_index + 1
                    ), xbmc.LOGWARNING)
        
        # Step 4: Test other servers (normal flow)
        xbmc.log("Testing first {} servers...".format(MAX_SERVERS_TO_TEST), xbmc.LOGINFO)
        
        servers_to_test = servers[:MAX_SERVERS_TO_TEST]
        
        for idx, server in enumerate(servers_to_test):
            # Skip if we already tested cached server
            if idx == cached_server_index:
                continue
            
            embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
            if not embed_url: continue

            embed_url = self._fix_url(embed_url)
            server_name = "Server {}".format(idx + 1)
            
            stream_url = self._resolve_server(embed_url)
            
            if stream_url and self._test_stream_url(stream_url):
                quality = self._guess_quality(stream_url)
                verified_servers.append({
                    'name': server_name,
                    'url': stream_url,
                    'quality': quality
                })
                xbmc.log("SUCCESS: {} verified!".format(server_name), xbmc.LOGINFO)
                
                # Cache URL and SERVER INDEX
                self.cache.set_url(cache_key, stream_url)
                self.cache.set_server_index(cache_key, idx)  # IMPORTANT: Remember which server works!
                
                break  # Stop after finding 1 (Android TV optimization)
        
        # Step 5: Fallback to remaining servers if needed
        if not verified_servers and len(servers) > MAX_SERVERS_TO_TEST:
            xbmc.log("Trying remaining servers...", xbmc.LOGINFO)
            
            for idx, server in enumerate(servers[MAX_SERVERS_TO_TEST:], start=MAX_SERVERS_TO_TEST):
                if idx == cached_server_index:
                    continue
                
                embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
                if not embed_url: continue

                embed_url = self._fix_url(embed_url)
                stream_url = self._resolve_server(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    verified_servers.append({
                        'name': "Server {}".format(idx + 1),
                        'url': stream_url,
                        'quality': self._guess_quality(stream_url)
                    })
                    
                    self.cache.set_url(cache_key, stream_url)
                    self.cache.set_server_index(cache_key, idx)
                    break
        
        # Log stats
        stats = self.cache.get_stats()
        xbmc.log("Cache stats: {} URL hits, {} server index hits, {:.1f}% URL hit rate".format(
            stats['url_hits'], stats['server_hits'], stats['url_hit_rate']
        ), xbmc.LOGINFO)
        
        return verified_servers
    
    def _resolve_server(self, embed_url):
        """Resolve server to stream URL"""
        is_internal = any(d in embed_url for d in SITE_CONFIG["DOMAINS"]) or DEV_URL in embed_url or "emb=true" in embed_url

        if is_internal:
            try:
                r2 = self._request(embed_url)
                if not r2: return None
                
                stream_url = self._extract_stream_from_html(r2.text)
                if stream_url:
                    return stream_url

                nested_iframe = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', r2.text)
                if nested_iframe:
                    iframe_url = nested_iframe.group(1)
                    if not iframe_url.startswith('http'):
                        iframe_url = urllib.parse.urljoin(embed_url, iframe_url)
                    
                    if not iframe_url.startswith('about:') and not iframe_url.startswith('javascript:'):
                        return self._resolve_iframe(iframe_url)
            except:
                return None
        else:
            return self._resolve_iframe(embed_url)
        
        return None
    
    def _guess_quality(self, url):
        """Guess quality from URL"""
        url_lower = url.lower()
        if 'hd' in url_lower or '1080' in url_lower:
            return 'HD'
        elif 'sd' in url_lower or '720' in url_lower:
            return 'SD'
        return 'Auto'

# ==============================================================================
# KODI ADDON LOGIC
# ==============================================================================

_handle = int(sys.argv[1])
_url = sys.argv[0]
addon = xbmcaddon.Addon()

scraper = ThreeSkScraper()
user_data = UserDataManager(addon)

def get_url(**kwargs):
    return '{}?{}'.format(_url, urllib.parse.urlencode(kwargs))

def list_series(page=1):
    """List series with infinite scroll"""
    xbmcplugin.setPluginCategory(_handle, 'Turkish Series - Page {}'.format(page))
    xbmcplugin.setContent(_handle, 'tvshows')
    
    # Add special sections at the top of first page
    if page == 1:
        # Continue Watching section
        continue_watching = user_data.get_continue_watching(limit=5)
        if continue_watching:
            continue_item = xbmcgui.ListItem(label='[COLOR cyan]▶ Continue Watching ({}) ▶[/COLOR]'.format(len(continue_watching)))
            continue_item.setArt({'icon': 'DefaultRecentlyAddedEpisodes.png'})
            continue_url = get_url(action='continue_watching')
            xbmcplugin.addDirectoryItem(_handle, continue_url, continue_item, True)
        
        # Favorites section - ALWAYS SHOW, even if empty
        favorites = user_data.load_favorites()
        if favorites:
            fav_label = '[COLOR yellow]⭐ MY FAVORITES ({}) - CLICK HERE! ⭐[/COLOR]'.format(len(favorites))
        else:
            fav_label = '[COLOR yellow]⭐ MY FAVORITES (Empty) - Add series to see them here! ⭐[/COLOR]'
        
        fav_item = xbmcgui.ListItem(label=fav_label)
        fav_item.setArt({'icon': 'DefaultAddSource.png'})
        fav_url = get_url(action='favorites')
        xbmcplugin.addDirectoryItem(_handle, fav_url, fav_item, True)
        
        # Search option
        search_item = xbmcgui.ListItem(label='[COLOR orange]🔍 Search Episodes[/COLOR]')
        search_item.setArt({'icon': 'DefaultAddonsSearch.png'})
        search_url = get_url(action='search')
        xbmcplugin.addDirectoryItem(_handle, search_url, search_item, True)
    
    series_list = scraper.get_series(page=page)
    
    for series in series_list:
        list_item = xbmcgui.ListItem(label=series['title'])
        list_item.setArt({'poster': series['poster'], 'fanart': series['poster']})
        list_item.setInfo('video', {'title': series['title'], 'mediatype': 'tvshow'})
        
        # Check if in favorites
        is_fav = user_data.is_favorite(series['url'])
        
        # Add context menu for favorites
        context_menu = []
        if is_fav:
            context_menu.append((
                'Remove from Favorites',
                'RunPlugin({})'.format(get_url(action='remove_favorite', series_url=series['url']))
            ))
        else:
            context_menu.append((
                'Add to Favorites',
                'RunPlugin({})'.format(get_url(
                    action='add_favorite',
                    series_url=series['url'],
                    series_title=series['title'],
                    poster=series.get('poster', '')
                ))
            ))
        
        list_item.addContextMenuItems(context_menu)
        
        # Add favorite indicator to title
        display_title = series['title']
        if is_fav:
            display_title = "⭐ {}".format(display_title)
        list_item.setLabel(display_title)
        
        url = get_url(action='episodes', series_url=series['url'], series_title=series['title'], poster=series.get('poster', ''))
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    # Next page
    if len(series_list) >= ITEMS_PER_PAGE - 5:
        next_item = xbmcgui.ListItem(label='[COLOR yellow]>>> Next Page (Page {}) >>>[/COLOR]'.format(page + 1))
        next_item.setArt({'icon': 'DefaultFolder.png'})
        next_url = get_url(action='list', page=page + 1)
        xbmcplugin.addDirectoryItem(_handle, next_url, next_item, True)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def list_episodes(series_url, series_title, poster=""):
    xbmc.log("=== LIST EPISODES ===", xbmc.LOGINFO)
    xbmc.log("Series URL: {}".format(series_url), xbmc.LOGINFO)
    xbmc.log("Series Title: {}".format(series_title), xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, series_title)
    xbmcplugin.setContent(_handle, 'episodes')
    
    # Add "Add to Favorites" button at the top
    is_fav = user_data.is_favorite(series_url)
    if is_fav:
        fav_label = '[COLOR red]★ REMOVE FROM FAVORITES[/COLOR]'
        fav_action = 'remove_favorite'
    else:
        fav_label = '[COLOR yellow]⭐ ADD TO FAVORITES[/COLOR]'
        fav_action = 'add_favorite'
    
    fav_item = xbmcgui.ListItem(label=fav_label)
    fav_item.setArt({'icon': 'DefaultAddSource.png'})
    fav_url = get_url(
        action=fav_action,
        series_url=series_url,
        series_title=series_title,
        poster=poster
    )
    xbmcplugin.addDirectoryItem(_handle, fav_url, fav_item, False)
    
    episodes = scraper.get_episodes(series_url)
    xbmc.log("Found {} episodes".format(len(episodes)), xbmc.LOGINFO)
    
    # Get watch progress for this series
    watch_progress = user_data.get_watch_progress(series_url)
    
    # Build episode list with next episode info
    for idx, episode in enumerate(episodes):
        # Build display title with season info if available
        season = episode.get('season', 1)
        episode_num = episode['number']
        display_title = episode['title']
        
        # Check if episode is watched
        is_watched = user_data.is_episode_watched(series_url, season, episode_num)
        
        # Check if has resume position
        resume_pos = user_data.get_resume_position(episode['url'])
        
        # If title doesn't already contain season info, add it
        if season > 1 and 'Season' not in display_title and 'موسم' not in display_title:
            display_title = "S{} - {}".format(season, display_title)
        
        # Add resume indicator
        if resume_pos:
            percentage = resume_pos.get('percentage', 0)
            display_title = "▶ {}% - {}".format(percentage, display_title)
        # Add watched indicator
        elif is_watched:
            display_title = "✓ {}".format(display_title)
        
        list_item = xbmcgui.ListItem(label=display_title)
        list_item.setInfo('video', {
            'title': display_title,
            'episode': episode_num,
            'season': season,
            'mediatype': 'episode',
            'tvshowtitle': series_title,
            'playcount': 1 if is_watched else 0  # Mark as watched in Kodi
        })
        list_item.setProperty('IsPlayable', 'true')
        
        # Get next episode info for auto-play
        next_episode_url = ""
        next_episode_num = 0
        next_season = season
        next_title = ""
        
        if idx < len(episodes) - 1:
            next_ep = episodes[idx + 1]
            next_episode_url = next_ep['url']
            next_episode_num = next_ep['number']
            next_season = next_ep.get('season', 1)
            next_title = next_ep['title']
        
        # Context menu
        list_item.addContextMenuItems([
            ('Force Refresh Servers', 'RunPlugin({})'.format(
                get_url(action='play', episode_url=episode['url'], force_refresh='1',
                       series_url=series_url, series_title=series_title,
                       episode_num=episode_num, season=season,
                       total_episodes=len(episodes), poster=poster,
                       next_episode_url=next_episode_url, next_episode_num=next_episode_num,
                       next_season=next_season, next_title=next_title)
            ))
        ])
        
        url = get_url(action='play', episode_url=episode['url'],
                     series_url=series_url, series_title=series_title,
                     episode_num=episode_num, season=season,
                     total_episodes=len(episodes), poster=poster,
                     next_episode_url=next_episode_url, next_episode_num=next_episode_num,
                     next_season=next_season, next_title=next_title)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(_handle)
    xbmc.log("list_episodes completed", xbmc.LOGINFO)

def play_video(episode_url, force_refresh=False, series_url="", series_title="", episode_num=0, season=1, total_episodes=0, poster="", next_episode_url="", next_episode_num=0, next_season=1, next_title=""):
    """Smart playback with server index caching, resume, and next episode"""
    global player_monitor
    
    xbmc.log("PLAY_VIDEO: {} (force={})".format(episode_url, force_refresh), xbmc.LOGINFO)
    
    # Initialize player monitor if not exists
    if player_monitor is None:
        player_monitor = PlaybackMonitor(user_data)
    
    # Check for resume position
    resume_pos = user_data.get_resume_position(episode_url)
    start_position = 0
    
    if resume_pos and not force_refresh:
        percentage = resume_pos.get('percentage', 0)
        position = resume_pos.get('position', 0)
        
        # Ask user if they want to resume
        dialog = xbmcgui.Dialog()
        resume = dialog.yesno(
            'Resume Playback',
            'Resume from {}% ({} minutes)?'.format(
                percentage,
                int(position / 60)
            ),
            nolabel='Start from Beginning',
            yeslabel='Resume'
        )
        
        if resume:
            start_position = position
            xbmc.log("Resuming from position: {}s".format(start_position), xbmc.LOGINFO)
        else:
            xbmc.log("Starting from beginning", xbmc.LOGINFO)
    
    # Track watch progress if we have series info
    if series_url and series_title and episode_num:
        user_data.update_watch_progress(
            series_url=series_url,
            series_title=series_title,
            episode_url=episode_url,
            episode_num=episode_num,
            season=season,
            total_episodes=total_episodes,
            poster=poster
        )
        xbmc.log("Tracked watch progress: {} S{}E{}".format(series_title, season, episode_num), xbmc.LOGINFO)
    
    verified_servers = scraper.get_stream_url(episode_url, force_refresh=force_refresh)
    
    if not verified_servers:
        xbmc.log("No verified servers!", xbmc.LOGERROR)
        
        dialog = xbmcgui.Dialog()
        retry = dialog.yesno(
            'Stream Error',
            'No working servers found. Try again?',
            nolabel='Cancel',
            yeslabel='Retry'
        )
        
        if retry:
            play_video(episode_url, force_refresh=True, series_url=series_url,
                      series_title=series_title, episode_num=episode_num,
                      season=season, total_episodes=total_episodes, poster=poster,
                      next_episode_url=next_episode_url, next_episode_num=next_episode_num,
                      next_season=next_season, next_title=next_title)
            return
        else:
            xbmcplugin.setResolvedUrl(_handle, False, listitem=xbmcgui.ListItem())
            return
    
    # Auto-play or show dialog
    if len(verified_servers) == 1:
        selected_server = verified_servers[0]
        xbmc.log("Auto-playing: {}".format(selected_server['name']), xbmc.LOGINFO)
    else:
        server_names = ["{} ({})".format(s['name'], s['quality']) for s in verified_servers]
        dialog = xbmcgui.Dialog()
        selected_idx = dialog.select('Choose Server', server_names)
        
        if selected_idx == -1:
            xbmcplugin.setResolvedUrl(_handle, False, listitem=xbmcgui.ListItem())
            return
        
        selected_server = verified_servers[selected_idx]
    
    stream_url = selected_server['url']
    xbmc.log("Playing: {}".format(stream_url[:150]), xbmc.LOGINFO)
    
    # Build playable URL
    user_agent = scraper.session.headers.get('User-Agent', '')
    referer = scraper.base_url + "/"
    
    if user_agent or referer:
        headers = []
        if user_agent:
            headers.append("User-Agent={}".format(user_agent))
        if referer:
            headers.append("Referer={}".format(referer))
        playable_url = "{}|{}".format(stream_url, '&'.join(headers))
    else:
        playable_url = stream_url
    
    play_item = xbmcgui.ListItem(path=playable_url)
    
    if '.m3u8' in stream_url:
        play_item.setMimeType('application/vnd.apple.mpegurl')
        play_item.setContentLookup(False)
    elif '.mp4' in stream_url:
        play_item.setMimeType('video/mp4')
    
    play_item.setProperty('IsPlayable', 'true')
    play_item.setProperty('IsInternetStream', 'true')
    
    # Set resume position if available
    if start_position > 0:
        play_item.setProperty('StartOffset', str(start_position))
        play_item.setProperty('ResumeTime', str(start_position))
    
    # Prepare next episode data for auto-play
    next_episode_data = None
    if next_episode_url and next_episode_num > 0:
        # Build the play URL for next episode
        next_play_url = get_url(
            action='play',
            episode_url=next_episode_url,
            series_url=series_url,
            series_title=series_title,
            episode_num=next_episode_num,
            season=next_season,
            total_episodes=total_episodes,
            poster=poster
        )
        
        next_episode_data = {
            'url': next_episode_url,
            'number': next_episode_num,
            'season': next_season,
            'title': next_title,
            'play_url': _url + '?' + next_play_url.split('?')[1] if '?' in next_play_url else next_play_url
        }
        xbmc.log("Next episode prepared: S{}E{}".format(next_season, next_episode_num), xbmc.LOGINFO)
    
    # Set episode info in player monitor
    player_monitor.set_episode_info(episode_url, next_episode_data)
    
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    xbmc.log("Playback started", xbmc.LOGINFO)
    
    # Seek to resume position after a small delay
    if start_position > 0:
        xbmc.sleep(1000)  # Wait 1 second for player to start
        if player_monitor.isPlaying():
            player_monitor.seekTime(start_position)
            xbmc.log("Seeked to position: {}s".format(start_position), xbmc.LOGINFO)

def search_dialog():
    """Show search dialog and display results"""
    dialog = xbmcgui.Dialog()
    query = dialog.input('Search for Episodes', type=xbmcgui.INPUT_ALPHANUM)
    
    if not query:
        return
    
    xbmc.log("User search query: {}".format(query), xbmc.LOGINFO)
    
    # Show searching progress
    progress = xbmcgui.DialogProgress()
    progress.create('Searching', 'Searching for: {}'.format(query))
    
    results = scraper.search(query)
    progress.close()
    
    if not results:
        dialog.ok('No Results', 'No episodes found for: {}'.format(query))
        return
    
    # Display results
    xbmcplugin.setPluginCategory(_handle, 'Search: {}'.format(query))
    xbmcplugin.setContent(_handle, 'episodes')
    
    for result in results:
        list_item = xbmcgui.ListItem(label=result['title'])
        
        if result['poster']:
            list_item.setArt({'thumb': result['poster'], 'poster': result['poster']})
        
        list_item.setInfo('video', {
            'title': result['title'],
            'episode': result['episode_number'],
            'mediatype': 'episode'
        })
        
        # When user selects this, we'll navigate to parent series
        # get_url() will handle encoding properly
        url = get_url(action='search_select', episode_url=result['episode_url'], episode_title=result['title'])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.endOfDirectory(_handle)

def handle_search_selection(episode_url, episode_title):
    """When user selects episode from search, find parent series and show all episodes"""
    
    # URLs might be double-encoded due to how they're passed through plugin URLs
    # Decode once more if needed (check if still contains %)
    if '%' in episode_url and not episode_url.startswith('http'):
        # Malformed, try to fix
        xbmc.log("WARNING: Malformed episode URL: {}".format(episode_url), xbmc.LOGWARNING)
    
    # If URL contains %XX patterns, it might need another decode
    # This handles the case where the HTML had pre-encoded URLs
    import urllib.parse
    decoded_url = urllib.parse.unquote(episode_url)
    
    # If decoding changed something, use the decoded version
    if decoded_url != episode_url:
        xbmc.log("URL was encoded, decoded from: {}".format(episode_url[:80]), xbmc.LOGINFO)
        xbmc.log("                         to: {}".format(decoded_url[:80]), xbmc.LOGINFO)
        episode_url = decoded_url
    
    xbmc.log("=== SEARCH SELECTION ===", xbmc.LOGINFO)
    xbmc.log("Episode URL received: {}".format(episode_url[:100]), xbmc.LOGINFO)
    xbmc.log("Episode title: {}".format(episode_title), xbmc.LOGINFO)
    
    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('Loading', 'Finding series for: {}'.format(episode_title))
    
    # Get parent series URL
    series_url = scraper.get_parent_series_url(episode_url)
    
    progress.close()
    
    xbmc.log("Parent series URL found: {}".format(series_url), xbmc.LOGINFO)
    
    if not series_url:
        xbmc.log("No parent series URL found!", xbmc.LOGWARNING)
        dialog = xbmcgui.Dialog()
        play_now = dialog.yesno(
            'Series Not Found',
            'Could not find the series page. Play this episode directly?',
            nolabel='Cancel',
            yeslabel='Play Now'
        )
        
        if play_now:
            play_video(episode_url)
        else:
            # User cancelled - show empty directory
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
        return
    
    # Navigate to series episodes page
    xbmc.log("Calling list_episodes with series_url: {}".format(series_url), xbmc.LOGINFO)
    try:
        list_episodes(series_url, episode_title.split(' - ')[0] if ' - ' in episode_title else episode_title)
    except Exception as e:
        xbmc.log("Error in list_episodes: {}".format(e), xbmc.LOGERROR)
        import traceback
        xbmc.log("Traceback: {}".format(traceback.format_exc()), xbmc.LOGERROR)
        dialog = xbmcgui.Dialog()
        dialog.ok('Error', 'Could not load episodes for this series.')
        xbmcplugin.endOfDirectory(_handle, succeeded=False)

def show_continue_watching():
    """Display Continue Watching list"""
    xbmc.log("=== SHOW CONTINUE WATCHING ===", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, 'Continue Watching')
    xbmcplugin.setContent(_handle, 'episodes')
    
    continue_watching = user_data.get_continue_watching(limit=20)
    
    if not continue_watching:
        # Show message if no history
        xbmcgui.Dialog().ok('Continue Watching', 'No watch history yet. Start watching some series!')
        xbmcplugin.endOfDirectory(_handle)
        return
    
    for item in continue_watching:
        # Build display title
        series_title = item['series_title']
        last_ep = item['last_episode']
        last_season = item['last_season']
        watched = item['watched_count']
        total = item['total_episodes']
        
        # Progress indicator
        if total > 0:
            progress_pct = int((watched / total) * 100)
            progress_bar = "[{}{}] {}%".format(
                "=" * (progress_pct // 10),
                " " * (10 - progress_pct // 10),
                progress_pct
            )
            label = "{} - S{}E{} | {}".format(series_title, last_season, last_ep, progress_bar)
        else:
            label = "{} - S{}E{} | {} watched".format(series_title, last_season, last_ep, watched)
        
        list_item = xbmcgui.ListItem(label=label)
        
        if item['poster']:
            list_item.setArt({'thumb': item['poster'], 'poster': item['poster'], 'fanart': item['poster']})
        
        list_item.setInfo('video', {
            'title': series_title,
            'episode': last_ep,
            'season': last_season,
            'mediatype': 'episode',
            'tvshowtitle': series_title
        })
        
        # When clicked, navigate to series episodes
        url = get_url(action='episodes', series_url=item['series_url'], 
                     series_title=series_title, poster=item['poster'])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.endOfDirectory(_handle)
    xbmc.log("Displayed {} continue watching items".format(len(continue_watching)), xbmc.LOGINFO)

def show_favorites():
    """Display Favorites list"""
    xbmc.log("=== SHOW FAVORITES ===", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, 'My Favorites')
    xbmcplugin.setContent(_handle, 'tvshows')
    
    favorites = user_data.load_favorites()
    
    if not favorites:
        # Show helpful message if no favorites
        dialog = xbmcgui.Dialog()
        dialog.ok(
            '⭐ My Favorites',
            'You don\'t have any favorites yet![CR][CR]'
            '[COLOR yellow]How to add favorites:[/COLOR][CR]'
            '1. Browse the series list[CR]'
            '2. Click on any series to see episodes[CR]'
            '3. At the TOP of episode list, click:[CR]'
            '   [COLOR yellow]⭐ ADD TO FAVORITES[/COLOR][CR][CR]'
            'Your favorite series will appear here!'
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    for fav in favorites:
        list_item = xbmcgui.ListItem(label="⭐ {}".format(fav['series_title']))
        
        if fav['poster']:
            list_item.setArt({'poster': fav['poster'], 'fanart': fav['poster']})
        
        list_item.setInfo('video', {
            'title': fav['series_title'],
            'mediatype': 'tvshow',
            'plot': 'Added: {}'.format(fav['added_date'])
        })
        
        # Context menu for removing from favorites
        list_item.addContextMenuItems([
            ('Remove from Favorites', 'RunPlugin({})'.format(
                get_url(action='remove_favorite', series_url=fav['series_url'])
            ))
        ])
        
        # When clicked, navigate to series episodes
        url = get_url(action='episodes', series_url=fav['series_url'], 
                     series_title=fav['series_title'], poster=fav.get('poster', ''))
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)
    xbmc.log("Displayed {} favorites".format(len(favorites)), xbmc.LOGINFO)

def add_favorite_action(series_url, series_title, poster=""):
    """Add series to favorites (called from context menu)"""
    success = user_data.add_favorite(series_url, series_title, poster)
    
    if success:
        # Show detailed notification with instructions
        dialog = xbmcgui.Dialog()
        dialog.notification(
            'Added to Favorites!',
            'Go to MAIN MENU → ⭐ MY FAVORITES to see it',
            xbmcgui.NOTIFICATION_INFO,
            5000  # Show for 5 seconds
        )
        
        # Also show a dialog with clear instructions
        dialog.ok(
            '⭐ Added to Favorites!',
            '[COLOR yellow]{}[/COLOR] has been added to your favorites![CR][CR]'
            'To access your favorites:[CR]'
            '1. Press [COLOR cyan]BACK[/COLOR] to return to MAIN MENU[CR]'
            '2. Look at the TOP of the list[CR]'
            '3. Click [COLOR yellow]⭐ MY FAVORITES[/COLOR][CR][CR]'
            'You will see all your favorite series there!'.format(series_title)
        )
    else:
        xbmcgui.Dialog().notification(
            'Already in Favorites',
            'This series is already in your favorites!',
            xbmcgui.NOTIFICATION_WARNING,
            3000
        )
    
    # Refresh the current directory
    xbmc.executebuiltin('Container.Refresh')

def remove_favorite_action(series_url):
    """Remove series from favorites (called from context menu)"""
    success = user_data.remove_favorite(series_url)
    
    if success:
        xbmcgui.Dialog().notification(
            'Favorites',
            'Removed from favorites',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
    else:
        xbmcgui.Dialog().notification(
            'Favorites',
            'Not in favorites!',
            xbmcgui.NOTIFICATION_WARNING,
            2000
        )
    
    # Refresh the current directory
    xbmc.executebuiltin('Container.Refresh')

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    
    if not params:
        list_series(page=1)
    elif params['action'] == 'list':
        list_series(page=int(params.get('page', 1)))
    elif params['action'] == 'episodes':
        list_episodes(
            params['series_url'],
            params.get('series_title', 'Episodes'),
            params.get('poster', '')
        )
    elif params['action'] == 'play':
        force_refresh = params.get('force_refresh', '0') == '1'
        play_video(
            params['episode_url'],
            force_refresh=force_refresh,
            series_url=params.get('series_url', ''),
            series_title=params.get('series_title', ''),
            episode_num=int(params.get('episode_num', 0)),
            season=int(params.get('season', 1)),
            total_episodes=int(params.get('total_episodes', 0)),
            poster=params.get('poster', ''),
            next_episode_url=params.get('next_episode_url', ''),
            next_episode_num=int(params.get('next_episode_num', 0)),
            next_season=int(params.get('next_season', 1)),
            next_title=params.get('next_title', '')
        )
    elif params['action'] == 'search':
        search_dialog()
    elif params['action'] == 'search_select':
        handle_search_selection(params['episode_url'], params.get('episode_title', 'Episode'))
    elif params['action'] == 'continue_watching':
        show_continue_watching()
    elif params['action'] == 'favorites':
        show_favorites()
    elif params['action'] == 'add_favorite':
        add_favorite_action(
            params['series_url'],
            params['series_title'],
            params.get('poster', '')
        )
    elif params['action'] == 'remove_favorite':
        remove_favorite_action(params['series_url'])
    else:
        raise ValueError('Invalid paramstring: {}'.format(paramstring))

if __name__ == '__main__':
    xbmc.log("=== 3SK ADDON v5 (SERVER INDEX CACHE) ===", xbmc.LOGINFO)
    
    # Clean old cache
    scraper.cache.clear_old()
    
    router(sys.argv[2][1:])
