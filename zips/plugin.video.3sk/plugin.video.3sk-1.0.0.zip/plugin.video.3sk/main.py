import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
import time
import json

# IMPORTANT: Import requests with error handling
try:
    import requests
except ImportError as e:
    xbmc.log("ERROR: requests module not found: {}".format(e), xbmc.LOGERROR)
    sys.exit(1)

# IMPORTANT: BeautifulSoup import for Kodi
try:
    from bs4 import BeautifulSoup
except ImportError as e:
    xbmc.log("ERROR: BeautifulSoup4 module not found: {}".format(e), xbmc.LOGERROR)
    sys.exit(1)

# ==============================================================================
# CONFIGURATION
# ==============================================================================

DEV_MODE = False
DEV_URL = "http://0.0.0.0:5000"

# Android TV optimizations with SMART SERVER INDEX CACHE
CACHE_DURATION = 600  # 10 minutes pour l'URL
SERVER_INDEX_CACHE_DURATION = 86400  # 24 heures pour l'index du serveur!
MAX_SERVERS_TO_TEST = 3
ITEMS_PER_PAGE = 24

SITE_CONFIG = {
    "DOMAINS": [
        "https://esheaq.onl",
        "https://x.esheaq.onl",
        "https://3sk.media",
        "https://u.3sk.media"
    ],
    "SELECTORS": {
        "series_container": "article.postEp",
        "series_title": "div.title",
        "series_url": "a",
        "series_img_selector": ".imgBg img",
        "series_img_attr": "data-image",

        "episode_list_container": "#epiList",
        "episode_item": "article.postEp",
        "episode_num": "div.episodeNum span:nth-of-type(2)",
        "episode_link": "a",

        "server_list": "ul.serversList li",
        "server_attr": "data-src"
    }
}

# ==============================================================================
# SMART CACHE WITH SERVER INDEX
# ==============================================================================

class ServerIndexCache:
    """
    Cache intelligent en 2 niveaux:
    
    Niveau 1 (court): URL du stream (10 min)
    Niveau 2 (long): INDEX du serveur qui marche (24h)
    
    Si l'URL expire, on teste d'abord le serveur qui marchait avant!
    """
    def __init__(self, session):
        self.url_cache = {}        # {episode: {"url": "...", "timestamp": ...}}
        self.server_cache = {}     # {episode: {"index": 2, "timestamp": ...}}
        self.session = session
        self.stats = {
            'url_hits': 0,
            'url_misses': 0,
            'server_hits': 0,
            'url_invalidated': 0
        }
    
    def get_url(self, key, validate=True):
        """
        Get cached URL with validation
        """
        if key not in self.url_cache:
            self.stats['url_misses'] += 1
            return None
        
        url, timestamp = self.url_cache[key]
        
        # Check expiration
        if time.time() - timestamp > CACHE_DURATION:
            xbmc.log("URL cache expired for: {}".format(key[:50]), xbmc.LOGDEBUG)
            del self.url_cache[key]
            self.stats['url_misses'] += 1
            return None
        
        # Validate if requested
        if validate:
            if self._quick_validate(url):
                xbmc.log("URL CACHE HIT (validated): {}".format(key[:50]), xbmc.LOGINFO)
                self.stats['url_hits'] += 1
                return url
            else:
                xbmc.log("URL INVALIDATED (dead link): {}".format(key[:50]), xbmc.LOGWARNING)
                del self.url_cache[key]
                self.stats['url_invalidated'] += 1
                return None
        else:
            self.stats['url_hits'] += 1
            return url
    
    def get_server_index(self, key):
        """
        Get cached server index (quel serveur marchait avant)
        Cache beaucoup plus long (24h) car l'index change rarement
        """
        if key not in self.server_cache:
            return None
        
        server_index, timestamp = self.server_cache[key]
        
        # Check expiration (24h)
        if time.time() - timestamp > SERVER_INDEX_CACHE_DURATION:
            xbmc.log("Server index cache expired: {}".format(key[:50]), xbmc.LOGDEBUG)
            del self.server_cache[key]
            return None
        
        xbmc.log("SERVER INDEX CACHE HIT: Episode {} -> Test server {} first!".format(
            key[:50], server_index
        ), xbmc.LOGINFO)
        self.stats['server_hits'] += 1
        return server_index
    
    def set_url(self, key, url):
        """Cache URL"""
        self.url_cache[key] = (url, time.time())
        xbmc.log("CACHED URL: {}".format(key[:50]), xbmc.LOGDEBUG)
    
    def set_server_index(self, key, server_index):
        """Cache server index (très important!)"""
        self.server_cache[key] = (server_index, time.time())
        xbmc.log("CACHED SERVER INDEX: Episode {} -> Server {} works!".format(
            key[:50], server_index
        ), xbmc.LOGINFO)
    
    def _quick_validate(self, url):
        """Quick URL validation (2 seconds max)"""
        try:
            response = self.session.head(url, timeout=2, allow_redirects=True)
            return response.status_code in [200, 206, 301, 302, 303, 307, 308]
        except:
            return False
    
    def clear_old(self):
        """Clear expired entries"""
        now = time.time()
        
        # Clear expired URLs (10 min)
        expired_urls = [k for k, (_, t) in self.url_cache.items() 
                       if now - t > CACHE_DURATION]
        for k in expired_urls:
            del self.url_cache[k]
        
        # Clear expired server indexes (24h)
        expired_servers = [k for k, (_, t) in self.server_cache.items() 
                          if now - t > SERVER_INDEX_CACHE_DURATION]
        for k in expired_servers:
            del self.server_cache[k]
        
        if expired_urls or expired_servers:
            xbmc.log("Cleared {} expired URLs, {} expired server indexes".format(
                len(expired_urls), len(expired_servers)
            ), xbmc.LOGINFO)
    
    def get_stats(self):
        """Get cache statistics"""
        total_url = self.stats['url_hits'] + self.stats['url_misses']
        if total_url > 0:
            url_hit_rate = (self.stats['url_hits'] / total_url) * 100
        else:
            url_hit_rate = 0
        
        return {
            'url_hits': self.stats['url_hits'],
            'url_misses': self.stats['url_misses'],
            'server_hits': self.stats['server_hits'],
            'url_invalidated': self.stats['url_invalidated'],
            'url_hit_rate': url_hit_rate,
            'url_cache_size': len(self.url_cache),
            'server_cache_size': len(self.server_cache)
        }

# ==============================================================================
# UTILITY FUNCTIONS
# ==============================================================================

def unpack_js(packed_code):
    try:
        match = re.search(r"}\('(.*)',(\d+),(\d+),'([^']*)'\.split\('\|'\)", packed_code)
        if not match: return None
        payload, radix, count, symtab = match.groups()
        radix = int(radix)
        symbols = symtab.split('|')
        def lookup(match):
            value = int(match.group(0), radix)
            return symbols[value] if value < len(symbols) and symbols[value] else match.group(0)
        return re.sub(r'\b\w+\b', lookup, payload)
    except: return None

# ==============================================================================
# THE SCRAPER CLASS
# ==============================================================================

class ThreeSkScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://google.com/'
        })

        if DEV_MODE:
            xbmc.log("DEV MODE ACTIVE: Intercepting requests to {}".format(DEV_URL), xbmc.LOGINFO)
            self.base_url = DEV_URL
        else:
            self.base_url = self._find_active_domain()
        
        # Initialize smart cache with server index tracking
        self.cache = ServerIndexCache(self.session)

    def _find_active_domain(self):
        xbmc.log("Checking domains...", xbmc.LOGINFO)
        for domain in SITE_CONFIG["DOMAINS"]:
            try:
                r = self.session.head(domain, timeout=5, allow_redirects=True)
                if r.status_code < 400:
                    return domain
            except: continue
        return SITE_CONFIG["DOMAINS"][0]

    def _request(self, url):
        target_url = url

        if DEV_MODE:
            for domain in SITE_CONFIG["DOMAINS"]:
                if domain in url:
                    target_url = url.replace(domain, DEV_URL)
                    break

            if target_url.startswith("/"):
                target_url = urllib.parse.urljoin(DEV_URL, target_url)

        xbmc.log("Requesting: {}".format(target_url), xbmc.LOGDEBUG)
        try:
            return self.session.get(target_url, timeout=30, allow_redirects=True)
        except Exception as e:
            xbmc.log("Connection Failed: {}".format(e), xbmc.LOGERROR)
            return None

    def _fix_url(self, url):
        if url.startswith("http"): return url
        return urllib.parse.urljoin(self.base_url, url)
    
    def _test_stream_url(self, url):
        """Quick test if URL is accessible"""
        try:
            head_response = self.session.head(url, timeout=3, allow_redirects=True)
            
            if head_response.status_code == 200:
                return True
            elif head_response.status_code in [301, 302, 303, 307, 308]:
                return True
            elif head_response.status_code == 403:
                get_response = self.session.get(url, headers={'Range': 'bytes=0-512'}, timeout=3)
                return get_response.status_code in [200, 206]
            
            return False
        except:
            return False
    
    def _extract_stream_from_html(self, html_content):
        """Extract stream URL using test_vidroba.py patterns"""
        if 'eval(function(p,a,c,k,e,d)' in html_content:
            unpacked = unpack_js(html_content)
            if unpacked:
                html_content = unpacked
        
        patterns = [
            ('JWPlayer file (double quotes)', r'"file"\s*:\s*"([^"]+)"'),
            ('JWPlayer file (single quotes)', r"'file'\s*:\s*'([^']+)'"),
            ('sources array', r'"sources"\s*:\s*\[\s*"([^"]+)"'),
            ('Direct m3u8', r'(https?://[^\s"\'<>]+\.m3u8(?:\?[^\s"\'<>]+)?)'),
            ('Direct mp4', r'(https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]+)?)')
        ]
        
        for name, pattern in patterns:
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                url = match.group(1)
                url = url.replace('\\/', '/').replace('\\u0026', '&').replace('&amp;', '&')
                
                if url.startswith('http') and any(ext in url.lower() for ext in ['.m3u8', '.mp4', '.mkv']):
                    xbmc.log("Extracted via {}: {}".format(name, url[:100]), xbmc.LOGINFO)
                    return url
        
        return None
    
    def _resolve_iframe(self, iframe_url, max_depth=3):
        """Resolve iframe to find stream"""
        if max_depth <= 0:
            return None
            
        xbmc.log("Resolving iframe: {}".format(iframe_url[:80]), xbmc.LOGDEBUG)
        
        try:
            response = self._request(iframe_url)
            if not response:
                return None
            
            html_content = response.text
            
            # OK.RU specific
            if 'ok.ru' in iframe_url or 'ok.ru' in html_content:
                # Method 1: hlsManifestUrl
                hls_match = re.search(r'"hlsManifestUrl"\s*:\s*"([^"]+)"', html_content)
                if hls_match:
                    url = hls_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if url.startswith('http'):
                        return url
                
                # Method 2: Videos array
                videos_match = re.search(r'"videos"\s*:\s*\[([^\]]+)\]', html_content)
                if videos_match:
                    for quality in ['hd', 'sd', 'low']:
                        q_match = re.search(
                            r'"name"\s*:\s*"{}"\s*,\s*"url"\s*:\s*"([^"]+)"'.format(quality),
                            videos_match.group(1)
                        )
                        if q_match:
                            url = q_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                            if url.startswith('http'):
                                return url
                
                # Method 3: Direct okcdn URL
                okcdn_match = re.search(r'"(https://[^"]+okcdn\.ru[^"]+\.m3u8[^"]*)"', html_content)
                if okcdn_match:
                    url = okcdn_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if '&quot;' not in url and url.startswith('http'):
                        return url
            
            # Generic extraction
            stream_url = self._extract_stream_from_html(html_content)
            if stream_url:
                return stream_url
            
            # Nested iframe
            nested = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html_content)
            if nested:
                next_url = nested.group(1)
                if not next_url.startswith('http'):
                    next_url = urllib.parse.urljoin(iframe_url, next_url)
                
                if not next_url.startswith('about:') and not next_url.startswith('javascript:'):
                    return self._resolve_iframe(next_url, max_depth - 1)
            
            return None
            
        except Exception as e:
            xbmc.log("Error resolving iframe: {}".format(e), xbmc.LOGERROR)
            return None

    def get_series(self, page=1):
        """Get series list with pagination"""
        if page == 1:
            url = "{}/e3blk2h43q/".format(self.base_url)
        else:
            url = "{}/e3blk2h43q/page/{}/".format(self.base_url, page)
        
        xbmc.log("Scraping Series page {}: {}".format(page, url), xbmc.LOGINFO)

        response = self._request(url)
        if not response: return []

        soup = BeautifulSoup(response.text, 'html.parser')
        series_list = []
        items = soup.select(SITE_CONFIG["SELECTORS"]["series_container"])
        xbmc.log("Found {} items on page {}".format(len(items), page), xbmc.LOGINFO)

        for article in items:
            try:
                title = article.select_one(SITE_CONFIG["SELECTORS"]["series_title"]).text.strip()
                link = self._fix_url(article.select_one(SITE_CONFIG["SELECTORS"]["series_url"])['href'])
                img_tag = article.select_one(SITE_CONFIG["SELECTORS"]["series_img_selector"])
                poster = img_tag.get(SITE_CONFIG["SELECTORS"]["series_img_attr"]) or img_tag.get('src')

                series_list.append({'title': title, 'url': link, 'poster': poster})
            except: 
                continue

        return series_list

    def get_episodes(self, series_url):
        xbmc.log("Scraping Episodes from: {}".format(series_url), xbmc.LOGINFO)
        response = self._request(series_url)
        if not response: return []

        soup = BeautifulSoup(response.text, 'html.parser')
        container = soup.select_one(SITE_CONFIG["SELECTORS"]["episode_list_container"]) or soup
        items = container.select(SITE_CONFIG["SELECTORS"]["episode_item"])
        xbmc.log("Found {} episode items.".format(len(items)), xbmc.LOGINFO)

        episodes = []
        for idx, item in enumerate(items):
            try:
                a_tag = item.select_one(SITE_CONFIG["SELECTORS"]["episode_link"])
                if not a_tag: continue
                ep_url = self._fix_url(a_tag['href'])

                num_tag = item.select_one(SITE_CONFIG["SELECTORS"]["episode_num"])
                if num_tag and num_tag.text.strip().isdigit():
                    ep_num = int(num_tag.text.strip())
                else:
                    ep_num = len(items) - idx

                episodes.append({'number': ep_num, 'url': ep_url, 'title': "Episode {}".format(ep_num)})
            except: 
                continue

        return episodes

    def get_stream_url(self, episode_url, force_refresh=False):
        """
        SMART SERVER INDEX CACHE:
        1. Check URL cache (validated)
        2. If expired, check SERVER INDEX cache
        3. Test cached server FIRST (huge time saver!)
        4. Fallback to other servers if needed
        """
        cache_key = episode_url
        
        # Step 1: Check URL cache (with validation)
        if not force_refresh:
            cached_url = self.cache.get_url(cache_key, validate=True)
            if cached_url:
                xbmc.log("URL cache hit! Using validated URL", xbmc.LOGINFO)
                return [{'name': 'Cached Server', 'url': cached_url, 'quality': 'Auto'}]
        
        # Step 2: Get all available servers
        response = self._request(episode_url)
        if not response: return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        see_link = soup.find('a', href=re.compile(r'/see/$'))
        if see_link:
            video_page_url = self._fix_url(see_link['href'])
        else:
            video_page_url = episode_url.rstrip('/') + '/see/'
        
        response = self._request(video_page_url)
        if not response: return []

        soup = BeautifulSoup(response.text, 'html.parser')
        servers = soup.select(SITE_CONFIG["SELECTORS"]["server_list"])
        xbmc.log("Found {} server options".format(len(servers)), xbmc.LOGINFO)
        
        # Step 3: Check SERVER INDEX cache (which server worked before)
        cached_server_index = self.cache.get_server_index(cache_key)
        
        verified_servers = []
        
        # SMART: If we know which server worked before, TEST IT FIRST!
        if cached_server_index is not None and cached_server_index < len(servers):
            xbmc.log("Testing CACHED server {} first (worked before!)".format(
                cached_server_index + 1
            ), xbmc.LOGINFO)
            
            server = servers[cached_server_index]
            embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
            
            if embed_url:
                embed_url = self._fix_url(embed_url)
                stream_url = self._resolve_server(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    xbmc.log("SUCCESS! Cached server {} still works!".format(
                        cached_server_index + 1
                    ), xbmc.LOGINFO)
                    
                    quality = self._guess_quality(stream_url)
                    verified_servers.append({
                        'name': "Server {} (Cached)".format(cached_server_index + 1),
                        'url': stream_url,
                        'quality': quality
                    })
                    
                    # Update caches
                    self.cache.set_url(cache_key, stream_url)
                    self.cache.set_server_index(cache_key, cached_server_index)
                    
                    # Return immediately (Android TV optimization)
                    return verified_servers
                else:
                    xbmc.log("Cached server {} now dead, trying others...".format(
                        cached_server_index + 1
                    ), xbmc.LOGWARNING)
        
        # Step 4: Test other servers (normal flow)
        xbmc.log("Testing first {} servers...".format(MAX_SERVERS_TO_TEST), xbmc.LOGINFO)
        
        servers_to_test = servers[:MAX_SERVERS_TO_TEST]
        
        for idx, server in enumerate(servers_to_test):
            # Skip if we already tested cached server
            if idx == cached_server_index:
                continue
            
            embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
            if not embed_url: continue

            embed_url = self._fix_url(embed_url)
            server_name = "Server {}".format(idx + 1)
            
            stream_url = self._resolve_server(embed_url)
            
            if stream_url and self._test_stream_url(stream_url):
                quality = self._guess_quality(stream_url)
                verified_servers.append({
                    'name': server_name,
                    'url': stream_url,
                    'quality': quality
                })
                xbmc.log("SUCCESS: {} verified!".format(server_name), xbmc.LOGINFO)
                
                # Cache URL and SERVER INDEX
                self.cache.set_url(cache_key, stream_url)
                self.cache.set_server_index(cache_key, idx)  # IMPORTANT: Remember which server works!
                
                break  # Stop after finding 1 (Android TV optimization)
        
        # Step 5: Fallback to remaining servers if needed
        if not verified_servers and len(servers) > MAX_SERVERS_TO_TEST:
            xbmc.log("Trying remaining servers...", xbmc.LOGINFO)
            
            for idx, server in enumerate(servers[MAX_SERVERS_TO_TEST:], start=MAX_SERVERS_TO_TEST):
                if idx == cached_server_index:
                    continue
                
                embed_url = server.get(SITE_CONFIG["SELECTORS"]["server_attr"])
                if not embed_url: continue

                embed_url = self._fix_url(embed_url)
                stream_url = self._resolve_server(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    verified_servers.append({
                        'name': "Server {}".format(idx + 1),
                        'url': stream_url,
                        'quality': self._guess_quality(stream_url)
                    })
                    
                    self.cache.set_url(cache_key, stream_url)
                    self.cache.set_server_index(cache_key, idx)
                    break
        
        # Log stats
        stats = self.cache.get_stats()
        xbmc.log("Cache stats: {} URL hits, {} server index hits, {:.1f}% URL hit rate".format(
            stats['url_hits'], stats['server_hits'], stats['url_hit_rate']
        ), xbmc.LOGINFO)
        
        return verified_servers
    
    def _resolve_server(self, embed_url):
        """Resolve server to stream URL"""
        is_internal = any(d in embed_url for d in SITE_CONFIG["DOMAINS"]) or DEV_URL in embed_url or "emb=true" in embed_url

        if is_internal:
            try:
                r2 = self._request(embed_url)
                if not r2: return None
                
                stream_url = self._extract_stream_from_html(r2.text)
                if stream_url:
                    return stream_url

                nested_iframe = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', r2.text)
                if nested_iframe:
                    iframe_url = nested_iframe.group(1)
                    if not iframe_url.startswith('http'):
                        iframe_url = urllib.parse.urljoin(embed_url, iframe_url)
                    
                    if not iframe_url.startswith('about:') and not iframe_url.startswith('javascript:'):
                        return self._resolve_iframe(iframe_url)
            except:
                return None
        else:
            return self._resolve_iframe(embed_url)
        
        return None
    
    def _guess_quality(self, url):
        """Guess quality from URL"""
        url_lower = url.lower()
        if 'hd' in url_lower or '1080' in url_lower:
            return 'HD'
        elif 'sd' in url_lower or '720' in url_lower:
            return 'SD'
        return 'Auto'

# ==============================================================================
# KODI ADDON LOGIC
# ==============================================================================

_handle = int(sys.argv[1])
_url = sys.argv[0]
addon = xbmcaddon.Addon()

scraper = ThreeSkScraper()

def get_url(**kwargs):
    return '{}?{}'.format(_url, urllib.parse.urlencode(kwargs))

def list_series(page=1):
    """List series with infinite scroll"""
    xbmcplugin.setPluginCategory(_handle, 'Turkish Series - Page {}'.format(page))
    xbmcplugin.setContent(_handle, 'tvshows')
    
    series_list = scraper.get_series(page=page)
    
    for series in series_list:
        list_item = xbmcgui.ListItem(label=series['title'])
        list_item.setArt({'poster': series['poster'], 'fanart': series['poster']})
        list_item.setInfo('video', {'title': series['title'], 'mediatype': 'tvshow'})
        url = get_url(action='episodes', series_url=series['url'], series_title=series['title'])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    # Next page
    if len(series_list) >= ITEMS_PER_PAGE - 5:
        next_item = xbmcgui.ListItem(label='[COLOR yellow]>>> Next Page (Page {}) >>>[/COLOR]'.format(page + 1))
        next_item.setArt({'icon': 'DefaultFolder.png'})
        next_url = get_url(action='list', page=page + 1)
        xbmcplugin.addDirectoryItem(_handle, next_url, next_item, True)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def list_episodes(series_url, series_title):
    xbmcplugin.setPluginCategory(_handle, series_title)
    xbmcplugin.setContent(_handle, 'episodes')
    
    episodes = scraper.get_episodes(series_url)
    
    for episode in episodes:
        list_item = xbmcgui.ListItem(label=episode['title'])
        list_item.setInfo('video', {
            'title': episode['title'],
            'episode': episode['number'],
            'mediatype': 'episode',
            'tvshowtitle': series_title
        })
        list_item.setProperty('IsPlayable', 'true')
        
        # Context menu for force refresh
        list_item.addContextMenuItems([
            ('Force Refresh Servers', 'RunPlugin({})'.format(
                get_url(action='play', episode_url=episode['url'], force_refresh='1')
            ))
        ])
        
        url = get_url(action='play', episode_url=episode['url'])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(_handle)

def play_video(episode_url, force_refresh=False):
    """Smart playback with server index caching"""
    xbmc.log("PLAY_VIDEO: {} (force={})".format(episode_url, force_refresh), xbmc.LOGINFO)
    
    verified_servers = scraper.get_stream_url(episode_url, force_refresh=force_refresh)
    
    if not verified_servers:
        xbmc.log("No verified servers!", xbmc.LOGERROR)
        
        dialog = xbmcgui.Dialog()
        retry = dialog.yesno(
            'Stream Error',
            'No working servers found. Try again?',
            nolabel='Cancel',
            yeslabel='Retry'
        )
        
        if retry:
            play_video(episode_url, force_refresh=True)
            return
        else:
            xbmcplugin.setResolvedUrl(_handle, False, listitem=xbmcgui.ListItem())
            return
    
    # Auto-play or show dialog
    if len(verified_servers) == 1:
        selected_server = verified_servers[0]
        xbmc.log("Auto-playing: {}".format(selected_server['name']), xbmc.LOGINFO)
    else:
        server_names = ["{} ({})".format(s['name'], s['quality']) for s in verified_servers]
        dialog = xbmcgui.Dialog()
        selected_idx = dialog.select('Choose Server', server_names)
        
        if selected_idx == -1:
            xbmcplugin.setResolvedUrl(_handle, False, listitem=xbmcgui.ListItem())
            return
        
        selected_server = verified_servers[selected_idx]
    
    stream_url = selected_server['url']
    xbmc.log("Playing: {}".format(stream_url[:150]), xbmc.LOGINFO)
    
    # Build playable URL
    user_agent = scraper.session.headers.get('User-Agent', '')
    referer = scraper.base_url + "/"
    
    if user_agent or referer:
        headers = []
        if user_agent:
            headers.append("User-Agent={}".format(user_agent))
        if referer:
            headers.append("Referer={}".format(referer))
        playable_url = "{}|{}".format(stream_url, '&'.join(headers))
    else:
        playable_url = stream_url
    
    play_item = xbmcgui.ListItem(path=playable_url)
    
    if '.m3u8' in stream_url:
        play_item.setMimeType('application/vnd.apple.mpegurl')
        play_item.setContentLookup(False)
    elif '.mp4' in stream_url:
        play_item.setMimeType('video/mp4')
    
    play_item.setProperty('IsPlayable', 'true')
    play_item.setProperty('IsInternetStream', 'true')
    
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    xbmc.log("Playback started", xbmc.LOGINFO)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    
    if not params:
        list_series(page=1)
    elif params['action'] == 'list':
        list_series(page=int(params.get('page', 1)))
    elif params['action'] == 'episodes':
        list_episodes(params['series_url'], params.get('series_title', 'Episodes'))
    elif params['action'] == 'play':
        force_refresh = params.get('force_refresh', '0') == '1'
        play_video(params['episode_url'], force_refresh=force_refresh)
    else:
        raise ValueError('Invalid paramstring: {}'.format(paramstring))

if __name__ == '__main__':
    xbmc.log("=== 3SK ADDON v5 (SERVER INDEX CACHE) ===", xbmc.LOGINFO)
    
    # Clean old cache
    scraper.cache.clear_old()
    
    router(sys.argv[2][1:])
