#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
AIO Metadata - Resources Library Package
"""

__all__ = ['utils', 'settings', 'api', 'plugin', 'player', 'router']
