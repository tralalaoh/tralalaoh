#!/usr/bin/env python3
"""
Turkish123 Scraper for Kodi
Enhanced with smart caching and advanced stream extraction
"""

import re
import time
import xbmc
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, quote

# ==============================================================================
# CONFIGURATION
# ==============================================================================

TURKISH123_CONFIG = {
    "BASE_URL": "https://www2.turkish123.org",
    "CACHE_DURATION": 0,  # DISABLED - Stream URLs have expiring tokens!
    "SERVER_INDEX_CACHE_DURATION": 86400,  # 24 hours for server indexes
    "MAX_SERVERS_TO_TEST": 3,
    
    "SELECTORS": {
        "series_list": "div.ml-item",
        "series_title": "h2",
        "series_link": "a",
        "series_image": "img",
        
        "episode_list": "div.les-content > a",
        "episode_title": "a",
        "episode_link": "a",
        
        "detail_title": "h1[itemprop=name]",
        "detail_cover": "img[itemprop='image']",
        "detail_desc": "p.f-desc",
    },
    
    "STREAM_PATTERNS": [
        # Tukipasti/Dwish embeds
        (r'https://tukipasti\.[^\s\'"]+', 'Tukipasti embed'),
        (r'https://dwish\.[^\s\'"]+', 'Dwish embed'),
        
        # Direct m3u8 patterns
        (r'(https?://[^\s"\'<>]+\.m3u8(?:\?[^\s"\'<>]+)?)', 'Direct m3u8'),
        
        # JWPlayer patterns
        (r'"file"\s*:\s*"([^"]+)"', 'JWPlayer file (double quotes)'),
        (r"'file'\s*:\s*'([^']+)'", 'JWPlayer file (single quotes)'),
        (r'"sources"\s*:\s*\[\s*"([^"]+)"', 'sources array'),
        
        # Direct mp4
        (r'(https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]+)?)', 'Direct mp4'),
        
        # OK.RU patterns
        (r'"hlsManifestUrl"\s*:\s*"([^"]+)"', 'OK.RU HLS'),
        (r'"(https://[^"]+okcdn\.ru[^"]+\.m3u8[^"]*)"', 'OK.RU okcdn'),
    ]
}

# ==============================================================================
# JAVASCRIPT UNPACKER
# ==============================================================================

def unpack_js(packed_code):
    """Unpack JavaScript packed code"""
    try:
        match = re.search(r"}\('(.*)',(\d+),(\d+),'([^']*)'\.split\('\|'\)", packed_code)
        if not match:
            return None
        
        payload, radix, count, symtab = match.groups()
        radix = int(radix)
        symbols = symtab.split('|')
        
        def lookup(match):
            value = int(match.group(0), radix)
            return symbols[value] if value < len(symbols) and symbols[value] else match.group(0)
        
        return re.sub(r'\b\w+\b', lookup, payload)
    except:
        return None

# ==============================================================================
# SMART CACHE WITH SERVER INDEX
# ==============================================================================

class ServerIndexCache:
    """Smart 2-level cache for Kodi"""
    
    def __init__(self, session):
        self.url_cache = {}
        self.server_cache = {}
        self.session = session
        self.stats = {
            'url_hits': 0,
            'url_misses': 0,
            'server_hits': 0,
            'url_invalidated': 0
        }
    
    def get_url(self, key, validate=True):
        """Get cached URL with validation"""
        if key not in self.url_cache:
            self.stats['url_misses'] += 1
            return None
        
        url, timestamp = self.url_cache[key]
        
        # Check expiration
        if time.time() - timestamp > TURKISH123_CONFIG["CACHE_DURATION"]:
            xbmc.log("Turkish123: URL cache expired for: {}".format(key[:50]), xbmc.LOGDEBUG)
            del self.url_cache[key]
            self.stats['url_misses'] += 1
            return None
        
        # Validate if requested
        if validate:
            if self._quick_validate(url):
                xbmc.log("Turkish123: URL CACHE HIT (validated): {}".format(key[:50]), xbmc.LOGINFO)
                self.stats['url_hits'] += 1
                return url
            else:
                xbmc.log("Turkish123: URL INVALIDATED (dead link): {}".format(key[:50]), xbmc.LOGWARNING)
                del self.url_cache[key]
                self.stats['url_invalidated'] += 1
                return None
        else:
            self.stats['url_hits'] += 1
            return url
    
    def get_server_index(self, key):
        """Get cached server index"""
        if key not in self.server_cache:
            return None
        
        server_index, timestamp = self.server_cache[key]
        
        # Check expiration (24h)
        if time.time() - timestamp > TURKISH123_CONFIG["SERVER_INDEX_CACHE_DURATION"]:
            xbmc.log("Turkish123: Server index cache expired: {}".format(key[:50]), xbmc.LOGDEBUG)
            del self.server_cache[key]
            return None
        
        xbmc.log("Turkish123: SERVER INDEX CACHE HIT: Episode {} -> Test server {} first!".format(
            key[:50], server_index
        ), xbmc.LOGINFO)
        self.stats['server_hits'] += 1
        return server_index
    
    def set_url(self, key, url):
        """Cache URL"""
        self.url_cache[key] = (url, time.time())
        xbmc.log("Turkish123: CACHED URL: {}".format(key[:50]), xbmc.LOGDEBUG)
    
    def set_server_index(self, key, server_index):
        """Cache server index"""
        self.server_cache[key] = (server_index, time.time())
        xbmc.log("Turkish123: CACHED SERVER INDEX: Episode {} -> Server {} works!".format(
            key[:50], server_index
        ), xbmc.LOGINFO)
    
    def _quick_validate(self, url):
        """Quick URL validation"""
        try:
            response = self.session.head(url, timeout=2, allow_redirects=True)
            return response.status_code in [200, 206, 301, 302, 303, 307, 308]
        except:
            return False
    
    def clear_old(self):
        """Clear expired entries"""
        now = time.time()
        
        expired_urls = [k for k, (_, t) in self.url_cache.items() 
                       if now - t > TURKISH123_CONFIG["CACHE_DURATION"]]
        for k in expired_urls:
            del self.url_cache[k]
        
        expired_servers = [k for k, (_, t) in self.server_cache.items() 
                          if now - t > TURKISH123_CONFIG["SERVER_INDEX_CACHE_DURATION"]]
        for k in expired_servers:
            del self.server_cache[k]
        
        if expired_urls or expired_servers:
            xbmc.log("Turkish123: Cleared {} expired URLs, {} expired server indexes".format(
                len(expired_urls), len(expired_servers)
            ), xbmc.LOGINFO)

# ==============================================================================
# TURKISH123 SCRAPER
# ==============================================================================

class Turkish123Scraper:
    """Turkish123 scraper for Kodi"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://www2.turkish123.org/'
        })
        
        self.base_url = TURKISH123_CONFIG["BASE_URL"]
        self.cache = ServerIndexCache(self.session)
        
        xbmc.log("Turkish123: Scraper initialized", xbmc.LOGINFO)
    
    def _request(self, url, timeout=30):
        """Make HTTP request"""
        if not url.startswith('http'):
            url = urljoin(self.base_url, url)
        
        try:
            xbmc.log("Turkish123: Requesting: {}...".format(url[:80]), xbmc.LOGDEBUG)
            response = self.session.get(url, timeout=timeout, allow_redirects=True)
            response.raise_for_status()
            return response
        except Exception as e:
            xbmc.log("Turkish123: Request failed: {}".format(e), xbmc.LOGERROR)
            return None
    
    def get_series_list(self, page=1):
        """Get series list"""
        url = "{}/series-list/".format(self.base_url)
        if page > 1:
            url = "{}/series-list/page/{}/".format(self.base_url, page)
        
        response = self._request(url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        series_list = []
        
        items = soup.select(TURKISH123_CONFIG["SELECTORS"]["series_list"])
        xbmc.log("Turkish123: Found {} series on page {}".format(len(items), page), xbmc.LOGINFO)
        
        for item in items:
            try:
                link = item.select_one(TURKISH123_CONFIG["SELECTORS"]["series_link"])
                title_elem = item.select_one(TURKISH123_CONFIG["SELECTORS"]["series_title"])
                img = item.select_one(TURKISH123_CONFIG["SELECTORS"]["series_image"])
                
                if not link or not title_elem:
                    continue
                
                series_list.append({
                    'title': title_elem.text.strip(),
                    'url': urljoin(self.base_url, link.get('href', '')),
                    'cover': img.get('src', '') if img else '',
                    'type': 'series'
                })
            except Exception as e:
                xbmc.log("Turkish123: Error parsing series: {}".format(e), xbmc.LOGERROR)
                continue
        
        return series_list
    
    def get_episodes(self, series_url):
        """Get episodes for a series"""
        response = self._request(series_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        episodes = []
        
        episode_links = soup.select(TURKISH123_CONFIG["SELECTORS"]["episode_list"])
        xbmc.log("Turkish123: Found {} episodes".format(len(episode_links)), xbmc.LOGINFO)
        
        for idx, link in enumerate(episode_links):
            try:
                title = link.text.strip()
                url = urljoin(self.base_url, link.get('href', ''))
                
                # Extract episode number
                ep_match = re.search(r'(?:Episode|Ep\.?)\s*(\d+)', title, re.IGNORECASE)
                ep_num = int(ep_match.group(1)) if ep_match else (len(episode_links) - idx)
                
                episodes.append({
                    'title': title,
                    'url': url,
                    'number': ep_num,
                    'type': 'episode',
                    'series_url': series_url
                })
            except Exception as e:
                xbmc.log("Turkish123: Error parsing episode: {}".format(e), xbmc.LOGERROR)
                continue
        
        # Sort by episode number (descending for latest first)
        episodes.sort(key=lambda x: x['number'], reverse=True)
        
        return episodes
    
    def search(self, query):
        """Search for series"""
        url = "{}/?s={}".format(self.base_url, quote(query))
        response = self._request(url)
        
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        results = []
        
        items = soup.select(TURKISH123_CONFIG["SELECTORS"]["series_list"])
        xbmc.log("Turkish123: Found {} search results for '{}'".format(len(items), query), xbmc.LOGINFO)
        
        for item in items:
            try:
                link = item.select_one(TURKISH123_CONFIG["SELECTORS"]["series_link"])
                title_elem = item.select_one(TURKISH123_CONFIG["SELECTORS"]["series_title"])
                img = item.select_one(TURKISH123_CONFIG["SELECTORS"]["series_image"])
                
                if not link or not title_elem:
                    continue
                
                results.append({
                    'title': title_elem.text.strip(),
                    'url': urljoin(self.base_url, link.get('href', '')),
                    'cover': img.get('src', '') if img else '',
                    'type': 'series'
                })
            except Exception as e:
                xbmc.log("Turkish123: Error parsing search result: {}".format(e), xbmc.LOGERROR)
                continue
        
        return results
    
    def _extract_stream_from_html(self, html_content):
        """Extract stream URL using multiple patterns"""
        # Try to unpack JavaScript first
        if 'eval(function(p,a,c,k,e,d)' in html_content:
            unpacked = unpack_js(html_content)
            if unpacked:
                xbmc.log("Turkish123: Unpacked JavaScript code", xbmc.LOGDEBUG)
                html_content = unpacked
        
        # Try all patterns
        for pattern, name in TURKISH123_CONFIG["STREAM_PATTERNS"]:
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                url = match.group(1) if match.lastindex else match.group(0)
                
                # Clean up URL
                url = url.replace('\\/', '/').replace('\\u0026', '&').replace('&amp;', '&')
                
                # Validate it's a proper stream URL
                if url.startswith('http') and any(ext in url.lower() for ext in ['.m3u8', '.mp4', 'tukipasti', 'dwish']):
                    xbmc.log("Turkish123: Extracted via {}: {}...".format(name, url[:100]), xbmc.LOGINFO)
                    return url
        
        return None
    
    def _resolve_iframe(self, iframe_url, max_depth=3):
        """Resolve iframe to find stream"""
        if max_depth <= 0:
            xbmc.log("Turkish123: Max iframe depth reached", xbmc.LOGWARNING)
            return None
        
        xbmc.log("Turkish123: Resolving iframe (depth {}): {}...".format(3-max_depth, iframe_url[:80]), xbmc.LOGDEBUG)
        
        try:
            response = self._request(iframe_url)
            if not response:
                return None
            
            html_content = response.text
            
            # OK.RU specific handling
            if 'ok.ru' in iframe_url or 'ok.ru' in html_content:
                xbmc.log("Turkish123: Detected OK.RU embed", xbmc.LOGINFO)
                
                # Method 1: hlsManifestUrl
                hls_match = re.search(r'"hlsManifestUrl"\s*:\s*"([^"]+)"', html_content)
                if hls_match:
                    url = hls_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if url.startswith('http'):
                        xbmc.log("Turkish123: Found OK.RU HLS manifest", xbmc.LOGINFO)
                        return url
                
                # Method 2: Videos array
                videos_match = re.search(r'"videos"\s*:\s*\[([^\]]+)\]', html_content)
                if videos_match:
                    for quality in ['hd', 'sd', 'low']:
                        q_match = re.search(
                            r'"name"\s*:\s*"{}"\s*,\s*"url"\s*:\s*"([^"]+)"'.format(quality),
                            videos_match.group(1)
                        )
                        if q_match:
                            url = q_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                            if url.startswith('http'):
                                xbmc.log("Turkish123: Found OK.RU {} quality".format(quality), xbmc.LOGINFO)
                                return url
            
            # Tukipasti/Dwish specific
            if 'tukipasti' in iframe_url or 'dwish' in iframe_url:
                xbmc.log("Turkish123: Detected Tukipasti/Dwish embed", xbmc.LOGINFO)
                m3u8_match = re.search(r'(https?://[^\s"\']*\.m3u8[^\s"\']*)', html_content)
                if m3u8_match:
                    url = m3u8_match.group(1)
                    xbmc.log("Turkish123: Found Tukipasti/Dwish m3u8", xbmc.LOGINFO)
                    return url
            
            # Generic extraction
            stream_url = self._extract_stream_from_html(html_content)
            if stream_url:
                return stream_url
            
            # Nested iframe
            nested = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html_content, re.IGNORECASE)
            if nested:
                next_url = nested.group(1)
                if not next_url.startswith('http'):
                    next_url = urljoin(iframe_url, next_url)
                
                if not next_url.startswith('about:') and not next_url.startswith('javascript:'):
                    return self._resolve_iframe(next_url, max_depth - 1)
            
            return None
            
        except Exception as e:
            xbmc.log("Turkish123: Error resolving iframe: {}".format(e), xbmc.LOGERROR)
            return None
    
    def _test_stream_url(self, url):
        """Quick test if stream URL is accessible"""
        try:
            head_response = self.session.head(url, timeout=3, allow_redirects=True)
            
            if head_response.status_code == 200:
                return True
            elif head_response.status_code in [301, 302, 303, 307, 308]:
                return True
            elif head_response.status_code == 403:
                get_response = self.session.get(
                    url, 
                    headers={'Range': 'bytes=0-512'}, 
                    timeout=3
                )
                return get_response.status_code in [200, 206]
            
            return False
        except:
            return False
    
    def get_stream_url(self, episode_url, force_refresh=False):
        """Get stream URL (no URL caching - tokens expire!)"""
        cache_key = episode_url
        
        # SKIP URL cache - stream URLs have expiring tokens!
        # We only use server index cache to know which server to test first
        
        xbmc.log("Turkish123: Extracting stream for: {}...".format(episode_url[:80]), xbmc.LOGINFO)
        
        # Step 2: Get episode page
        response = self._request(episode_url)
        if not response:
            return None
        
        # Step 3: Find embed URLs
        html = response.text
        
        embed_patterns = [
            r'https://tukipasti\.[^\s\'"]+',
            r'https://dwish\.[^\s\'"]+',
        ]
        
        embed_urls = []
        for pattern in embed_patterns:
            matches = re.findall(pattern, html)
            embed_urls.extend(matches)
        
        # Also look for iframe sources
        iframe_matches = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
        embed_urls.extend(iframe_matches)
        
        if not embed_urls:
            xbmc.log("Turkish123: No embed URLs found", xbmc.LOGWARNING)
            return None
        
        xbmc.log("Turkish123: Found {} potential embed URLs".format(len(embed_urls)), xbmc.LOGINFO)
        
        # Step 4: Check SERVER INDEX cache
        cached_server_index = self.cache.get_server_index(cache_key)
        
        # Test cached server FIRST if available
        if cached_server_index is not None and cached_server_index < len(embed_urls):
            xbmc.log("Turkish123: Testing CACHED server {} first".format(cached_server_index + 1), xbmc.LOGINFO)
            
            embed_url = embed_urls[cached_server_index]
            if not embed_url.startswith('http'):
                embed_url = urljoin(episode_url, embed_url)
            
            stream_url = self._resolve_iframe(embed_url)
            
            if stream_url and self._test_stream_url(stream_url):
                xbmc.log("Turkish123: SUCCESS! Cached server {} still works!".format(cached_server_index + 1), xbmc.LOGINFO)
                
                # Don't cache URL - tokens expire! Only cache server index
                self.cache.set_server_index(cache_key, cached_server_index)
                
                return stream_url
            else:
                xbmc.log("Turkish123: Cached server {} now dead, trying others...".format(cached_server_index + 1), xbmc.LOGWARNING)
        
        # Step 5: Test other servers
        max_to_test = min(len(embed_urls), TURKISH123_CONFIG["MAX_SERVERS_TO_TEST"])
        xbmc.log("Turkish123: Testing first {} servers...".format(max_to_test), xbmc.LOGINFO)
        
        for idx, embed_url in enumerate(embed_urls[:max_to_test]):
            if idx == cached_server_index:
                continue
            
            if not embed_url.startswith('http'):
                embed_url = urljoin(episode_url, embed_url)
            
            xbmc.log("Turkish123: Server {}/{}: {}...".format(idx + 1, max_to_test, embed_url[:60]), xbmc.LOGDEBUG)
            
            stream_url = self._resolve_iframe(embed_url)
            
            if stream_url and self._test_stream_url(stream_url):
                xbmc.log("Turkish123: SUCCESS: Server {} verified!".format(idx + 1), xbmc.LOGINFO)
                
                # Don't cache URL - tokens expire! Only cache server index
                self.cache.set_server_index(cache_key, idx)
                
                return stream_url
        
        # Step 6: Fallback to remaining servers
        if len(embed_urls) > max_to_test:
            xbmc.log("Turkish123: Trying remaining {} servers...".format(len(embed_urls) - max_to_test), xbmc.LOGINFO)
            
            for idx, embed_url in enumerate(embed_urls[max_to_test:], start=max_to_test):
                if idx == cached_server_index:
                    continue
                
                if not embed_url.startswith('http'):
                    embed_url = urljoin(episode_url, embed_url)
                
                stream_url = self._resolve_iframe(embed_url)
                
                if stream_url and self._test_stream_url(stream_url):
                    xbmc.log("Turkish123: SUCCESS: Server {} verified!".format(idx + 1), xbmc.LOGINFO)
                    
                    # Don't cache URL - tokens expire! Only cache server index
                    self.cache.set_server_index(cache_key, idx)
                    
                    return stream_url
        
        xbmc.log("Turkish123: No working stream found", xbmc.LOGERROR)
        return None
