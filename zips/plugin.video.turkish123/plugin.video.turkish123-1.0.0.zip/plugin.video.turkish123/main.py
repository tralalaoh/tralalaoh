import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import os
from datetime import datetime

# Import scraper
from turkish123_scraper import Turkish123Scraper

# ==============================================================================
# CONFIGURATION
# ==============================================================================

_handle = int(sys.argv[1])
_url = sys.argv[0]
addon = xbmcaddon.Addon()

# Initialize scraper
scraper = Turkish123Scraper()

# ==============================================================================
# USER DATA MANAGER - Favorites & Watch History
# ==============================================================================

class UserDataManager:
    """Manages user data: favorites and watch history"""
    
    def __init__(self, addon):
        self.addon = addon
        self.data_dir = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        
        if not xbmcvfs.exists(self.data_dir):
            xbmcvfs.mkdirs(self.data_dir)
        
        self.favorites_file = os.path.join(self.data_dir, 'favorites.json')
        self.history_file = os.path.join(self.data_dir, 'watch_history.json')
        
        xbmc.log("Turkish123: UserDataManager initialized: {}".format(self.data_dir), xbmc.LOGINFO)
    
    # ==================== FAVORITES ====================
    
    def load_favorites(self):
        """Load favorites from storage"""
        try:
            if xbmcvfs.exists(self.favorites_file):
                with open(self.favorites_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('favorites', [])
        except Exception as e:
            xbmc.log("Turkish123: Error loading favorites: {}".format(e), xbmc.LOGERROR)
        return []
    
    def save_favorites(self, favorites):
        """Save favorites to storage"""
        try:
            with open(self.favorites_file, 'w', encoding='utf-8') as f:
                json.dump({'favorites': favorites}, f, ensure_ascii=False, indent=2)
            xbmc.log("Turkish123: Saved {} favorites".format(len(favorites)), xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log("Turkish123: Error saving favorites: {}".format(e), xbmc.LOGERROR)
            return False
    
    def add_favorite(self, series_url, series_title, cover=""):
        """Add series to favorites"""
        favorites = self.load_favorites()
        
        if any(f['series_url'] == series_url for f in favorites):
            xbmc.log("Turkish123: Series already in favorites: {}".format(series_title), xbmc.LOGINFO)
            return False
        
        favorites.append({
            'series_url': series_url,
            'series_title': series_title,
            'cover': cover,
            'added_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
        
        self.save_favorites(favorites)
        xbmc.log("Turkish123: Added to favorites: {}".format(series_title), xbmc.LOGINFO)
        return True
    
    def remove_favorite(self, series_url):
        """Remove series from favorites"""
        favorites = self.load_favorites()
        original_count = len(favorites)
        
        favorites = [f for f in favorites if f['series_url'] != series_url]
        
        if len(favorites) < original_count:
            self.save_favorites(favorites)
            xbmc.log("Turkish123: Removed from favorites: {}".format(series_url), xbmc.LOGINFO)
            return True
        return False
    
    def is_favorite(self, series_url):
        """Check if series is in favorites"""
        favorites = self.load_favorites()
        return any(f['series_url'] == series_url for f in favorites)
    
    # ==================== WATCH HISTORY ====================
    
    def load_history(self):
        """Load watch history from storage"""
        try:
            if xbmcvfs.exists(self.history_file):
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('history', {})
        except Exception as e:
            xbmc.log("Turkish123: Error loading history: {}".format(e), xbmc.LOGERROR)
        return {}
    
    def save_history(self, history):
        """Save watch history to storage"""
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump({'history': history}, f, ensure_ascii=False, indent=2)
            xbmc.log("Turkish123: Saved watch history ({} series)".format(len(history)), xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log("Turkish123: Error saving history: {}".format(e), xbmc.LOGERROR)
            return False
    
    def update_watch_progress(self, series_url, series_title, episode_url, episode_num, total_episodes=0, cover=""):
        """Update watch progress for a series"""
        history = self.load_history()
        
        if series_url not in history:
            history[series_url] = {
                'series_title': series_title,
                'cover': cover,
                'watched_episodes': [],
                'total_episodes': total_episodes,
                'resume_positions': {}
            }
        
        series_data = history[series_url]
        
        series_data['last_watched_url'] = episode_url
        series_data['last_watched_episode'] = episode_num
        series_data['last_watched_date'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        if total_episodes > 0:
            series_data['total_episodes'] = total_episodes
        
        episode_id = "E{}".format(episode_num)
        if episode_id not in series_data['watched_episodes']:
            series_data['watched_episodes'].append(episode_id)
        
        if 'resume_positions' not in series_data:
            series_data['resume_positions'] = {}
        
        self.save_history(history)
        xbmc.log("Turkish123: Updated watch progress: {} - E{}".format(series_title, episode_num), xbmc.LOGINFO)
    
    def get_continue_watching(self, limit=10):
        """Get list of series to continue watching"""
        history = self.load_history()
        
        continue_watching = []
        for series_url, data in history.items():
            if 'last_watched_date' in data:
                continue_watching.append({
                    'series_url': series_url,
                    'series_title': data['series_title'],
                    'cover': data.get('cover', ''),
                    'last_episode': data['last_watched_episode'],
                    'last_watched_url': data['last_watched_url'],
                    'last_watched_date': data['last_watched_date'],
                    'watched_count': len(data.get('watched_episodes', [])),
                    'total_episodes': data.get('total_episodes', 0)
                })
        
        continue_watching.sort(key=lambda x: x['last_watched_date'], reverse=True)
        
        return continue_watching[:limit]
    
    def is_episode_watched(self, series_url, episode_num):
        """Check if an episode has been watched"""
        history = self.load_history()
        
        if series_url not in history:
            return False
        
        episode_id = "E{}".format(episode_num)
        return episode_id in history[series_url].get('watched_episodes', [])

# Initialize user data manager
user_data = UserDataManager(addon)

# ==============================================================================
# KODI ADDON FUNCTIONS
# ==============================================================================

def get_url(**kwargs):
    """Create plugin URL"""
    return '{}?{}'.format(_url, urllib.parse.urlencode(kwargs))

def list_series(page=1):
    """List series with pagination"""
    xbmcplugin.setPluginCategory(_handle, 'Turkish123 - Page {}'.format(page))
    xbmcplugin.setContent(_handle, 'tvshows')
    
    # Add special sections at top of first page
    if page == 1:
        # Continue Watching
        continue_watching = user_data.get_continue_watching(limit=5)
        if continue_watching:
            continue_item = xbmcgui.ListItem(label='[COLOR cyan]▶ Continue Watching ({}) ▶[/COLOR]'.format(len(continue_watching)))
            continue_item.setArt({'icon': 'DefaultRecentlyAddedEpisodes.png'})
            continue_url = get_url(action='continue_watching')
            xbmcplugin.addDirectoryItem(_handle, continue_url, continue_item, True)
        
        # Favorites
        favorites = user_data.load_favorites()
        if favorites:
            fav_label = '[COLOR yellow]⭐ MY FAVORITES ({}) ⭐[/COLOR]'.format(len(favorites))
        else:
            fav_label = '[COLOR yellow]⭐ MY FAVORITES (Empty) ⭐[/COLOR]'
        
        fav_item = xbmcgui.ListItem(label=fav_label)
        fav_item.setArt({'icon': 'DefaultAddSource.png'})
        fav_url = get_url(action='favorites')
        xbmcplugin.addDirectoryItem(_handle, fav_url, fav_item, True)
        
        # Search
        search_item = xbmcgui.ListItem(label='[COLOR orange]🔍 Search Series[/COLOR]')
        search_item.setArt({'icon': 'DefaultAddonsSearch.png'})
        search_url = get_url(action='search')
        xbmcplugin.addDirectoryItem(_handle, search_url, search_item, True)
    
    # Get series
    series_list = scraper.get_series_list(page=page)
    
    for series in series_list:
        list_item = xbmcgui.ListItem(label=series['title'])
        list_item.setArt({'poster': series['cover'], 'fanart': series['cover']})
        list_item.setInfo('video', {'title': series['title'], 'mediatype': 'tvshow'})
        
        is_fav = user_data.is_favorite(series['url'])
        
        # Context menu
        context_menu = []
        if is_fav:
            context_menu.append((
                'Remove from Favorites',
                'RunPlugin({})'.format(get_url(action='remove_favorite', series_url=series['url']))
            ))
        else:
            context_menu.append((
                'Add to Favorites',
                'RunPlugin({})'.format(get_url(
                    action='add_favorite',
                    series_url=series['url'],
                    series_title=series['title'],
                    cover=series.get('cover', '')
                ))
            ))
        
        list_item.addContextMenuItems(context_menu)
        
        # Add favorite indicator
        display_title = series['title']
        if is_fav:
            display_title = "⭐ {}".format(display_title)
        list_item.setLabel(display_title)
        
        url = get_url(action='episodes', series_url=series['url'], series_title=series['title'], cover=series.get('cover', ''))
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    # Next page
    if len(series_list) >= 20:
        next_item = xbmcgui.ListItem(label='[COLOR yellow]>>> Next Page (Page {}) >>>[/COLOR]'.format(page + 1))
        next_item.setArt({'icon': 'DefaultFolder.png'})
        next_url = get_url(action='list', page=page + 1)
        xbmcplugin.addDirectoryItem(_handle, next_url, next_item, True)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def list_episodes(series_url, series_title, cover=""):
    """List episodes"""
    xbmc.log("Turkish123: list_episodes for {}".format(series_title), xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, series_title)
    xbmcplugin.setContent(_handle, 'episodes')
    
    # Add favorite button at top
    is_fav = user_data.is_favorite(series_url)
    if is_fav:
        fav_label = '[COLOR red]★ REMOVE FROM FAVORITES[/COLOR]'
        fav_action = 'remove_favorite'
    else:
        fav_label = '[COLOR yellow]⭐ ADD TO FAVORITES[/COLOR]'
        fav_action = 'add_favorite'
    
    fav_item = xbmcgui.ListItem(label=fav_label)
    fav_item.setArt({'icon': 'DefaultAddSource.png'})
    fav_url = get_url(
        action=fav_action,
        series_url=series_url,
        series_title=series_title,
        cover=cover
    )
    xbmcplugin.addDirectoryItem(_handle, fav_url, fav_item, False)
    
    # Get episodes
    episodes = scraper.get_episodes(series_url)
    xbmc.log("Turkish123: Found {} episodes".format(len(episodes)), xbmc.LOGINFO)
    
    for idx, episode in enumerate(episodes):
        episode_num = episode['number']
        display_title = episode['title']
        
        # Check if watched
        is_watched = user_data.is_episode_watched(series_url, episode_num)
        
        if is_watched:
            display_title = "✓ {}".format(display_title)
        
        list_item = xbmcgui.ListItem(label=display_title)
        list_item.setInfo('video', {
            'title': display_title,
            'episode': episode_num,
            'mediatype': 'episode',
            'tvshowtitle': series_title,
            'playcount': 1 if is_watched else 0
        })
        list_item.setProperty('IsPlayable', 'true')
        
        # Get next episode info
        next_episode_url = ""
        next_episode_num = 0
        next_title = ""
        
        if idx < len(episodes) - 1:
            next_ep = episodes[idx + 1]
            next_episode_url = next_ep['url']
            next_episode_num = next_ep['number']
            next_title = next_ep['title']
        
        # Context menu
        list_item.addContextMenuItems([
            ('Force Refresh Servers', 'RunPlugin({})'.format(
                get_url(action='play', episode_url=episode['url'], force_refresh='1',
                       series_url=series_url, series_title=series_title,
                       episode_num=episode_num, total_episodes=len(episodes), cover=cover,
                       next_episode_url=next_episode_url, next_episode_num=next_episode_num,
                       next_title=next_title)
            ))
        ])
        
        url = get_url(action='play', episode_url=episode['url'],
                     series_url=series_url, series_title=series_title,
                     episode_num=episode_num, total_episodes=len(episodes), cover=cover,
                     next_episode_url=next_episode_url, next_episode_num=next_episode_num,
                     next_title=next_title)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(_handle)

def play_video(episode_url, force_refresh=False, series_url="", series_title="", episode_num=0, total_episodes=0, cover="", next_episode_url="", next_episode_num=0, next_title=""):
    """Play video with inputstream.adaptive and anti-403 headers"""
    xbmc.log("Turkish123: play_video: {}".format(episode_url), xbmc.LOGINFO)
    
    # Track watch progress
    if series_url and series_title and episode_num:
        user_data.update_watch_progress(
            series_url=series_url,
            series_title=series_title,
            episode_url=episode_url,
            episode_num=episode_num,
            total_episodes=total_episodes,
            cover=cover
        )
        xbmc.log("Turkish123: Tracked watch progress: {} E{}".format(series_title, episode_num), xbmc.LOGINFO)
    
    # Get stream URL (always get fresh URL - tokens expire!)
    stream_url = scraper.get_stream_url(episode_url, force_refresh=True)
    
    if not stream_url:
        xbmc.log("Turkish123: No stream found!", xbmc.LOGERROR)
        
        dialog = xbmcgui.Dialog()
        retry = dialog.yesno(
            'Stream Error',
            'No working stream found. Try again?',
            nolabel='Cancel',
            yeslabel='Retry'
        )
        
        if retry:
            play_video(episode_url, force_refresh=True, series_url=series_url,
                      series_title=series_title, episode_num=episode_num,
                      total_episodes=total_episodes, cover=cover,
                      next_episode_url=next_episode_url, next_episode_num=next_episode_num,
                      next_title=next_title)
            return
        else:
            xbmcplugin.setResolvedUrl(_handle, False, listitem=xbmcgui.ListItem())
            return
    
    xbmc.log("Turkish123: Stream URL: {}".format(stream_url), xbmc.LOGINFO)
    
    # Check if HLS
    is_hls = '.m3u8' in stream_url.lower()
    
    # Check for inputstream.adaptive
    has_inputstream = False
    try:
        import xbmcaddon
        inputstream_addon = xbmcaddon.Addon('inputstream.adaptive')
        has_inputstream = True
        xbmc.log("Turkish123: inputstream.adaptive version: {}".format(
            inputstream_addon.getAddonInfo('version')
        ), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("Turkish123: inputstream.adaptive NOT installed: {}".format(e), xbmc.LOGWARNING)
        if is_hls:
            dialog = xbmcgui.Dialog()
            dialog.ok(
                'inputstream.adaptive Required',
                'HLS streams require inputstream.adaptive.[CR][CR]'
                'Install from: Settings > Add-ons > Install from repository >[CR]'
                'Kodi Add-on repository > VideoPlayer InputStream >[CR]'
                'InputStream Adaptive[CR][CR]'
                'Then restart Kodi.'
            )
            xbmcplugin.setResolvedUrl(_handle, False, listitem=xbmcgui.ListItem())
            return
    
    # Create ListItem
    play_item = xbmcgui.ListItem(path=stream_url)
    
    # Set video info
    if series_title and episode_num:
        play_item.setInfo('video', {
            'title': '{} - Episode {}'.format(series_title, episode_num),
            'episode': episode_num,
            'mediatype': 'episode',
            'tvshowtitle': series_title
        })
    
    # Configure for HLS with ANTI-403 headers
    if is_hls and has_inputstream:
        xbmc.log("Turkish123: Configuring inputstream.adaptive with anti-403 headers", xbmc.LOGINFO)
        
        # Set inputstream
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        # CRITICAL: These headers prevent 403 Forbidden
        headers = (
            'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36&'
            'Referer=https://www2.turkish123.org/&'
            'Origin=https://www2.turkish123.org'
        )
        
        # Apply headers to BOTH manifest and stream segments
        play_item.setProperty('inputstream.adaptive.stream_headers', headers)
        play_item.setProperty('inputstream.adaptive.manifest_headers', headers)
        
        # Set MIME type
        play_item.setMimeType('application/vnd.apple.mpegurl')
        play_item.setContentLookup(False)
    
    elif is_hls:
        # Fallback without inputstream
        xbmc.log("Turkish123: WARNING - No inputstream.adaptive", xbmc.LOGWARNING)
        play_item.setMimeType('application/vnd.apple.mpegurl')
    
    else:
        # Direct MP4
        play_item.setMimeType('video/mp4')
    
    # Set playback properties
    play_item.setProperty('IsPlayable', 'true')
    play_item.setProperty('IsInternetStream', 'true')
    
    # Resolve URL
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    xbmc.log("Turkish123: Playback initiated", xbmc.LOGINFO)

def search_dialog():
    """Show search dialog"""
    dialog = xbmcgui.Dialog()
    query = dialog.input('Search for Series', type=xbmcgui.INPUT_ALPHANUM)
    
    if not query:
        return
    
    xbmc.log("Turkish123: User search query: {}".format(query), xbmc.LOGINFO)
    
    # Show searching progress
    progress = xbmcgui.DialogProgress()
    progress.create('Searching', 'Searching for: {}'.format(query))
    
    results = scraper.search(query)
    progress.close()
    
    if not results:
        dialog.ok('No Results', 'No series found for: {}'.format(query))
        return
    
    # Display results
    xbmcplugin.setPluginCategory(_handle, 'Search: {}'.format(query))
    xbmcplugin.setContent(_handle, 'tvshows')
    
    for result in results:
        list_item = xbmcgui.ListItem(label=result['title'])
        
        if result['cover']:
            list_item.setArt({'thumb': result['cover'], 'poster': result['cover']})
        
        list_item.setInfo('video', {
            'title': result['title'],
            'mediatype': 'tvshow'
        })
        
        url = get_url(action='episodes', series_url=result['url'], series_title=result['title'], cover=result.get('cover', ''))
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.endOfDirectory(_handle)

def show_continue_watching():
    """Display Continue Watching list"""
    xbmc.log("Turkish123: show_continue_watching", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, 'Continue Watching')
    xbmcplugin.setContent(_handle, 'episodes')
    
    continue_watching = user_data.get_continue_watching(limit=20)
    
    if not continue_watching:
        xbmcgui.Dialog().ok('Continue Watching', 'No watch history yet. Start watching some series!')
        xbmcplugin.endOfDirectory(_handle)
        return
    
    for item in continue_watching:
        series_title = item['series_title']
        last_ep = item['last_episode']
        watched = item['watched_count']
        total = item['total_episodes']
        
        # Progress indicator
        if total > 0:
            progress_pct = int((watched / total) * 100)
            label = "{} - E{} | {}%".format(series_title, last_ep, progress_pct)
        else:
            label = "{} - E{} | {} watched".format(series_title, last_ep, watched)
        
        list_item = xbmcgui.ListItem(label=label)
        
        if item['cover']:
            list_item.setArt({'thumb': item['cover'], 'poster': item['cover'], 'fanart': item['cover']})
        
        list_item.setInfo('video', {
            'title': series_title,
            'episode': last_ep,
            'mediatype': 'episode',
            'tvshowtitle': series_title
        })
        
        url = get_url(action='episodes', series_url=item['series_url'], 
                     series_title=series_title, cover=item['cover'])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.endOfDirectory(_handle)

def show_favorites():
    """Display Favorites list"""
    xbmc.log("Turkish123: show_favorites", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, 'My Favorites')
    xbmcplugin.setContent(_handle, 'tvshows')
    
    favorites = user_data.load_favorites()
    
    if not favorites:
        dialog = xbmcgui.Dialog()
        dialog.ok(
            '⭐ My Favorites',
            'You don\'t have any favorites yet![CR][CR]'
            'Browse series and add them to favorites!'
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    for fav in favorites:
        list_item = xbmcgui.ListItem(label="⭐ {}".format(fav['series_title']))
        
        if fav['cover']:
            list_item.setArt({'poster': fav['cover'], 'fanart': fav['cover']})
        
        list_item.setInfo('video', {
            'title': fav['series_title'],
            'mediatype': 'tvshow',
            'plot': 'Added: {}'.format(fav['added_date'])
        })
        
        # Context menu
        list_item.addContextMenuItems([
            ('Remove from Favorites', 'RunPlugin({})'.format(
                get_url(action='remove_favorite', series_url=fav['series_url'])
            ))
        ])
        
        url = get_url(action='episodes', series_url=fav['series_url'], 
                     series_title=fav['series_title'], cover=fav.get('cover', ''))
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def add_favorite_action(series_url, series_title, cover=""):
    """Add series to favorites"""
    success = user_data.add_favorite(series_url, series_title, cover)
    
    if success:
        xbmcgui.Dialog().notification(
            'Favorites',
            'Added to favorites!',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
    else:
        xbmcgui.Dialog().notification(
            'Favorites',
            'Already in favorites!',
            xbmcgui.NOTIFICATION_WARNING,
            2000
        )
    
    xbmc.executebuiltin('Container.Refresh')

def remove_favorite_action(series_url):
    """Remove series from favorites"""
    success = user_data.remove_favorite(series_url)
    
    if success:
        xbmcgui.Dialog().notification(
            'Favorites',
            'Removed from favorites',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
    
    xbmc.executebuiltin('Container.Refresh')

def router(paramstring):
    """Router function"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    
    if not params:
        list_series(page=1)
    elif params['action'] == 'list':
        list_series(page=int(params.get('page', 1)))
    elif params['action'] == 'episodes':
        list_episodes(
            params['series_url'],
            params.get('series_title', 'Episodes'),
            params.get('cover', '')
        )
    elif params['action'] == 'play':
        force_refresh = params.get('force_refresh', '0') == '1'
        play_video(
            params['episode_url'],
            force_refresh=force_refresh,
            series_url=params.get('series_url', ''),
            series_title=params.get('series_title', ''),
            episode_num=int(params.get('episode_num', 0)),
            total_episodes=int(params.get('total_episodes', 0)),
            cover=params.get('cover', ''),
            next_episode_url=params.get('next_episode_url', ''),
            next_episode_num=int(params.get('next_episode_num', 0)),
            next_title=params.get('next_title', '')
        )
    elif params['action'] == 'search':
        search_dialog()
    elif params['action'] == 'continue_watching':
        show_continue_watching()
    elif params['action'] == 'favorites':
        show_favorites()
    elif params['action'] == 'add_favorite':
        add_favorite_action(
            params['series_url'],
            params['series_title'],
            params.get('cover', '')
        )
    elif params['action'] == 'remove_favorite':
        remove_favorite_action(params['series_url'])
    else:
        raise ValueError('Invalid paramstring: {}'.format(paramstring))

if __name__ == '__main__':
    xbmc.log("Turkish123: Addon started", xbmc.LOGINFO)
    
    # Clean old cache
    scraper.cache.clear_old()
    
    router(sys.argv[2][1:])
