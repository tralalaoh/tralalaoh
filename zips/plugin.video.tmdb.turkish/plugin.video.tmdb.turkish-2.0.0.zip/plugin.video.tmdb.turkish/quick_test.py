#!/usr/bin/env python3
"""
Quick Test - Phase 2 Integration
Simple test to verify everything works
"""

import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))

print("="*80)
print("Quick Test - Phase 2 Integration")
print("="*80)

# Test 1: Import Engine3SK
print("\n[1] Testing Engine3SK import...")
try:
    from lib.engines.engine_3sk import Engine3SK
    print("✓ Engine3SK imported successfully")
except Exception as e:
    print(f"✗ Failed to import Engine3SK: {e}")
    sys.exit(1)

# Test 2: Initialize Engine
print("\n[2] Initializing Engine3SK...")
try:
    engine = Engine3SK()
    print(f"✓ Engine initialized: {engine.get_engine_name()}")
    print(f"  Audio language: {engine.get_audio_language()}")
    print(f"  Base URL: {engine.base_url}")
except Exception as e:
    print(f"✗ Failed to initialize: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 3: Import TMDB API
print("\n[3] Testing TMDB API import...")
try:
    from lib.tmdb_api import TMDBApi
    print("✓ TMDBApi imported successfully")
except Exception as e:
    print(f"✗ Failed to import TMDBApi: {e}")
    sys.exit(1)

# Test 4: Import ContentRouter
print("\n[4] Testing ContentRouter import...")
try:
    from lib.content_router import ContentRouter
    print("✓ ContentRouter imported successfully")
except Exception as e:
    print(f"✗ Failed to import ContentRouter: {e}")
    sys.exit(1)

# Test 5: Search test (quick)
print("\n[5] Testing 3SK search (quick test)...")
try:
    results = engine.search_series(['Test Series'])
    print(f"✓ Search function works (found {len(results)} results)")
except Exception as e:
    print(f"✗ Search failed: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*80)
print("✓✓✓ All imports and basic tests passed! ✓✓✓")
print("="*80)
print("\nYou can now run full tests:")
print("  python3 test_engine3sk.py    - Test engine only")
print("  python3 test_phase2b.py      - Test complete flow")
print("="*80)
