#!/usr/bin/env python3
"""
Standalone Test for Engine3SK
Tests engine outside of Kodi to verify stream extraction works
"""

import sys
import os

# Add lib to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))

from lib.engines.engine_3sk import Engine3SK


def test_engine():
    """Test Engine3SK functionality"""
    
    print("="*80)
    print("Testing Engine3SK")
    print("="*80)
    
    # Initialize engine
    print("\n[1] Initializing engine...")
    engine = Engine3SK()
    print(f"✓ Engine: {engine.get_engine_name()}")
    print(f"✓ Audio: {engine.get_audio_language()}")
    print(f"✓ Base URL: {engine.base_url}")
    
    # Test search
    print("\n[2] Testing search...")
    test_names = [
        'Kızılcık Şerbeti',
        'Cranberry Sorbet',
        'مربى الكشمش'
    ]
    
    results = engine.search_series(test_names)
    print(f"✓ Found {len(results)} results")
    
    if len(results) > 0:
        print(f"\nFirst 5 results:")
        for i, result in enumerate(results[:5], 1):
            print(f"  {i}. {result['title']}")
            print(f"     Season: {result.get('season')}, Episode: {result.get('episode')}")
            print(f"     URL: {result['episode_url'][:60]}...")
    
    # Test episode finding
    if len(results) > 0:
        print("\n[3] Testing episode URL extraction...")
        
        # Try to find first episode
        first_result = results[0]
        season = first_result.get('season')
        episode = first_result.get('episode')
        
        if season and episode:
            print(f"   Looking for S{season:02d}E{episode:02d}...")
            episode_url = engine.get_episode_url(results, season, episode)
            
            if episode_url:
                print(f"✓ Found episode URL: {episode_url[:60]}...")
                
                # Test stream extraction
                print("\n[4] Testing stream extraction...")
                print("   This may take 10-20 seconds (testing servers)...")
                
                streams = engine.get_stream_url(episode_url)
                
                if streams:
                    print(f"✓ Found {len(streams)} working stream(s)!")
                    for stream in streams:
                        print(f"   • {stream['name']}: {stream['quality']}")
                        print(f"     {stream['url'][:80]}...")
                else:
                    print("✗ No working streams found")
            else:
                print("✗ Episode URL not found")
        else:
            print("✗ Cannot extract season/episode from title")
    
    # Cache stats
    print("\n[5] Cache Statistics:")
    stats = engine.cache.get_stats()
    print(f"   Server hits: {stats['server_hits']}")
    print(f"   Server misses: {stats['server_misses']}")
    print(f"   Hit rate: {stats['hit_rate']:.1f}%")
    print(f"   Cache size: {stats['cache_size']}")
    
    print("\n" + "="*80)
    print("Test Complete!")
    print("="*80)


if __name__ == "__main__":
    try:
        test_engine()
    except KeyboardInterrupt:
        print("\n\nTest interrupted by user")
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
