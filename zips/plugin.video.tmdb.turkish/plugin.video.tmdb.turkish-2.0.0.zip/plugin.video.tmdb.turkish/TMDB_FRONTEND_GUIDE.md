# TMDB Frontend Integration - User Always Sees TMDB

## 🎯 Your Question

**"User always see TMDB on front end, even in episode page"**

**Answer:** YES! Users see beautiful TMDB metadata everywhere, but we stream from 3SK in the background.

---

## 🎨 Frontend Architecture

```
USER SEES (TMDB):                  BACKEND DOES (3SK):
┌─────────────────────┐           ┌──────────────────────┐
│  Love Is in the Air │           │ Search 3SK for:      │
│  ★★★★★ 8.2/10      │           │ "أطرق بابي"          │
│                     │           │                      │
│  [Poster Image]     │           │ Build virtual folder │
│                     │           │ Cache to SQLite      │
│  Turkish romantic   │           └──────────────────────┘
│  comedy series...   │
│                     │
│  Season 1 (52 eps)  │
│  Season 2 (13 eps)  │
└─────────────────────┘

USER CLICKS EPISODE 5:            BACKEND DOES:
┌─────────────────────┐           ┌──────────────────────┐
│  Episode 5          │           │ Get URL from cache:  │
│  "You Knock on      │           │ https://x.esheaq...  │
│   My Door"          │           │                      │
│                     │           │ Scrape servers       │
│  First air: 2020    │           │ Test OK.RU, Vidoba   │
│  Duration: 120 min  │           │ Return stream URL    │
│                     │           └──────────────────────┘
│  [Episode Poster]   │
│                     │
│  Eda and Serkan...  │
│                     │
│  [▶ PLAY]           │
└─────────────────────┘
```

**Key Principle:** 
- **Frontend = 100% TMDB** (beautiful, accurate, multilingual)
- **Backend = 3SK/Turkish123** (actual video streams)

---

## 📋 Complete Data Flow

### Step 1: User Searches "Sen Çal Kapımı"

**Frontend Shows (TMDB):**
```python
# Kodi shows search results from TMDB
series_list = tmdb.search_series("Sen Çal Kapımı")

for series in series_list:
    list_item = xbmcgui.ListItem(label=series['name'])
    list_item.setArt({
        'poster': series['poster'],      # TMDB poster
        'fanart': series['fanart']       # TMDB backdrop
    })
    list_item.setInfo('video', {
        'title': series['name'],          # TMDB title
        'plot': series['overview'],       # TMDB description
        'rating': series['vote_average'], # TMDB rating
        'year': series['year'],           # TMDB year
        'genre': series['genres']         # TMDB genres
    })
```

**User Sees:**
```
┌──────────────────────────────────┐
│ Love Is in the Air (2020)       │
│ ★★★★★ 8.2/10                    │
│ [Beautiful TMDB Poster]          │
│ Turkish romantic comedy series   │
│ about a landscape architect...   │
└──────────────────────────────────┘
```

### Step 2: User Clicks Series → See Episodes

**Frontend Shows (TMDB):**
```python
# Get series details from TMDB
metadata = tmdb.get_series_details(tmdb_id=104877)

# Show series info with TMDB metadata
series_name = metadata['name']           # "Love Is in the Air"
series_plot = metadata['overview']       # TMDB description
series_poster = metadata['poster_path']  # TMDB poster
num_seasons = len(metadata['seasons'])   # 2 seasons

# Get episodes for Season 1
season_data = tmdb.get_season_details(tmdb_id=104877, season=1)

for episode in season_data['episodes']:
    list_item = xbmcgui.ListItem(label=episode['name'])  # TMDB episode name!
    list_item.setArt({
        'thumb': episode['still_path']   # TMDB episode screenshot
    })
    list_item.setInfo('video', {
        'title': episode['name'],         # TMDB: "You Knock on My Door"
        'plot': episode['overview'],      # TMDB: Episode description
        'episode': episode['episode_number'],
        'season': episode['season_number'],
        'aired': episode['air_date'],     # TMDB air date
        'duration': episode['runtime']    # TMDB duration
    })
```

**User Sees:**
```
Love Is in the Air - Season 1
[TMDB Fanart Background]

1. You Knock on My Door
   First aired: 2020-07-08 | 120 min
   [Episode Screenshot]
   Eda Yıldız is a young and bright...

2. Episode 2
   First aired: 2020-07-15 | 120 min
   [Episode Screenshot]
   Serkan and Eda continue their...

3. Episode 3
   ...
```

**Backend Does (Hidden from User):**
```python
# In background, build 3SK virtual folder
episodes_3sk = router.get_episodes(tmdb_id=104877)
# → Searches 3SK for "أطرق بابي"
# → Builds virtual folder with Arabic episode URLs
# → Caches to SQLite

# Stored in cache:
# {
#   'episodes': [
#     {'title': 'مسلسل انت اطرق بابي الحلقة 1', 'url': 'https://x.esheaq.onl/watch/xxx/', 'episode_number': 1},
#     {'title': 'مسلسل انت اطرق بابي الحلقة 2', 'url': 'https://x.esheaq.onl/watch/yyy/', 'episode_number': 2},
#     ...
#   ]
# }
```

### Step 3: User Clicks Episode 5 to Watch

**Frontend Shows (TMDB):**
```python
# Episode info from TMDB
episode_info = tmdb.get_episode_details(tmdb_id=104877, season=1, episode=5)

# Show in player
play_item.setInfo('video', {
    'title': episode_info['name'],        # TMDB: "Episode 5"
    'plot': episode_info['overview'],     # TMDB: Description
    'tvshowtitle': 'Love Is in the Air',  # TMDB: Series name
    'season': 1,
    'episode': 5,
    'duration': episode_info['runtime']   # TMDB: 120 minutes
})
```

**Backend Does (Hidden):**
```python
# Get stream from 3SK
result = router.play_episode(tmdb_id=104877, season=1, episode=5)

# What happens:
# 1. Load Episode 5 URL from SQLite cache:
#    'https://x.esheaq.onl/watch/5ltj5wpq4j/'
#
# 2. Scrape servers for Episode 5:
#    - Test OK.RU
#    - Test Vidoba
#    - Return working stream
#
# 3. Return stream URL:
#    'https://okcdn.ru/video/123456.m3u8'
```

**User Sees During Playback:**
```
Now Playing:
Love Is in the Air - S01E05
"Episode 5"

[Video Player with TMDB metadata overlay]
Duration: 1:59:23 / 2:00:00

[TMDB episode screenshot as thumbnail]
```

---

## 💻 Complete Kodi Implementation

### main.py - Shows TMDB Everywhere

```python
# -*- coding: utf-8 -*-
"""
Main Kodi Addon Entry Point
User sees 100% TMDB metadata
Backend uses 3SK/Turkish123 for streams
"""

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from lib.tmdb_api import TMDBApi
from lib.content_router import ContentRouter

# Initialize
addon = xbmcaddon.Addon()
handle = int(sys.argv[1])

# TMDB API (for frontend metadata)
tmdb = TMDBApi(
    api_key=addon.getSetting('tmdb_api_key'),
    language='en'  # or user's language preference
)

# Content Router (for backend streaming)
router = ContentRouter(
    tmdb_api=tmdb,
    settings=addon,
    cache_dir=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
)


def search_series(query):
    """
    Search and show results
    USER SEES: TMDB metadata only
    """
    xbmcplugin.setPluginCategory(handle, f'Search: {query}')
    xbmcplugin.setContent(handle, 'tvshows')
    
    # Search TMDB
    results = tmdb.search_series(query)
    
    for series in results:
        # Create list item with TMDB metadata
        list_item = xbmcgui.ListItem(label=series['name'])
        
        # TMDB artwork
        list_item.setArt({
            'poster': tmdb.get_image_url(series.get('poster_path')),
            'fanart': tmdb.get_image_url(series.get('backdrop_path'))
        })
        
        # TMDB metadata
        list_item.setInfo('video', {
            'title': series['name'],
            'originaltitle': series.get('original_name'),
            'plot': series.get('overview', 'No description available'),
            'rating': series.get('vote_average', 0),
            'votes': series.get('vote_count', 0),
            'year': int(series.get('first_air_date', '0000')[:4]) if series.get('first_air_date') else 0,
            'genre': ', '.join(series.get('genres', [])),
            'mediatype': 'tvshow'
        })
        
        # When clicked, show episodes
        url = build_url({'action': 'episodes', 'tmdb_id': series['id']})
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    
    xbmcplugin.endOfDirectory(handle)


def list_episodes(tmdb_id):
    """
    Show episode list
    USER SEES: TMDB episode names, descriptions, screenshots
    BACKEND: Builds 3SK virtual folder (hidden from user)
    """
    # Get TMDB metadata for display
    series_metadata = tmdb.get_series_details(tmdb_id)
    season_data = tmdb.get_season_details(tmdb_id, season=1)  # or user's selected season
    
    xbmcplugin.setPluginCategory(handle, series_metadata['name'])
    xbmcplugin.setContent(handle, 'episodes')
    
    # Backend: Build 3SK virtual folder (cached)
    # This happens in background, user doesn't see it
    episodes_3sk = router.get_episodes(tmdb_id)
    
    if not episodes_3sk:
        xbmcgui.Dialog().notification('Error', 'Episodes not available', xbmcgui.NOTIFICATION_ERROR)
        return
    
    # Show episodes with TMDB metadata
    for tmdb_episode in season_data['episodes']:
        episode_num = tmdb_episode['episode_number']
        
        # Create list item with TMDB metadata
        label = f"{episode_num}. {tmdb_episode['name']}"
        list_item = xbmcgui.ListItem(label=label)
        
        # TMDB artwork
        list_item.setArt({
            'thumb': tmdb.get_image_url(tmdb_episode.get('still_path')),
            'fanart': tmdb.get_image_url(series_metadata.get('backdrop_path'))
        })
        
        # TMDB metadata
        list_item.setInfo('video', {
            'title': tmdb_episode['name'],          # TMDB episode title!
            'plot': tmdb_episode.get('overview', 'No description'),  # TMDB description!
            'episode': episode_num,
            'season': 1,
            'tvshowtitle': series_metadata['name'],
            'aired': tmdb_episode.get('air_date'),
            'duration': tmdb_episode.get('runtime', 0) * 60,  # seconds
            'rating': tmdb_episode.get('vote_average', 0),
            'mediatype': 'episode'
        })
        
        list_item.setProperty('IsPlayable', 'true')
        
        # When clicked, play episode (backend uses 3SK)
        url = build_url({
            'action': 'play',
            'tmdb_id': tmdb_id,
            'season': 1,
            'episode': episode_num
        })
        
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(handle)


def play_episode(tmdb_id, season, episode):
    """
    Play episode
    USER SEES: TMDB metadata in player
    BACKEND: Gets stream from 3SK
    """
    # Get TMDB metadata for player display
    series_metadata = tmdb.get_series_details(tmdb_id)
    episode_metadata = tmdb.get_episode_details(tmdb_id, season, episode)
    
    # Show progress
    progress = xbmcgui.DialogProgress()
    progress.create('Loading', f'Finding stream for {episode_metadata["name"]}...')
    
    # BACKEND: Get stream from 3SK (hidden from user)
    result = router.play_episode(tmdb_id, season, episode)
    
    progress.close()
    
    if not result:
        xbmcgui.Dialog().notification(
            'Playback Error',
            'No stream found. Try again later.',
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    
    # Create playable item with TMDB metadata
    play_item = xbmcgui.ListItem(path=result['stream_url'])
    
    # TMDB artwork in player
    play_item.setArt({
        'thumb': tmdb.get_image_url(episode_metadata.get('still_path')),
        'fanart': tmdb.get_image_url(series_metadata.get('backdrop_path'))
    })
    
    # TMDB metadata in player
    play_item.setInfo('video', {
        'title': episode_metadata['name'],           # TMDB title in player!
        'plot': episode_metadata.get('overview'),    # TMDB description!
        'episode': episode,
        'season': season,
        'tvshowtitle': series_metadata['name'],      # TMDB series name!
        'duration': episode_metadata.get('runtime', 0) * 60,
        'rating': episode_metadata.get('vote_average', 0),
        'mediatype': 'episode'
    })
    
    play_item.setProperty('IsPlayable', 'true')
    
    # Start playback
    xbmcplugin.setResolvedUrl(handle, True, play_item)
    
    # Log what happened (for debugging)
    xbmc.log(f"Playing: {series_metadata['name']} S{season:02d}E{episode:02d}", xbmc.LOGINFO)
    xbmc.log(f"  TMDB Title: {episode_metadata['name']}", xbmc.LOGINFO)
    xbmc.log(f"  Stream from: {result['engine'].upper()}", xbmc.LOGINFO)
    xbmc.log(f"  Stream URL: {result['stream_url'][:60]}...", xbmc.LOGINFO)


def build_url(params):
    """Build plugin URL"""
    return f"{sys.argv[0]}?{urllib.parse.urlencode(params)}"


def router(paramstring):
    """Route to appropriate function"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    
    if not params:
        # Main menu
        show_main_menu()
    elif params['action'] == 'search':
        query = xbmcgui.Dialog().input('Search Series', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_series(query)
    elif params['action'] == 'episodes':
        list_episodes(int(params['tmdb_id']))
    elif params['action'] == 'play':
        play_episode(
            int(params['tmdb_id']),
            int(params['season']),
            int(params['episode'])
        )


if __name__ == '__main__':
    router(sys.argv[2][1:])
```

---

## 📊 Data Mapping

### Series Level

| What User Sees (TMDB) | Backend Has (3SK) |
|----------------------|-------------------|
| "Love Is in the Air" | "مسلسل انت اطرق بابي" |
| English description | Arabic episode titles |
| TMDB poster | 3SK episode URLs |
| 8.2/10 rating | Cached virtual folder |
| 2 seasons, 65 episodes | 52 episodes found |

### Episode Level

| What User Sees (TMDB) | Backend Has (3SK) |
|----------------------|-------------------|
| "Episode 5" | "مسلسل انت اطرق بابي الحلقة 5" |
| "You Knock on My Door" | `https://x.esheaq.onl/watch/xxx/` |
| Episode screenshot | Server list (OK.RU, Vidoba...) |
| Air date: 2020-08-05 | Stream URL when playing |

---

## ✅ Benefits of TMDB Frontend

**For Users:**
- ✅ Beautiful, professional UI
- ✅ Accurate metadata in their language
- ✅ High-quality posters and screenshots
- ✅ Episode descriptions and ratings
- ✅ Consistent experience across all content

**For You:**
- ✅ Don't need to scrape metadata from 3SK
- ✅ Don't worry about Arabic/Turkish translations
- ✅ TMDB has better artwork
- ✅ TMDB updates automatically
- ✅ Clean separation: TMDB=frontend, 3SK=backend

---

## 🎯 Summary

**User Experience:**
```
User searches "Sen Çal Kapımı"
  → Sees TMDB results with beautiful posters
  → Clicks series
  → Sees TMDB episode list with English titles
  → Clicks Episode 5
  → Sees "Episode 5: You Knock on My Door" with TMDB metadata
  → Presses play
  → Stream comes from 3SK (user doesn't know or care!)
```

**Backend Flow:**
```
Search request
  → TMDB API: Get series list (for display)
  
View episodes
  → TMDB API: Get episode metadata (for display)
  → 3SK: Build virtual folder (cached, for streaming)
  
Play episode
  → TMDB API: Get episode metadata (for player)
  → 3SK: Get stream URL (from cache + on-demand scraping)
```

**Key Principle:**
- Frontend = 100% TMDB (what user sees)
- Backend = 3SK/Turkish123 (where streams come from)
- User never sees 3SK Arabic titles or metadata
- User enjoys beautiful TMDB experience!

---

**Version:** Phase 2C  
**Integration:** TMDB Frontend + 3SK Backend  
**Result:** Best of both worlds!
