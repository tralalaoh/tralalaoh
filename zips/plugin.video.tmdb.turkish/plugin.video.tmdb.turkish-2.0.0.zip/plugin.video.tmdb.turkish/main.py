# -*- coding: utf-8 -*-
"""
Turkish Series (TMDB) - Main Entry Point
PHASE 2C: TMDB Frontend + 3SK Backend with SQLite Caching

Architecture:
- Frontend: Beautiful TMDB metadata (English titles, descriptions, posters)
- Backend: 3SK streaming with SQLite episode caching
- Performance: ~44,500x faster after first load
"""

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Import TMDB API and Content Router
from lib.tmdb_api import TMDBApi
from lib.content_router import ContentRouter

# ==============================================================================
# CONFIGURATION
# ==============================================================================

_handle = int(sys.argv[1])
_url = sys.argv[0]
addon = xbmcaddon.Addon()

# Initialize TMDB API (for beautiful frontend metadata)
api_key = addon.getSetting('tmdb_api_key')
metadata_language = addon.getSetting('tmdb_language') or 'en'

if not api_key:
    xbmc.log("Turkish TMDB: No API key configured!", xbmc.LOGERROR)
    api_key = "c8578981f94591042c8a9b9837571314"  # Default key

tmdb = TMDBApi(api_key, metadata_language)

# Initialize Content Router with SQLite caching
cache_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
content_router = ContentRouter(tmdb, addon, cache_dir=cache_dir)

# Settings
items_per_page = int(addon.getSetting('items_per_page') or '20')
enable_debug = addon.getSetting('enable_debug') == 'true'
airing_days_back = int(addon.getSetting('airing_days_back') or '30')

# ==============================================================================
# UTILITY FUNCTIONS
# ==============================================================================

def get_url(**kwargs):
    """Create plugin URL"""
    return '{}?{}'.format(_url, urllib.parse.urlencode(kwargs))

def log(message, level=xbmc.LOGINFO):
    """Log message"""
    if level == xbmc.LOGDEBUG and not enable_debug:
        return
    xbmc.log(f"Turkish TMDB: {message}", level)

# ==============================================================================
# MAIN MENU
# ==============================================================================

def show_main_menu():
    """Show main category menu"""
    log("Showing main menu", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, 'Turkish Series')
    xbmcplugin.setContent(_handle, 'tvshows')
    
    # Categories
    categories = [
        {
            'label': '[COLOR yellow]Popular Turkish Series[/COLOR]',
            'action': 'popular',
            'icon': 'DefaultTVShows.png',
            'description': 'Most popular Turkish series on TMDB'
        },
        {
            'label': '[COLOR cyan]New Series (2024+)[/COLOR]',
            'action': 'airing',
            'icon': 'DefaultRecentlyAddedEpisodes.png',
            'description': 'Turkish series currently airing'
        },
        {
            'label': '[COLOR orange]Discover[/COLOR]',
            'action': 'discover',
            'icon': 'DefaultMovies.png',
            'description': 'Discover Turkish series by genre and year'
        },
        {
            'label': '[COLOR white]Search[/COLOR]',
            'action': 'search',
            'icon': 'DefaultAddonsSearch.png',
            'description': 'Search for Turkish series'
        }
    ]
    
    for cat in categories:
        list_item = xbmcgui.ListItem(label=cat['label'])
        list_item.setArt({'icon': cat['icon']})
        list_item.setInfo('video', {
            'title': cat['label'],
            'plot': cat['description']
        })
        
        url = get_url(action=cat['action'], page=1)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.endOfDirectory(_handle)

# ==============================================================================
# SERIES LISTING (TMDB Frontend)
# ==============================================================================

def list_popular_series(page=1):
    """
    Show popular Turkish series
    USER SEES: TMDB metadata (English titles, posters, ratings)
    """
    log(f"Listing popular series (page {page})", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, 'Popular Turkish Series')
    xbmcplugin.setContent(_handle, 'tvshows')
    
    # Get popular Turkish series from TMDB
    results = tmdb.get_popular_turkish(page=page)
    
    if not results:
        xbmcgui.Dialog().notification(
            'Turkish Series',
            'No series found',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    # Show each series with TMDB metadata
    for series in results:
        add_series_item(series)
    
    # Next page
    list_item = xbmcgui.ListItem(label='[COLOR yellow]>>> Next Page >>>[/COLOR]')
    list_item.setArt({'icon': 'DefaultFolder.png'})
    url = get_url(action='popular', page=page + 1)
    xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.endOfDirectory(_handle)

def list_airing_series(page=1):
    """
    Show currently airing Turkish series
    USER SEES: TMDB metadata
    """
    log(f"Listing airing series (page {page})", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, 'Currently Airing')
    xbmcplugin.setContent(_handle, 'tvshows')
    
    # Get airing Turkish series from TMDB
    results = tmdb.get_airing_turkish(days_back=airing_days_back, page=page)
    
    if not results:
        xbmcgui.Dialog().notification(
            'Turkish Series',
            'No airing series found',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    # Show each series with TMDB metadata
    for series in results:
        add_series_item(series)
    
    # Next page
    list_item = xbmcgui.ListItem(label='[COLOR yellow]>>> Next Page >>>[/COLOR]')
    list_item.setArt({'icon': 'DefaultFolder.png'})
    url = get_url(action='airing', page=page + 1)
    xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.endOfDirectory(_handle)

def list_discover_series(page=1):
    """
    Show top-rated Turkish series (Discover category)
    Based on YOUR popular_discover.py - Top Rated with 50+ votes
    
    USER SEES: Highly rated Turkish dramas
    """
    log(f"Listing discover series (page {page})", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, 'Discover: Top Rated')
    xbmcplugin.setContent(_handle, 'tvshows')
    
    # Get discover results from TMDB (Top Rated with 50+ votes)
    discover_data = tmdb.get_discover(page=page)
    
    if not discover_data or 'results' not in discover_data:
        xbmcgui.Dialog().notification(
            'Turkish Series',
            'No series found',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    results = discover_data['results']
    
    if not results:
        xbmcgui.Dialog().notification(
            'Discover',
            'No top-rated series found',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    # Show each series with TMDB metadata
    for series in results:
        add_series_item(series)
    
    # Next page
    list_item = xbmcgui.ListItem(label='[COLOR yellow]>>> Next Page >>>[/COLOR]')
    list_item.setArt({'icon': 'DefaultFolder.png'})
    url = get_url(action='discover', page=page + 1)
    xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    
    xbmcplugin.endOfDirectory(_handle)

def search_series():
    """
    Search for series
    USER SEES: TMDB search results
    """
    # Show keyboard
    keyboard = xbmc.Keyboard('', 'Search for Turkish Series')
    keyboard.doModal()
    
    if not keyboard.isConfirmed():
        return
    
    query = keyboard.getText()
    if not query:
        return
    
    log(f"Searching for: {query}", xbmc.LOGINFO)
    
    xbmcplugin.setPluginCategory(_handle, f'Search: {query}')
    xbmcplugin.setContent(_handle, 'tvshows')
    
    # Search TMDB
    results = tmdb.search_series(query)
    
    if not results:
        xbmcgui.Dialog().notification(
            'Search',
            f'No results for "{query}"',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    # Show results with TMDB metadata
    for series in results:
        add_series_item(series)
    
    xbmcplugin.endOfDirectory(_handle)

def add_series_item(series):
    """
    Add series item to directory
    USER SEES: Beautiful TMDB metadata
    BACKEND: Will cache episodes when user clicks
    
    Args:
        series (dict): TMDB series data
    """
    tmdb_id = series['id']
    
    # Create list item with TMDB metadata
    label = series['name']
    list_item = xbmcgui.ListItem(label=label)
    
    # TMDB artwork
    poster = tmdb.get_image_url(series.get('poster_path'))
    fanart = tmdb.get_image_url(series.get('backdrop_path'))
    
    list_item.setArt({
        'poster': poster,
        'fanart': fanart,
        'thumb': poster
    })
    
    # TMDB metadata
    year = 0
    if series.get('first_air_date'):
        try:
            year = int(series['first_air_date'][:4])
        except:
            pass
    
    list_item.setInfo('video', {
        'title': series['name'],
        'originaltitle': series.get('original_name', ''),
        'plot': series.get('overview', 'No description available'),
        'rating': series.get('vote_average', 0),
        'votes': series.get('vote_count', 0),
        'year': year,
        'mediatype': 'tvshow',
        'genre': ', '.join(series.get('genres', []))
    })
    
    # Context menu
    context_menu = [
        (
            'Series Information',
            'Action(Info)'
        ),
        (
            'Refresh Cache',
            f'RunPlugin({get_url(action="refresh_cache", tmdb_id=tmdb_id)})'
        )
    ]
    list_item.addContextMenuItems(context_menu)
    
    # When clicked, show episodes
    url = get_url(action='episodes', tmdb_id=tmdb_id)
    xbmcplugin.addDirectoryItem(_handle, url, list_item, True)

# ==============================================================================
# EPISODE LISTING (TMDB Frontend + 3SK Backend Cache)
# ==============================================================================

def list_episodes(tmdb_id):
    """
    Show episode list with seasons
    USER SEES: TMDB episode metadata (English titles, descriptions, screenshots)
    BACKEND: Builds 3SK virtual folder and caches to SQLite
    
    This is where the magic happens:
    1. First time: Scrapes 3SK landing page, caches to SQLite (~4 seconds)
    2. Next time: Loads from SQLite cache (instant!)
    """
    log(f"Listing episodes for TMDB {tmdb_id}", xbmc.LOGINFO)
    
    # Get series metadata from TMDB
    series_metadata = tmdb.get_series_details(tmdb_id)
    
    if not series_metadata:
        xbmcgui.Dialog().notification(
            'Error',
            'Series not found on TMDB',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    xbmcplugin.setPluginCategory(_handle, series_metadata['name'])
    xbmcplugin.setContent(_handle, 'episodes')
    
    # BACKEND: Build/load 3SK virtual folder (CACHED!)
    # First time: ~4 seconds (scraping)
    # Next time: ~0.0001 seconds (from cache!)
    log("Getting episodes from backend (cached if available)...", xbmc.LOGDEBUG)
    episodes_3sk = content_router.get_episodes(tmdb_id)
    
    if not episodes_3sk:
        xbmcgui.Dialog().notification(
            'Episodes Not Available',
            'This series is not available for streaming',
            xbmcgui.NOTIFICATION_WARNING,
            5000
        )
        xbmcplugin.endOfDirectory(_handle)
        return
    
    log(f"Backend: {episodes_3sk['total_episodes']} episodes cached", xbmc.LOGINFO)
    
    # Get seasons from TMDB
    seasons = series_metadata.get('seasons', [])
    
    if not seasons:
        # No season data, show episodes directly
        show_season_episodes(tmdb_id, 1, series_metadata, episodes_3sk)
        return
    
    # Show seasons (if more than 1 season)
    if len(seasons) > 1:
        for season in seasons:
            season_num = season['season_number']
            
            # Skip season 0 (specials)
            if season_num == 0:
                continue
            
            label = f"Season {season_num} ({season.get('episode_count', 0)} episodes)"
            list_item = xbmcgui.ListItem(label=label)
            
            # Season poster
            season_poster = tmdb.get_image_url(season.get('poster_path'))
            if season_poster:
                list_item.setArt({'poster': season_poster, 'thumb': season_poster})
            
            list_item.setInfo('video', {
                'title': label,
                'plot': season.get('overview', ''),
                'season': season_num,
                'mediatype': 'season'
            })
            
            url = get_url(action='season', tmdb_id=tmdb_id, season=season_num)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    else:
        # Only one season, show episodes directly
        show_season_episodes(tmdb_id, 1, series_metadata, episodes_3sk)
    
    xbmcplugin.endOfDirectory(_handle)

def show_season_episodes(tmdb_id, season, series_metadata=None, episodes_3sk=None):
    """
    Show episodes for a specific season
    USER SEES: TMDB episode metadata (titles, descriptions, screenshots)
    BACKEND: Episode URLs already cached in SQLite
    
    Args:
        tmdb_id (int): TMDB series ID
        season (int): Season number
        series_metadata (dict): TMDB series metadata (optional, will fetch if not provided)
        episodes_3sk (dict): Cached 3SK episodes (optional, will fetch if not provided)
    """
    log(f"Showing season {season} episodes for TMDB {tmdb_id}", xbmc.LOGINFO)
    
    # Get series metadata if not provided
    if not series_metadata:
        series_metadata = tmdb.get_series_details(tmdb_id)
        if not series_metadata:
            xbmcgui.Dialog().notification('Error', 'Series not found', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle)
            return
    
    # Get 3SK episodes if not provided (from cache!)
    if not episodes_3sk:
        episodes_3sk = content_router.get_episodes(tmdb_id)
        if not episodes_3sk:
            xbmcgui.Dialog().notification('Error', 'Episodes not available', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle)
            return
    
    xbmcplugin.setPluginCategory(_handle, f"{series_metadata['name']} - Season {season}")
    xbmcplugin.setContent(_handle, 'episodes')
    
    # Get TMDB episode metadata for this season
    season_data = tmdb.get_season_details(tmdb_id, season)
    
    if not season_data:
        xbmcgui.Dialog().notification('Error', f'Season {season} not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)
        return
    
    # Show each episode with TMDB metadata
    for tmdb_episode in season_data['episodes']:
        episode_num = tmdb_episode['episode_number']
        
        # Check if episode is available in 3SK cache
        episode_available = any(
            ep['episode_number'] == episode_num and ep.get('season', 1) == season
            for ep in episodes_3sk['episodes']
        )
        
        # Create label with TMDB episode title
        label = f"{episode_num}. {tmdb_episode['name']}"
        
        # Add indicator if not available
        if not episode_available:
            label = f"[COLOR gray]{label} (Not Available)[/COLOR]"
        
        list_item = xbmcgui.ListItem(label=label)
        
        # TMDB artwork
        still = tmdb.get_image_url(tmdb_episode.get('still_path'))
        fanart = tmdb.get_image_url(series_metadata.get('backdrop_path'))
        
        list_item.setArt({
            'thumb': still if still else fanart,
            'fanart': fanart
        })
        
        # TMDB metadata
        runtime = tmdb_episode.get('runtime') or 0  # Handle None
        list_item.setInfo('video', {
            'title': tmdb_episode['name'],
            'plot': tmdb_episode.get('overview', 'No description available'),
            'episode': episode_num,
            'season': season,
            'tvshowtitle': series_metadata['name'],
            'aired': tmdb_episode.get('air_date', ''),
            'duration': runtime * 60,  # Convert to seconds
            'rating': tmdb_episode.get('vote_average', 0),
            'mediatype': 'episode'
        })
        
        if episode_available:
            list_item.setProperty('IsPlayable', 'true')
            
            # Context menu
            context_menu = [
                (
                    'Episode Information',
                    'Action(Info)'
                ),
                (
                    'Force Refresh Stream',
                    f'RunPlugin({get_url(action="play", tmdb_id=tmdb_id, season=season, episode=episode_num, force_refresh="1")})'
                )
            ]
            list_item.addContextMenuItems(context_menu)
            
            # When clicked, play episode (streams scraped on-demand!)
            url = get_url(action='play', tmdb_id=tmdb_id, season=season, episode=episode_num)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
        else:
            # Not available - just show as directory item (can't play)
            url = get_url(action='not_available')
            xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    
    xbmcplugin.endOfDirectory(_handle)

# ==============================================================================
# PLAYBACK (TMDB Metadata + 3SK Stream - ON-DEMAND!)
# ==============================================================================

def play_episode(tmdb_id, season, episode, force_refresh=False):
    """
    Play episode with ON-DEMAND stream scraping
    USER SEES: TMDB metadata in player
    BACKEND: Scrapes 3SK servers ONLY when playing (on-demand!)
    
    Flow:
    1. Get episode URL from SQLite cache (instant!)
    2. Scrape servers for this episode only (5-10 seconds)
    3. Return stream and play
    
    Args:
        tmdb_id (int): TMDB series ID
        season (int): Season number  
        episode (int): Episode number
        force_refresh (bool): Force refresh stream servers
    """
    log(f"Playing: TMDB {tmdb_id} S{season:02d}E{episode:02d}", xbmc.LOGINFO)
    
    # Get TMDB metadata for player display
    series_metadata = tmdb.get_series_details(tmdb_id)
    episode_metadata = tmdb.get_episode_details(tmdb_id, season, episode)
    
    if not series_metadata or not episode_metadata:
        xbmcgui.Dialog().notification(
            'Error',
            'Episode metadata not found',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
        return
    
    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create(
        'Loading Stream',
        f"{series_metadata['name']}\nS{season:02d}E{episode:02d}: {episode_metadata['name']}"
    )
    
    try:
        # BACKEND: Get stream from 3SK (on-demand scraping!)
        # This is where servers are scraped (ONLY when playing!)
        log("Backend: Scraping stream on-demand...", xbmc.LOGINFO)
        result = content_router.play_episode(tmdb_id, season, episode)
        
        progress.close()
        
        if not result:
            xbmcgui.Dialog().notification(
                'Playback Error',
                'No working stream found. Try again later.',
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
        
        log(f"Backend: Stream found from {result.get('engine', 'unknown')}", xbmc.LOGINFO)
        log(f"Backend: Quality: {result.get('quality', 'unknown')}", xbmc.LOGINFO)
        
        # Create playable item with TMDB metadata
        stream_url = result['stream_url']
        engine = result.get('engine', 'unknown')
        
        # For HLS streams, add required headers to prevent 403 errors
        if '.m3u8' in stream_url.lower():
            # Choose headers based on which engine provided the stream
            if engine == 'turkish123':
                # Turkish123 (Tukipasti/Dwish) specific headers
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://www2.turkish123.org/',
                    'Origin': 'https://www2.turkish123.org',
                    'Accept': '*/*'
                }
                log(f"Using Turkish123 headers for HLS stream", xbmc.LOGINFO)
            elif engine == '3sk':
                # 3SK specific headers - MUST include Referer to esheaq.onl
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer': 'https://x.esheaq.onl/',
                    'Accept': '*/*'
                }
                log(f"Using 3SK headers for HLS stream", xbmc.LOGINFO)
            else:
                # Generic fallback headers
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': '*/*'
                }
                log(f"Using generic headers for {engine} HLS stream", xbmc.LOGINFO)
            
            # Format headers for Kodi (key=value pairs separated by &)
            header_string = '&'.join([f'{k}={v}' for k, v in headers.items()])
            stream_url_with_headers = f"{stream_url}|{header_string}"
            
            play_item = xbmcgui.ListItem(path=stream_url_with_headers)
            
            # Enable inputstream.adaptive for HLS
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
            log(f"HLS stream with headers: {stream_url[:100]}...", xbmc.LOGINFO)
        else:
            play_item = xbmcgui.ListItem(path=stream_url)
        
        # TMDB artwork in player
        still = tmdb.get_image_url(episode_metadata.get('still_path'))
        fanart = tmdb.get_image_url(series_metadata.get('backdrop_path'))
        poster = tmdb.get_image_url(series_metadata.get('poster_path'))
        
        play_item.setArt({
            'thumb': still if still else poster,
            'fanart': fanart,
            'poster': poster
        })
        
        # TMDB metadata in player
        runtime = episode_metadata.get('runtime') or 0  # Handle None
        play_item.setInfo('video', {
            'title': episode_metadata['name'],
            'plot': episode_metadata.get('overview', ''),
            'episode': episode,
            'season': season,
            'tvshowtitle': series_metadata['name'],
            'duration': runtime * 60,
            'rating': episode_metadata.get('vote_average', 0),
            'year': int(series_metadata.get('first_air_date', '0000')[:4]) if series_metadata.get('first_air_date') else 0,
            'mediatype': 'episode'
        })
        
        play_item.setProperty('IsPlayable', 'true')
        
        # Set video info for better player experience
        if '.m3u8' in stream_url.lower():
            play_item.setMimeType('application/vnd.apple.mpegurl')
            play_item.setContentLookup(False)
        
        # Start playback
        xbmcplugin.setResolvedUrl(_handle, True, play_item)
        
        log("Playback started successfully", xbmc.LOGINFO)
        
    except Exception as e:
        progress.close()
        log(f"Playback error: {e}", xbmc.LOGERROR)
        import traceback
        log(traceback.format_exc(), xbmc.LOGERROR)
        
        xbmcgui.Dialog().notification(
            'Playback Error',
            str(e),
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

# ==============================================================================
# CACHE MANAGEMENT
# ==============================================================================

def refresh_cache(tmdb_id):
    """
    Force refresh cache for a series
    
    Args:
        tmdb_id (int): TMDB series ID
    """
    log(f"Refreshing cache for TMDB {tmdb_id}", xbmc.LOGINFO)
    
    progress = xbmcgui.DialogProgress()
    progress.create('Refreshing Cache', 'Rebuilding episode list...')
    
    try:
        # Force rebuild cache
        episodes_data = content_router.get_episodes(tmdb_id, force_refresh=True)
        
        progress.close()
        
        if episodes_data:
            xbmcgui.Dialog().notification(
                'Cache Refreshed',
                f"{episodes_data['total_episodes']} episodes updated",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
        else:
            xbmcgui.Dialog().notification(
                'Refresh Failed',
                'Could not refresh cache',
                xbmcgui.NOTIFICATION_ERROR,
                3000
            )
    except Exception as e:
        progress.close()
        log(f"Cache refresh error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            'Error',
            str(e),
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
    
    # Refresh current container
    xbmc.executebuiltin('Container.Refresh')

# ==============================================================================
# ROUTER
# ==============================================================================

def router(paramstring):
    """
    Route to appropriate function based on parameters
    
    Args:
        paramstring (str): URL parameters
    """
    params = dict(urllib.parse.parse_qsl(paramstring))
    
    if not params:
        # Main menu
        show_main_menu()
    
    elif params['action'] == 'popular':
        list_popular_series(page=int(params.get('page', 1)))
    
    elif params['action'] == 'airing':
        list_airing_series(page=int(params.get('page', 1)))
    
    elif params['action'] == 'discover':
        list_discover_series(page=int(params.get('page', 1)))
    
    elif params['action'] == 'search':
        search_series()
    
    elif params['action'] == 'episodes':
        list_episodes(int(params['tmdb_id']))
    
    elif params['action'] == 'season':
        show_season_episodes(
            int(params['tmdb_id']),
            int(params['season'])
        )
    
    elif params['action'] == 'play':
        play_episode(
            int(params['tmdb_id']),
            int(params['season']),
            int(params['episode']),
            force_refresh=params.get('force_refresh') == '1'
        )
    
    elif params['action'] == 'refresh_cache':
        refresh_cache(int(params['tmdb_id']))
    
    elif params['action'] == 'not_available':
        xbmcgui.Dialog().ok(
            'Episode Not Available',
            'This episode is not currently available for streaming.'
        )
    
    else:
        log(f"Unknown action: {params.get('action')}", xbmc.LOGWARNING)
        show_main_menu()

# ==============================================================================
# ENTRY POINT
# ==============================================================================

if __name__ == '__main__':
    log("=== TURKISH SERIES ADDON STARTED (Phase 2D - UNIFIED CACHE) ===", xbmc.LOGINFO)
    log(f"TMDB Language: {metadata_language}", xbmc.LOGINFO)
    log(f"Cache Directory: {cache_dir}", xbmc.LOGINFO)
    
    try:
        router(sys.argv[2][1:])
    except Exception as e:
        log(f"Router error: {e}", xbmc.LOGERROR)
        import traceback
        log(traceback.format_exc(), xbmc.LOGERROR)
        
        xbmcgui.Dialog().notification(
            'Addon Error',
            str(e),
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
    
    log("=== TURKISH SERIES ADDON FINISHED ===", xbmc.LOGINFO)
