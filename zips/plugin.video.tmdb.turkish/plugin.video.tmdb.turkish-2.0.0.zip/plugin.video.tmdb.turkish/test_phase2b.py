#!/usr/bin/env python3
"""
Phase 2B End-to-End Test
Tests complete flow: TMDB → ContentRouter → Engine3SK → Stream
"""

import sys
import os

# Add lib to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))

from lib.tmdb_api import TMDBApi
from lib.content_router import ContentRouter


class FakeSettings:
    """Fake settings object for testing"""
    def getSetting(self, key):
        settings = {
            'audio_language': 'both',  # Try both engines
            'enable_debug': 'true'
        }
        return settings.get(key, '')


def test_full_flow():
    """Test complete TMDB → Stream flow"""
    
    print("="*80)
    print("Phase 2B: End-to-End Test")
    print("Testing: TMDB → ContentRouter → Engine3SK → Stream")
    print("="*80)
    
    # Initialize TMDB API
    print("\n[1] Initializing TMDB API...")
    api_key = "c8578981f94591042c8a9b9837571314"
    tmdb = TMDBApi(api_key, language='en')
    print("✓ TMDB API ready")
    
    # Initialize ContentRouter
    print("\n[2] Initializing ContentRouter...")
    settings = FakeSettings()
    router = ContentRouter(tmdb, settings)
    print("✓ ContentRouter ready")
    
    # Test series: Sen Çal Kapımı (TMDB ID: 104877)
    # NOTE: 3SK only has episodes 3-52 for this series (episodes 1-2 missing)
    test_series = {
        'tmdb_id': 104877,
        'name': 'Sen Çal Kapımı',
        'season': 1,
        'episode': 3  # Episode 3 IS available on 3SK
    }
    
    print(f"\n[3] Testing with: {test_series['name']}")
    print(f"    TMDB ID: {test_series['tmdb_id']}")
    print(f"    Episode: S{test_series['season']:02d}E{test_series['episode']:02d}")
    
    # Get series details
    print("\n[4] Getting series details from TMDB...")
    series = tmdb.get_series_details(test_series['tmdb_id'])
    
    if series:
        print(f"✓ Series: {series.get('name')}")
        print(f"  Seasons: {len(series.get('seasons', []))}")
        print(f"  Episodes: {series.get('number_of_episodes', 0)}")
    else:
        print("✗ Failed to get series details")
        return
    
    # Get all names
    print("\n[5] Getting name translations...")
    names = tmdb.get_all_names(test_series['tmdb_id'])
    
    print(f"✓ Found names:")
    if names.get('original'):
        print(f"  • Original: {names['original']}")
    if names.get('turkish'):
        print(f"  • Turkish: {names['turkish']}")
    if names.get('arabic'):
        print(f"  • Arabic: {names['arabic']}")
    if names.get('english'):
        print(f"  • English: {names['english']}")
    
    # Try playback
    print(f"\n[6] Attempting playback via ContentRouter...")
    print("    This may take 20-30 seconds (searching + stream extraction)...")
    
    result = router.play_episode(
        tmdb_id=test_series['tmdb_id'],
        season=test_series['season'],
        episode=test_series['episode'],
        episode_title=f"{test_series['name']} S{test_series['season']:02d}E{test_series['episode']:02d}"
    )
    
    if result:
        print("\n" + "="*80)
        print("✓✓✓ SUCCESS! Stream Found! ✓✓✓")
        print("="*80)
        print(f"Engine: {result['engine'].upper()}")
        print(f"Audio: {result['audio_language']}")
        print(f"Quality: {result['quality']}")
        print(f"Server: {result.get('server_name', 'Unknown')}")
        print(f"Stream URL: {result['stream_url'][:80]}...")
        print(f"Episode URL: {result['episode_url'][:80]}...")
        print("="*80)
    else:
        print("\n" + "="*80)
        print("✗✗✗ FAILED: No Stream Found ✗✗✗")
        print("="*80)
        print("Possible reasons:")
        print("• Episode not available on 3SK")
        print("• Name mismatch (TMDB name ≠ 3SK name)")
        print("• Episode numbering different")
        print("• Network/server issues")
        print("="*80)
    
    # Test with another episode
    print("\n[7] Testing second episode (S01E04)...")
    
    result2 = router.play_episode(
        tmdb_id=test_series['tmdb_id'],
        season=1,
        episode=4,  # Episode 4 IS available
        episode_title=f"{test_series['name']} S01E04"
    )
    
    if result2:
        print(f"✓ Second episode found via {result2['engine']}")
        print(f"  Quality: {result2['quality']}")
        print(f"  Server: {result2.get('server_name', 'Unknown')}")
    else:
        print("✗ Second episode not found")
    
    print("\n" + "="*80)
    print("Test Complete!")
    print("="*80)


def test_alternative_series():
    """Test with different series"""
    
    print("\n" + "="*80)
    print("Testing Alternative Series")
    print("="*80)
    
    # Initialize
    api_key = "c8578981f94591042c8a9b9837571314"
    tmdb = TMDBApi(api_key, language='en')
    router = ContentRouter(tmdb, FakeSettings())
    
    # Test different series (REAL Turkish series!)
    test_cases = [
        {'tmdb_id': 82148, 'name': 'Çukur', 'season': 1, 'episode': 1},
        {'tmdb_id': 100088, 'name': 'Kuruluş: Osman', 'season': 1, 'episode': 1},
        {'tmdb_id': 79103, 'name': 'Arka Sokaklar', 'season': 1, 'episode': 1},
    ]
    
    for test in test_cases:
        print(f"\n[TEST] {test['name']} S{test['season']:02d}E{test['episode']:02d}")
        
        result = router.play_episode(
            tmdb_id=test['tmdb_id'],
            season=test['season'],
            episode=test['episode'],
            episode_title=test['name']
        )
        
        if result:
            print(f"  ✓ Found via {result['engine']} ({result['quality']})")
        else:
            print(f"  ✗ Not found")


if __name__ == "__main__":
    try:
        # Main test
        test_full_flow()
        
        # Optional: Test more series
        print("\n" + "="*80)
        answer = input("\nTest more series? (y/n): ").strip().lower()
        if answer == 'y':
            test_alternative_series()
        
    except KeyboardInterrupt:
        print("\n\nTest interrupted by user")
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
