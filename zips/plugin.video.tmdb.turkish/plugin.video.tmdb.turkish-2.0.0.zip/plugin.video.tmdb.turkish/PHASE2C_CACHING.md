# Phase 2C - SQLite Caching + On-Demand Streams

## 🎯 Architecture Overview

**The Problem with Phase 2B:**
- Every time user opens a series, we scrape the landing page
- Every episode requires scraping servers (even if not watching)
- Lots of unnecessary network requests
- Slow user experience

**Phase 2C Solution:**
```
FIRST TIME USER OPENS A SERIES:
1. Search 3SK → Find ANY episode
2. Visit landing page → Extract ALL 52 episodes
3. Cache to SQLite → Store virtual folder for 7 days
4. Show episodes to user → Instant!

USER CLICKS EPISODE 5 TO WATCH:
5. Load episode URL from SQLite cache → Instant!
6. Scrape servers for Episode 5 only → On-demand!
7. Return stream → Play!

NEXT TIME USER OPENS SAME SERIES:
8. Load from SQLite cache → Instant!
9. No scraping needed → Super fast!
```

---

## 📊 Performance Comparison

| Operation | Phase 2B (No Cache) | Phase 2C (With Cache) |
|-----------|---------------------|----------------------|
| First load | ~15-20 seconds | ~15-20 seconds (same - must scrape) |
| Second load | ~15-20 seconds | **<0.1 seconds** (instant!) |
| Browse episodes | Requires scraping | **Instant from cache** |
| Click play Episode 5 | Scrape + Test servers | **Scrape only Episode 5** |
| Speed improvement | - | **~200x faster** |

---

## 🗂 Database Schema

**Table: `series_cache`**
```sql
CREATE TABLE series_cache (
    tmdb_id TEXT PRIMARY KEY,
    series_name TEXT,
    episodes_json TEXT,         -- JSON array of all episodes
    total_episodes INTEGER,
    cached_at INTEGER,           -- Unix timestamp
    expires_at INTEGER           -- Unix timestamp + 7 days
)
```

**Table: `episode_metadata`**
```sql
CREATE TABLE episode_metadata (
    tmdb_id TEXT,
    season INTEGER,
    episode INTEGER,
    episode_url TEXT,
    episode_title TEXT,
    PRIMARY KEY (tmdb_id, season, episode)
)
```

**Example Data:**
```json
{
  "tmdb_id": "104877",
  "series_name": "Love Is in the Air",
  "episodes_json": [
    {"title": "مسلسل انت اطرق بابي الحلقة 1 مترجمة", "url": "https://x.esheaq.onl/watch/xxx/", "episode_number": 1, "season": 1},
    {"title": "مسلسل انت اطرق بابي الحلقة 2 مترجمة", "url": "https://x.esheaq.onl/watch/yyy/", "episode_number": 2, "season": 1},
    ...
  ],
  "total_episodes": 52,
  "cached_at": 1735320000,
  "expires_at": 1735924800  // 7 days later
}
```

---

## 🔄 Complete Workflow

### Scenario 1: First Time User Searches for "Sen Çal Kapımı"

```python
# 1. User searches in Kodi
user_search = "Sen Çal Kapımı"

# 2. ContentRouter.get_episodes(104877)
episodes = router.get_episodes(tmdb_id=104877)

# 3. Cache miss → Build virtual folder
# Inside ContentRouter.get_episodes():
cached = series_cache.get_series(104877)  # Returns None
if not cached:
    # Get TMDB metadata
    metadata = tmdb.get_series_details(104877)
    names = tmdb.get_all_names(104877)  # ['Sen Çal Kapımı', 'أطرق بابي', ...]
    
    # Search 3SK
    search_results = engine_3sk.search_series(names)  # 50 results
    
    # Build virtual folder from landing page
    virtual_folder = engine_3sk.build_virtual_series_folder(search_results)
    # Returns: [{'title': '...', 'url': '...', 'episode_number': 1}, ...]
    
    # Cache to SQLite
    series_cache.set_series(104877, "Love Is in the Air", virtual_folder, cache_days=7)

# 4. Return episodes to user
return {
    'series_name': 'Love Is in the Air',
    'total_episodes': 52,
    'episodes': virtual_folder
}

# 5. Kodi shows episode list (instant from cache)
```

**Time:** ~15-20 seconds (one-time scraping)

### Scenario 2: User Opens Same Series Again (2 hours later)

```python
# 1. User browses to "Sen Çal Kapımı" again
episodes = router.get_episodes(tmdb_id=104877)

# 2. Cache HIT!
cached = series_cache.get_series(104877)  # Found!
# Returns: {
#   'series_name': 'Love Is in the Air',
#   'episodes': [...52 episodes...],
#   'cached_at': datetime(2025, 12, 27, 14, 30, 0)
# }

# 3. Return instantly (no scraping!)
return cached
```

**Time:** ~0.05 seconds (instant!)

### Scenario 3: User Clicks Play on Episode 5

```python
# 1. User clicks "Play Episode 5"
result = router.play_episode(tmdb_id=104877, season=1, episode=5)

# 2. Get episode URL from cache
episode_url = series_cache.get_episode_url(104877, season=1, episode=5)
# Returns: "https://x.esheaq.onl/watch/5ltj5wpq4j/"

# 3. NOW scrape servers (on-demand!)
stream_urls = engine_3sk.get_stream_url(episode_url)
# - Visit episode page
# - Find servers (OK.RU, Vidoba, etc.)
# - Test servers
# - Return working stream

# 4. Play stream
return {
    'stream_url': 'https://okcdn.ru/...',
    'quality': 'HD'
}
```

**Time:** ~5-10 seconds (only scraping Episode 5 servers)

---

## 📁 New Files in Phase 2C

```
plugin.video.tmdb.turkish/
├── lib/
│   ├── series_cache.py                 # NEW! SQLite cache manager
│   ├── content_router.py               # UPDATED! Uses cache
│   └── engines/
│       └── engine_3sk.py               # UPDATED! build_virtual_series_folder()
├── test_phase2c_caching.py             # NEW! Demonstrates caching
└── data/
    └── series_cache.db                 # SQLite database (auto-created)
```

---

## 🚀 Usage Examples

### Example 1: Get Episodes (with automatic caching)

```python
from lib.content_router import ContentRouter
from lib.tmdb_api import TMDBApi

# Initialize
tmdb = TMDBApi(api_key="...")
router = ContentRouter(tmdb, settings, cache_dir="~/.kodi/userdata/addon_data/...")

# Get episodes (automatically caches if not cached)
episodes = router.get_episodes(tmdb_id=104877)

# Returns:
# {
#   'series_name': 'Love Is in the Air',
#   'total_episodes': 52,
#   'cached_at': datetime(...),
#   'episodes': [
#       {'title': '...', 'url': '...', 'episode_number': 1, 'season': 1},
#       ...
#   ]
# }

# Show in Kodi UI
for ep in episodes['episodes']:
    list_item = xbmcgui.ListItem(label=ep['title'])
    # ...
```

### Example 2: Play Episode (on-demand stream scraping)

```python
# User clicks Episode 5
result = router.play_episode(
    tmdb_id=104877,
    season=1,
    episode=5
)

# Returns:
# {
#   'stream_url': 'https://okcdn.ru/...',
#   'quality': 'HD',
#   'engine': '3sk'
# }

# Play in Kodi
play_item = xbmcgui.ListItem(path=result['stream_url'])
xbmcplugin.setResolvedUrl(handle, True, play_item)
```

### Example 3: Cache Management

```python
from lib.series_cache import get_cache

cache = get_cache(cache_dir="...")

# Get stats
stats = cache.get_stats()
# Returns: {'total_series': 5, 'total_episodes': 250, 'expired_series': 1}

# Clear expired entries
deleted = cache.clear_expired()
print(f"Deleted {deleted} expired series")

# Force refresh specific series
cache.clear_series(tmdb_id=104877)
episodes = router.get_episodes(tmdb_id=104877, force_refresh=True)

# Clear all cache
cache.clear_all()
```

---

## 🎨 Kodi Integration Pattern

```python
# In main.py addon entry point

def list_episodes(tmdb_id):
    """Show episode list for a series"""
    
    # Get episodes (uses cache if available)
    episodes_data = router.get_episodes(tmdb_id)
    
    if not episodes_data:
        xbmcgui.Dialog().notification('Error', 'Series not found')
        return
    
    # Set Kodi category
    xbmcplugin.setPluginCategory(handle, episodes_data['series_name'])
    xbmcplugin.setContent(handle, 'episodes')
    
    # Add each episode to Kodi
    for ep in episodes_data['episodes']:
        # Create list item
        label = f"{ep['episode_number']}. {ep['title']}"
        list_item = xbmcgui.ListItem(label=label)
        
        # Set properties
        list_item.setInfo('video', {
            'title': ep['title'],
            'episode': ep['episode_number'],
            'season': ep['season'],
            'mediatype': 'episode'
        })
        
        # Create play URL
        url = build_url({
            'action': 'play',
            'tmdb_id': tmdb_id,
            'season': ep['season'],
            'episode': ep['episode_number']
        })
        
        # Add to Kodi
        xbmcplugin.addDirectoryItem(handle, url, list_item, False)
    
    xbmcplugin.endOfDirectory(handle)


def play_episode(tmdb_id, season, episode):
    """Play specific episode (on-demand stream scraping)"""
    
    # Show progress
    progress = xbmcgui.DialogProgress()
    progress.create('Loading', 'Finding stream...')
    
    # Get stream (scrapes servers on-demand)
    result = router.play_episode(tmdb_id, season, episode)
    
    progress.close()
    
    if not result:
        xbmcgui.Dialog().notification('Error', 'No stream found')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    
    # Play stream
    play_item = xbmcgui.ListItem(path=result['stream_url'])
    play_item.setProperty('IsPlayable', 'true')
    
    xbmcplugin.setResolvedUrl(handle, True, play_item)
```

---

## ⚙️ Configuration

### Cache Duration

Default: 7 days

```python
# Set custom cache duration when caching
series_cache.set_series(
    tmdb_id=104877,
    series_name="...",
    episodes=virtual_folder,
    cache_days=14  # Cache for 14 days instead of 7
)
```

### Cache Location

```python
# Kodi environment
cache_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

# Testing environment
cache_dir = os.path.expanduser('~/.cache/kodi_turkish')

# Custom location
cache_dir = "/path/to/custom/cache"

router = ContentRouter(tmdb, settings, cache_dir=cache_dir)
```

---

## 🔍 Benefits Summary

### Performance
- **~200x faster** subsequent loads
- **Instant** episode browsing
- **On-demand** stream scraping only

### Network Usage
- **Single scrape** per series (every 7 days)
- **No unnecessary** server testing
- **Minimal bandwidth** for browsing

### User Experience
- **Instant** series browsing
- **Fast** episode listings
- **Smooth** navigation
- **Predictable** loading times

### Architecture
- **Clean separation** of concerns
- **SQLite storage** (portable, reliable)
- **Automatic expiration** (no stale data)
- **Easy cache management** (stats, clear, refresh)

---

## 🧪 Testing

Run the Phase 2C test to see caching in action:

```bash
cd plugin.video.tmdb.turkish
python3 test_phase2c_caching.py
```

**Expected Output:**
```
================================================================================
  Phase 2C: SQLite Caching + On-Demand Streams
================================================================================

Test Series: Sen Çal Kapımı (Love Is in the Air)
TMDB ID: 104877

[1. Initializing Components]
✓ TMDB API initialized
✓ Cache directory: /home/user/.cache/kodi_turkish_test
✓ ContentRouter initialized
✓ Cache cleared

Cache stats: 0 series, 0 episodes

================================================================================
  2. FIRST REQUEST: Build Virtual Folder (Slow - Scraping)
================================================================================

This may take 10-20 seconds...

✓ SUCCESS! Built virtual folder in 15.32 seconds

Series: Love Is in the Air
Total Episodes: 52
Cached at: 2025-12-27 14:30:00

Episode List (first 10):
  E001: مسلسل انت اطرق بابي الحلقة 1 مترجمة
  E002: مسلسل انت اطرق بابي الحلقة 2 مترجمة
  ...

Cache stats: 1 series, 52 episodes

================================================================================
  3. SECOND REQUEST: Load from Cache (Fast - No Scraping)
================================================================================

✓ SUCCESS! Loaded from cache in 0.0523 seconds
  (52.3 milliseconds - INSTANT!)

✓ Cache data matches original - perfect!
```

---

## 🎯 Next Steps

**Phase 2C Complete:**
- ✅ SQLite caching implemented
- ✅ Virtual series folders cached
- ✅ On-demand stream resolution architecture
- ✅ Fast episode browsing

**Phase 3: Full Kodi Integration**
- Integrate caching with main.py
- Add cache management UI
- Add refresh/clear cache options
- Show cache stats in addon settings

**Phase 4: Enhanced Features**
- Watch history tracking
- Resume positions
- Favorites system
- Continue watching

---

**Version:** Phase 2C  
**Date:** December 27, 2025  
**Status:** ✅ Ready for Integration
