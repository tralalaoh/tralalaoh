"""
SQLite Cache Manager for Virtual Series Folders
Stores scraped episode lists so we don't need to scrape every time
"""

import sqlite3
import json
import os
import time
from datetime import datetime, timedelta


class SeriesCache:
    """
    Cache virtual series folders in SQLite
    
    Architecture:
    - Cache episode lists (title, url, episode_number) per TMDB ID
    - Cache expires after 7 days (configurable)
    - Only scrape streams on-demand when user clicks play
    """
    
    def __init__(self, cache_dir):
        """
        Initialize cache database
        
        Args:
            cache_dir: Directory to store cache.db (usually addon data dir)
        """
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
        self.db_path = os.path.join(cache_dir, 'series_cache.db')
        self._init_db()
    
    def _init_db(self):
        """Create tables if they don't exist"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if tables exist and need migration
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='series_cache'")
        table_exists = cursor.fetchone() is not None
        
        if table_exists:
            # Check if engine column exists
            cursor.execute("PRAGMA table_info(series_cache)")
            columns = [row[1] for row in cursor.fetchall()]
            
            if 'engine' not in columns:
                # Migration needed!
                print("SeriesCache: Migrating database schema...")
                
                # Add engine column with default value
                cursor.execute("ALTER TABLE series_cache ADD COLUMN engine TEXT DEFAULT '3sk'")
                cursor.execute("UPDATE series_cache SET engine = '3sk' WHERE engine IS NULL")
                print("SeriesCache: Added 'engine' column to series_cache")
                
                # Check episode_metadata table
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='episode_metadata'")
                if cursor.fetchone():
                    cursor.execute("PRAGMA table_info(episode_metadata)")
                    ep_columns = [row[1] for row in cursor.fetchall()]
                    
                    if 'engine' not in ep_columns:
                        cursor.execute("ALTER TABLE episode_metadata ADD COLUMN engine TEXT DEFAULT '3sk'")
                        cursor.execute("UPDATE episode_metadata SET engine = '3sk' WHERE engine IS NULL")
                        print("SeriesCache: Added 'engine' column to episode_metadata")
                
                conn.commit()
                print("SeriesCache: Migration complete!")
        
        # Series cache table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS series_cache (
                tmdb_id TEXT PRIMARY KEY,
                series_name TEXT,
                episodes_json TEXT,
                total_episodes INTEGER,
                engine TEXT DEFAULT '3sk',
                cached_at INTEGER,
                expires_at INTEGER
            )
        ''')
        
        # Episode metadata table (for quick lookups)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS episode_metadata (
                tmdb_id TEXT,
                season INTEGER,
                episode INTEGER,
                episode_url TEXT,
                episode_title TEXT,
                engine TEXT DEFAULT '3sk',
                PRIMARY KEY (tmdb_id, season, episode)
            )
        ''')
        
        # Create indexes for faster queries
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_expires 
            ON series_cache(expires_at)
        ''')
        
        conn.commit()
        conn.close()
    
    def get_series(self, tmdb_id):
        """
        Get cached series episodes
        
        Args:
            tmdb_id: TMDB series ID
            
        Returns:
            dict with episodes list or None if not cached/expired
            {
                'series_name': str,
                'episodes': [
                    {'title': str, 'url': str, 'episode_number': int},
                    ...
                ],
                'total_episodes': int,
                'cached_at': datetime
            }
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT series_name, episodes_json, total_episodes, engine, cached_at, expires_at
            FROM series_cache
            WHERE tmdb_id = ?
        ''', (str(tmdb_id),))
        
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return None
        
        series_name, episodes_json, total_episodes, engine, cached_at, expires_at = row
        
        # Check if expired
        now = int(time.time())
        if now > expires_at:
            return None
        
        # Parse episodes
        try:
            episodes = json.loads(episodes_json)
        except:
            return None
        
        return {
            'series_name': series_name,
            'episodes': episodes,
            'total_episodes': total_episodes,
            'engine': engine,
            'cached_at': datetime.fromtimestamp(cached_at)
        }
    
    def set_series(self, tmdb_id, series_name, episodes, engine='3sk', cache_days=7):
        """
        Cache series episodes
        
        Args:
            tmdb_id: TMDB series ID
            series_name: Series name for display
            episodes: List of episode dicts [{'title', 'url', 'episode_number'}, ...]
            engine: Engine name ('3sk' or 'turkish123')
            cache_days: How many days to keep cache (default 7)
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        now = int(time.time())
        expires_at = now + (cache_days * 24 * 60 * 60)
        
        episodes_json = json.dumps(episodes, ensure_ascii=False)
        
        cursor.execute('''
            INSERT OR REPLACE INTO series_cache 
            (tmdb_id, series_name, episodes_json, total_episodes, engine, cached_at, expires_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            str(tmdb_id),
            series_name,
            episodes_json,
            len(episodes),
            engine,
            now,
            expires_at
        ))
        
        # Also cache individual episode metadata for quick lookups
        # Use the episode's season from the data, or default to 1
        for ep in episodes:
            try:
                # Get URL - handle both field names (3SK uses 'url', Turkish123 uses 'episode_url')
                ep_url = ep.get('episode_url') or ep.get('url')
                if not ep_url:
                    # Log the episode structure for debugging
                    print(f"WARNING: Episode missing URL: {ep}")
                    continue
                
                # Get title - handle both field names
                ep_title = ep.get('episode_title') or ep.get('title', 'Unknown')
                
                cursor.execute('''
                    INSERT OR REPLACE INTO episode_metadata
                    (tmdb_id, season, episode, episode_url, episode_title, engine)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    str(tmdb_id),
                    ep.get('season', 1),  # Use episode's season or default to 1
                    ep['episode_number'],
                    ep_url,
                    ep_title,
                    engine
                ))
            except Exception as e:
                print(f"ERROR caching episode {ep.get('episode_number')}: {e}")
                print(f"Episode data: {ep}")
                continue
        
        conn.commit()
        conn.close()
    
    def get_episode_url(self, tmdb_id, season, episode):
        """
        Get cached episode URL and engine for quick lookup
        
        Args:
            tmdb_id: TMDB series ID
            season: Season number
            episode: Episode number
            
        Returns:
            tuple: (episode_url, engine) or (None, None) if not found
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT episode_url, engine
            FROM episode_metadata
            WHERE tmdb_id = ? AND season = ? AND episode = ?
        ''', (str(tmdb_id), season, episode))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return (row[0], row[1])  # (url, engine)
        else:
            return (None, None)
    
    def clear_expired(self):
        """Remove expired cache entries"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        now = int(time.time())
        
        # Delete expired series
        cursor.execute('''
            DELETE FROM series_cache
            WHERE expires_at < ?
        ''', (now,))
        
        # Delete orphaned episode metadata
        cursor.execute('''
            DELETE FROM episode_metadata
            WHERE tmdb_id NOT IN (SELECT tmdb_id FROM series_cache)
        ''')
        
        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        
        return deleted
    
    def clear_series(self, tmdb_id):
        """Remove specific series from cache"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM series_cache WHERE tmdb_id = ?', (str(tmdb_id),))
        cursor.execute('DELETE FROM episode_metadata WHERE tmdb_id = ?', (str(tmdb_id),))
        
        conn.commit()
        conn.close()
    
    def clear_all(self):
        """Clear entire cache"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM series_cache')
        cursor.execute('DELETE FROM episode_metadata')
        
        conn.commit()
        conn.close()
    
    def get_stats(self):
        """Get cache statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM series_cache')
        total_series = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM episode_metadata')
        total_episodes = cursor.fetchone()[0]
        
        now = int(time.time())
        cursor.execute('SELECT COUNT(*) FROM series_cache WHERE expires_at < ?', (now,))
        expired = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_series': total_series,
            'total_episodes': total_episodes,
            'expired_series': expired
        }


# Singleton instance for global use
_cache_instance = None

def get_cache(cache_dir=None):
    """Get or create cache instance"""
    global _cache_instance
    
    if _cache_instance is None:
        if cache_dir is None:
            # Default to temp directory for testing
            cache_dir = os.path.join(os.path.expanduser('~'), '.cache', 'kodi_turkish')
        _cache_instance = SeriesCache(cache_dir)
    
    return _cache_instance
