# -*- coding: utf-8 -*-
"""
TMDB API Handler
Handles all TMDB API calls for Turkish series
"""

import requests
import time

try:
    import xbmc
    import xbmcaddon
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGDEBUG = 0
        LOGINFO = 1
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"[{level}] {msg}")


class TMDBApi:
    """TMDB API handler for Turkish series"""
    
    API_BASE = "https://api.themoviedb.org/3"
    IMAGE_BASE = "https://image.tmdb.org/t/p"
    
    def __init__(self, api_key, language='en'):
        """
        Initialize TMDB API
        
        Args:
            api_key (str): TMDB API key
            language (str): Metadata language ('en' or 'tr')
        """
        self.api_key = api_key
        self.language = language
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'User-Agent': 'Kodi-TMDB-Turkish/1.0'
        })
        
        self._log(f"TMDB API initialized (language: {language})", xbmc.LOGINFO)
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message"""
        if KODI_ENV:
            xbmc.log(f"TMDB API: {message}", level)
        else:
            print(f"TMDB API: {message}")
    
    def _request(self, endpoint, params=None):
        """Make TMDB API request"""
        if params is None:
            params = {}
        
        params['api_key'] = self.api_key
        params['language'] = self.language
        
        url = f"{self.API_BASE}{endpoint}"
        
        try:
            self._log(f"Request: {endpoint}", xbmc.LOGDEBUG)
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            self._log(f"Request failed: {e}", xbmc.LOGERROR)
            return None
    
    def get_popular(self, page=1):
        """
        Get popular Turkish series (STRICTLY Turkish origin only)
        Based on working test code - uses your exact logic
        
        Args:
            page (int): Page number
        
        Returns:
            dict: TMDB response with results (filtered)
        """
        self._log(f"Getting popular Turkish series (page {page})", xbmc.LOGINFO)
        
        # YOUR WORKING CODE: Popular by popularity
        data = self._request('/discover/tv', {
            'with_origin_country': 'TR',
            'with_original_language': 'tr',  # CRITICAL: Must be Turkish language
            'sort_by': 'popularity.desc',
            'page': page,
            'include_adult': False,
            'include_null_first_air_dates': False  # Exclude series without dates
        })
        
        # STRICT FILTER: Only Turkish origin
        if data and 'results' in data:
            data['results'] = self._filter_turkish_only(data['results'])
        
        return data
    
    def get_airing_today(self, page=1):
        """
        Get Turkish series airing today (STRICTLY Turkish origin only)
        
        Args:
            page (int): Page number
        
        Returns:
            dict: TMDB response with results (filtered)
        """
        self._log(f"Getting airing today (page {page})", xbmc.LOGINFO)
        
        data = self._request('/discover/tv', {
            'with_origin_country': 'TR',
            'air_date.gte': time.strftime('%Y-%m-%d'),
            'air_date.lte': time.strftime('%Y-%m-%d'),
            'sort_by': 'popularity.desc',
            'page': page,
            'include_adult': False
        })
        
        # STRICT FILTER: Only Turkish origin
        if data and 'results' in data:
            data['results'] = self._filter_turkish_only(data['results'])
        
        return data
    
    def get_on_the_air(self, page=1, days_back=30):
        """
        Get NEW Turkish series (2024+) currently airing
        Based on YOUR airing_now.py - shows only recently premiered series
        
        YOUR CODE: "Fetches TV Series only from Turkey released since 2024"
        This focuses on NEW shows that premiered in 2024+, not old shows still airing.
        
        Args:
            page (int): Page number
            days_back (int): Not used - kept for compatibility
        
        Returns:
            dict: TMDB response with results (filtered and sorted)
        """
        self._log(f"Getting NEW Turkish series (2024+) - page {page}", xbmc.LOGINFO)
        
        # YOUR EXACT CODE from airing_now.py
        # Shows only series that premiered since 2024-01-01
        data = self._request('/discover/tv', {
            'with_origin_country': 'TR',
            'with_original_language': 'tr',
            'first_air_date.gte': '2024-01-01',  # Only NEW series from 2024+
            'sort_by': 'popularity.desc',
            'include_null_first_air_dates': False,
            'page': page,
            'include_adult': False
        })
        
        # STRICT FILTER: Only Turkish origin
        if data and 'results' in data:
            original_count = len(data['results'])
            data['results'] = self._filter_turkish_only(data['results'])
            filtered_count = len(data['results'])
            self._log(f"New Series (2024+): {original_count} results, {filtered_count} after filter", xbmc.LOGINFO)
        
        return data
    
    def get_discover(self, page=1, genre=None, year=None):
        """
        Discover Turkish series with filters (STRICTLY Turkish origin only)
        Based on working test code - YOUR EXACT LOGIC (Top Rated with 50+ votes)
        
        Args:
            page (int): Page number
            genre (int): Genre ID (optional)
            year (int): Year (optional)
        
        Returns:
            dict: TMDB response with results (filtered)
        """
        self._log(f"Discover (page {page}, genre={genre}, year={year})", xbmc.LOGINFO)
        
        # YOUR WORKING CODE: Top Rated logic
        params = {
            'with_origin_country': 'TR',
            'with_original_language': 'tr',  # CRITICAL: Must be Turkish language
            'sort_by': 'vote_average.desc',  # Top rated
            'vote_count.gte': 50,            # At least 50 votes
            'page': page,
            'include_adult': False,
            'include_null_first_air_dates': False  # Exclude series without dates
        }
        
        if genre:
            params['with_genres'] = genre
        if year:
            params['first_air_date_year'] = year
        
        data = self._request('/discover/tv', params)
        
        # STRICT FILTER: Only Turkish origin
        if data and 'results' in data:
            data['results'] = self._filter_turkish_only(data['results'])
        
        return data
    
    def get_series_details(self, tmdb_id):
        """
        Get detailed info for a series
        
        Args:
            tmdb_id (int): TMDB series ID
        
        Returns:
            dict: Series details with seasons/episodes
        """
        self._log(f"Getting series details for {tmdb_id}", xbmc.LOGINFO)
        
        # Get basic details with append
        details = self._request(f'/tv/{tmdb_id}', {
            'append_to_response': 'credits,videos,images,alternative_titles'
        })
        
        if not details:
            return None
        
        # Get all seasons with episodes
        seasons = []
        for season in details.get('seasons', []):
            season_num = season['season_number']
            
            # Skip season 0 (specials) unless it's the only season
            if season_num == 0 and len(details.get('seasons', [])) > 1:
                continue
            
            season_details = self._request(f'/tv/{tmdb_id}/season/{season_num}')
            if season_details:
                seasons.append(season_details)
        
        details['seasons_detailed'] = seasons
        
        return details
    
    def get_all_names(self, tmdb_id):
        """
        Get all name variants for a series (Turkish, Arabic, English, etc.)
        ENHANCED: Collects ALL Arabic name variants
        
        Args:
            tmdb_id (int): TMDB series ID
        
        Returns:
            dict: All name variants including multiple Arabic names
        """
        self._log(f"Getting all names for {tmdb_id}", xbmc.LOGINFO)
        
        # Get details with alternative titles
        details = self._request(f'/tv/{tmdb_id}', {
            'append_to_response': 'alternative_titles,translations'
        })
        
        if not details:
            return {}
        
        names = {
            'original': details.get('original_name', ''),
            'name': details.get('name', ''),
            'alternatives': []
        }
        
        # Add alternative titles
        alt_titles = details.get('alternative_titles', {}).get('results', [])
        for alt in alt_titles:
            title = alt.get('title', '')
            if title and title not in [names['original'], names['name']]:
                names['alternatives'].append(title)
        
        # Add translations - COLLECT ALL ARABIC VARIANTS
        translations = details.get('translations', {}).get('translations', [])
        arabic_names = []  # Store all Arabic name variants
        
        for trans in translations:
            iso = trans.get('iso_639_1', '')
            trans_data = trans.get('data', {})
            trans_name = trans_data.get('name', '')
            
            if trans_name:
                # Arabic translations - collect ALL variants
                if iso == 'ar':
                    if trans_name not in arabic_names:
                        arabic_names.append(trans_name)
                    # Store first Arabic as primary
                    if 'arabic' not in names:
                        names['arabic'] = trans_name
                
                # Turkish translations
                elif iso == 'tr':
                    names['turkish'] = trans_name
                
                # English translations
                elif iso == 'en':
                    names['english'] = trans_name
                
                # Add to alternatives if not already there
                if trans_name not in [names['original'], names['name']] + names['alternatives']:
                    names['alternatives'].append(trans_name)
        
        # Add all Arabic variants to alternatives
        for arabic_name in arabic_names:
            if arabic_name not in names['alternatives']:
                names['alternatives'].append(arabic_name)
        
        self._log(f"Found names: {list(names.keys())}", xbmc.LOGDEBUG)
        if arabic_names:
            self._log(f"Arabic variants: {len(arabic_names)}", xbmc.LOGINFO)
        
        return names
    
    def get_search_names(self, tmdb_id):
        """
        Get all name variants as a flat list for searching
        
        Args:
            tmdb_id (int): TMDB series ID
        
        Returns:
            list: All name variants in priority order
        """
        names_dict = self.get_all_names(tmdb_id)
        
        if not names_dict:
            return []
        
        # Build list in priority order
        search_names = []
        
        # 1. Original name
        if names_dict.get('original'):
            search_names.append(names_dict['original'])
        
        # 2. Primary Arabic name
        if names_dict.get('arabic'):
            search_names.append(names_dict['arabic'])
        
        # 3. English name
        if names_dict.get('english'):
            search_names.append(names_dict['english'])
        
        # 4. Turkish name
        if names_dict.get('turkish'):
            search_names.append(names_dict['turkish'])
        
        # 5. Primary name (if different from original)
        if names_dict.get('name') and names_dict['name'] != names_dict.get('original'):
            search_names.append(names_dict['name'])
        
        # 6. All alternatives (including other Arabic variants)
        for alt in names_dict.get('alternatives', []):
            if alt not in search_names:
                search_names.append(alt)
        
        # Deduplicate while preserving order
        seen = set()
        deduped = []
        for name in search_names:
            if name and name not in seen:
                seen.add(name)
                deduped.append(name)
        
        return deduped
    
    def get_name_translations(self, tmdb_id):
        """
        Get name translations (alias for get_search_names for compatibility)
        
        Returns:
            dict: {'names': [list of name variants]}
        """
        names = self.get_search_names(tmdb_id)
        return {'names': names}
    
    def search(self, query, page=1):
        """
        Search for series
        
        Args:
            query (str): Search query
            page (int): Page number
        
        Returns:
            dict: Search results
        """
        self._log(f"Searching: {query} (page {page})", xbmc.LOGINFO)
        
        return self._request('/search/tv', {
            'query': query,
            'page': page,
            'include_adult': False
        })
    
    def get_image_url(self, path, size='w500'):
        """
        Get full image URL
        
        Args:
            path (str): Image path from TMDB
            size (str): Image size (w92, w185, w500, w780, original)
        
        Returns:
            str: Full image URL or None
        """
        if not path:
            return None
        return f"{self.IMAGE_BASE}/{size}{path}"
    
    def _filter_turkish_only(self, results):
        """
        STRICT FILTER: Remove any series not originated in Turkey
        
        TMDB sometimes includes US/other shows with Turkish dubs.
        This ensures ONLY Turkish-origin series are shown.
        
        Args:
            results (list): TMDB results
        
        Returns:
            list: Filtered results (Turkish origin only)
        """
        if not results:
            return []
        
        filtered = []
        for series in results:
            origin_countries = series.get('origin_country', [])
            original_language = series.get('original_language', '')
            
            # STRICT CHECK:
            # 1. Must have Turkey in origin_country
            # 2. Original language should be Turkish (tr)
            # 3. Reject if USA/other countries in origin
            
            if not origin_countries:
                continue
            
            # Turkey must be in origin
            if 'TR' not in origin_countries:
                self._log(f"Filtered out: {series.get('name')} (no TR in origin)", xbmc.LOGDEBUG)
                continue
            
            # Reject if USA/UK/etc also in origin (co-productions we don't want)
            unwanted = ['US', 'GB', 'CA', 'AU', 'FR', 'DE', 'ES', 'IT', 'JP', 'KR', 'CN']
            if any(country in origin_countries for country in unwanted):
                self._log(f"Filtered out: {series.get('name')} (co-production with {origin_countries})", xbmc.LOGDEBUG)
                continue
            
            # Original language should be Turkish
            if original_language and original_language != 'tr':
                self._log(f"Filtered out: {series.get('name')} (original language: {original_language})", xbmc.LOGDEBUG)
                continue
            
            # Passed all checks!
            filtered.append(series)
        
        self._log(f"Filtered: {len(results)} → {len(filtered)} (Turkish only)", xbmc.LOGINFO)
        return filtered
    
    # ========================================================================
    # WRAPPER METHODS FOR MAIN.PY COMPATIBILITY
    # ========================================================================
    
    def get_popular_turkish(self, page=1):
        """
        Get popular Turkish series - returns list instead of dict
        For main.py compatibility
        """
        data = self.get_popular(page=page)
        return data.get('results', []) if data else []
    
    def get_airing_turkish(self, days_back=30, page=1):
        """
        Get airing Turkish series - returns list instead of dict
        For main.py compatibility
        """
        data = self.get_on_the_air(page=page, days_back=days_back)
        return data.get('results', []) if data else []
    
    def search_series(self, query, page=1):
        """
        Search for TV series
        
        Args:
            query (str): Search query
            page (int): Page number
        
        Returns:
            list: Search results
        """
        results = self._request('/search/tv', {
            'query': query,
            'page': page
        })
        
        if not results or 'results' not in results:
            return []
        
        return results['results']
    
    def get_episode_details(self, tmdb_id, season, episode):
        """
        Get details for a specific episode
        
        Args:
            tmdb_id (int): TMDB series ID
            season (int): Season number
            episode (int): Episode number
        
        Returns:
            dict: Episode details
        """
        return self._request(f'/tv/{tmdb_id}/season/{season}/episode/{episode}')
    
    def get_season_details(self, tmdb_id, season):
        """
        Get details for a specific season including all episodes
        
        Args:
            tmdb_id (int): TMDB series ID
            season (int): Season number
        
        Returns:
            dict: Season details with episodes list
        """
        self._log(f"Getting season {season} details for {tmdb_id}", xbmc.LOGINFO)
        
        season_data = self._request(f'/tv/{tmdb_id}/season/{season}')
        
        if not season_data:
            self._log(f"Season {season} not found for TMDB {tmdb_id}", xbmc.LOGWARNING)
            return None
        
        return season_data
