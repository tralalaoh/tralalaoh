# -*- coding: utf-8 -*-
"""
Utility Functions for Engines
- JavaScript unpacking
- Episode info parsing
"""

import re


def unpack_js(packed_code):
    """
    Unpack JavaScript code packed with Dean Edwards' packer
    
    YOUR PROVEN CODE from 3SK/Turkish123 addons
    
    Args:
        packed_code (str): Packed JavaScript code
    
    Returns:
        str: Unpacked code or None if unpacking fails
    """
    try:
        match = re.search(r"}\('(.*)',(\d+),(\d+),'([^']*)'\.split\('\|'\)", packed_code)
        if not match:
            return None
        
        payload, radix, count, symtab = match.groups()
        radix = int(radix)
        symbols = symtab.split('|')
        
        def lookup(match):
            value = int(match.group(0), radix)
            return symbols[value] if value < len(symbols) and symbols[value] else match.group(0)
        
        return re.sub(r'\b\w+\b', lookup, payload)
    except:
        return None


def parse_episode_info(title):
    """
    Extract season and episode numbers from title
    
    Supports multiple formats:
    - S##E## (standard)
    - الموسم ## الحلقة ## (Arabic)
    - Season ## Episode ## (English)
    - Sezon ## Bölüm ## (Turkish)
    - Ep ## / Episode ## (episode only, assume season 1)
    
    Args:
        title (str): Episode title
    
    Returns:
        tuple: (season, episode) or (None, None) if not found
    
    Examples:
        >>> parse_episode_info("Series Name S02E05")
        (2, 5)
        
        >>> parse_episode_info("مسلسل Name الموسم 2 الحلقة 5")
        (2, 5)
        
        >>> parse_episode_info("Series Name Episode 10")
        (1, 10)
    """
    
    patterns = [
        # Standard S##E## format
        (r'S(\d+)E(\d+)', 'standard'),
        
        # Arabic: الموسم X الحلقة Y
        (r'الموسم\s*(\d+).*?الحلقة\s*(\d+)', 'arabic'),
        
        # English: Season X Episode Y
        (r'Season\s*(\d+).*?Episode\s*(\d+)', 'english'),
        
        # Turkish: Sezon X Bölüm Y
        (r'Sezon\s*(\d+).*?Bölüm\s*(\d+)', 'turkish'),
        
        # Arabic: الحلقة X (episode only, assume season 1)
        (r'الحلقة\s*(\d+)', 'arabic_episode_only'),
        
        # English: Episode X / Ep X (episode only, assume season 1)
        (r'(?:Episode|Ep)\s*(\d+)', 'english_episode_only'),
    ]
    
    for pattern, format_type in patterns:
        match = re.search(pattern, title, re.IGNORECASE | re.UNICODE)
        if match:
            if 'episode_only' in format_type:
                # Episode only, assume season 1
                return (1, int(match.group(1)))
            else:
                # Both season and episode
                return (int(match.group(1)), int(match.group(2)))
    
    return (None, None)


def deduplicate_results(results):
    """
    Remove duplicate episodes from search results
    
    Args:
        results (list): List of search results with 'episode_url' key
    
    Returns:
        list: Deduplicated results
    """
    seen_urls = set()
    deduplicated = []
    
    for result in results:
        url = result.get('episode_url', '')
        if url and url not in seen_urls:
            seen_urls.add(url)
            deduplicated.append(result)
    
    return deduplicated


def clean_arabic_title(title):
    """
    Clean Arabic titles for better matching
    
    Args:
        title (str): Title to clean
    
    Returns:
        str: Cleaned title
    """
    # Remove common prefixes
    title = re.sub(r'مسلسل\s+', '', title)
    title = re.sub(r'الحلقة\s+\d+', '', title)
    title = re.sub(r'الموسم\s+\d+', '', title)
    
    # Remove extra whitespace
    title = ' '.join(title.split())
    
    return title.strip()
