# -*- coding: utf-8 -*-
"""
Turkish123 Streaming Engine
Based on YOUR PROVEN WORKING IMPLEMENTATION
"""

import re
import time
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, quote_plus

try:
    import xbmc
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGDEBUG = 0
        LOGINFO = 1
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"[Turkish123] {msg}")

try:
    from .base_engine import BaseEngine
    from .server_cache import ServerIndexCache
    from .utils import unpack_js
except ImportError:
    from base_engine import BaseEngine
    from server_cache import ServerIndexCache
    from utils import unpack_js


# ==============================================================================
# YOUR PROVEN CONFIGURATION
# ==============================================================================

MAX_SERVERS_TO_TEST = 3

STREAM_PATTERNS = [
    # Tukipasti/Dwish embeds (YOUR PRIMARY PATTERNS!)
    (r'https://tukipasti\.[^\s\'"]+', 'Tukipasti embed'),
    (r'https://dwish\.[^\s\'"]+', 'Dwish embed'),
    
    # Direct m3u8 patterns
    (r'(https?://[^\s"\'<>]+\.m3u8(?:\?[^\s"\'<>]+)?)', 'Direct m3u8'),
    
    # JWPlayer patterns
    (r'"file"\s*:\s*"([^"]+)"', 'JWPlayer file (double quotes)'),
    (r"'file'\s*:\s*'([^']+)'", 'JWPlayer file (single quotes)'),
    (r'"sources"\s*:\s*\[\s*"([^"]+)"', 'sources array'),
    
    # Direct mp4
    (r'(https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]+)?)', 'Direct mp4'),
    
    # OK.RU patterns
    (r'"hlsManifestUrl"\s*:\s*"([^"]+)"', 'OK.RU HLS'),
    (r'"(https://[^"]+okcdn\.ru[^"]+\.m3u8[^"]*)"', 'OK.RU okcdn'),
]


class EngineTurkish123(BaseEngine):
    """
    Turkish123 engine with YOUR PROVEN stream extraction logic
    """
    
    def __init__(self):
        """Initialize Turkish123 engine"""
        self.name = "Turkish123"
        self.base_url = "https://www2.turkish123.org"
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://www2.turkish123.org/'
        })
        
        # Initialize server index cache (YOUR SMART CACHING!)
        self.cache = ServerIndexCache()
        
        self._log("Turkish123 Engine initialized", xbmc.LOGINFO)
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message"""
        if KODI_ENV:
            xbmc.log(f"EngineTurkish123: {message}", level)
        else:
            print(f"[Turkish123] {message}")
    
    def _request(self, url, timeout=30):
        """Make HTTP request"""
        if not url.startswith('http'):
            url = urljoin(self.base_url, url)
        
        try:
            self._log(f"Request: {url[:100]}...", xbmc.LOGDEBUG)
            response = self.session.get(url, timeout=timeout, allow_redirects=True)
            response.raise_for_status()
            return response
        except Exception as e:
            self._log(f"Request failed: {e}", xbmc.LOGERROR)
            return None
    
    def normalize_for_search(self, text):
        """Normalize Turkish text for searching"""
        if not text:
            return ""
        
        text = text.lower()
        
        # Turkish character replacements
        replacements = {
            'ç': 'c', 'ğ': 'g', 'ı': 'i',
            'ö': 'o', 'ş': 's', 'ü': 'u'
        }
        
        for tr_char, en_char in replacements.items():
            text = text.replace(tr_char, en_char)
        
        # Remove special characters
        text = re.sub(r'[^a-z0-9\s]', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def search(self, search_names):
        """Search Turkish123 for series"""
        self._log(f"Searching Turkish123 with {len(search_names)} names", xbmc.LOGINFO)
        
        for name in search_names:
            query = self.normalize_for_search(name)
            if not query:
                continue
            
            self._log(f"Searching for: {query}", xbmc.LOGINFO)
            
            search_url = f"{self.base_url}/?s={quote_plus(query)}"
            response = self._request(search_url)
            if not response:
                continue
            
            soup = BeautifulSoup(response.text, 'html.parser')
            items = soup.select("div.ml-item")
            
            self._log(f"Found {len(items)} search results", xbmc.LOGINFO)
            
            for item in items:
                link_tag = item.select_one("a")
                title_tag = item.select_one("h2")
                
                if not link_tag or not title_tag:
                    continue
                
                found_title = self.normalize_for_search(title_tag.text.strip())
                
                if query in found_title:
                    series_url = urljoin(self.base_url, link_tag.get('href', ''))
                    self._log(f"Found match: {title_tag.text.strip()}", xbmc.LOGINFO)
                    return [{'url': series_url, 'title': title_tag.text.strip()}]
        
        self._log("No matching series found", xbmc.LOGWARNING)
        return []
    
    def build_virtual_series_folder(self, search_results):
        """Build virtual folder from Turkish123 series page"""
        self._log("=== BUILDING VIRTUAL SERIES FOLDER ===", xbmc.LOGINFO)
        
        if not search_results or len(search_results) == 0:
            return []
        
        series_url = search_results[0]['url']
        self._log(f"Series page: {series_url[:80]}...", xbmc.LOGINFO)
        
        response = self._request(series_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.text, 'html.parser')
        episode_links = soup.select("div.les-content > a")
        
        self._log(f"Found {len(episode_links)} episodes on series page", xbmc.LOGINFO)
        
        episodes = []
        for idx, link in enumerate(episode_links):
            title = link.text.strip()
            url = urljoin(self.base_url, link.get('href', ''))
            
            num_match = re.search(r'(\d+)', title)
            ep_num = int(num_match.group(1)) if num_match else (len(episode_links) - idx)
            
            episodes.append({
                'episode_number': ep_num,
                'season': 1,
                'episode_title': title,
                'episode_url': url
            })
        
        episodes.sort(key=lambda x: x['episode_number'], reverse=True)
        
        self._log(f"✓ Found {len(episodes)} episodes in virtual folder", xbmc.LOGINFO)
        return episodes
    
    # ==========================================================================
    # YOUR PROVEN STREAM EXTRACTION LOGIC
    # ==========================================================================
    
    def get_stream_url(self, episode_url, force_refresh=False):
        """
        YOUR PROVEN get_stream_url() METHOD
        
        Smart caching strategy:
        1. NO URL caching (tokens expire!)
        2. Cache server INDEX (which server worked)
        3. Test cached server FIRST on next playback
        
        Returns:
            list: Stream options [{'name': '...', 'url': '...', 'quality': '...'}]
        """
        cache_key = episode_url
        
        self._log(f"Extracting stream for: {episode_url[:80]}...", xbmc.LOGINFO)
        
        # Step 1: Get episode page
        response = self._request(episode_url)
        if not response:
            self._log("Failed to fetch episode page", xbmc.LOGERROR)
            return []
        
        html = response.text
        
        # Step 2: Find embed URLs (YOUR PROVEN PATTERNS!)
        embed_patterns = [
            r'https://tukipasti\.[^\s\'"]+',
            r'https://dwish\.[^\s\'"]+',
        ]
        
        embed_urls = []
        for pattern in embed_patterns:
            matches = re.findall(pattern, html)
            embed_urls.extend(matches)
        
        # Also look for iframe sources
        iframe_matches = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
        embed_urls.extend(iframe_matches)
        
        if not embed_urls:
            self._log("No embed URLs found", xbmc.LOGWARNING)
            return []
        
        self._log(f"Found {len(embed_urls)} potential embed URLs", xbmc.LOGINFO)
        
        # Step 3: Check SERVER INDEX cache
        cached_server_index = self.cache.get_server_index(cache_key) if not force_refresh else None
        
        # Test cached server FIRST if available
        if cached_server_index is not None and cached_server_index < len(embed_urls):
            self._log(f"Testing CACHED server {cached_server_index + 1} first", xbmc.LOGINFO)
            
            embed_url = embed_urls[cached_server_index]
            if not embed_url.startswith('http'):
                embed_url = urljoin(episode_url, embed_url)
            
            stream_url = self._resolve_iframe(embed_url)
            
            if stream_url:
                self._log(f"✓ Cached server {cached_server_index + 1} returned stream URL", xbmc.LOGINFO)
                
                # Cache server index
                self.cache.set_server_index(cache_key, cached_server_index)
                
                return [{
                    'name': f'Server {cached_server_index + 1} (Cached)',
                    'url': stream_url,
                    'quality': self._guess_quality(stream_url)
                }]
            else:
                self._log(f"Cached server {cached_server_index + 1} returned no stream", xbmc.LOGWARNING)
        
        # Step 4: Test first N servers
        max_to_test = min(len(embed_urls), MAX_SERVERS_TO_TEST)
        self._log(f"Testing first {max_to_test} servers...", xbmc.LOGINFO)
        
        for idx, embed_url in enumerate(embed_urls[:max_to_test]):
            if idx == cached_server_index:
                continue
            
            if not embed_url.startswith('http'):
                embed_url = urljoin(episode_url, embed_url)
            
            self._log(f"Server {idx + 1}/{max_to_test}: {embed_url[:60]}...", xbmc.LOGDEBUG)
            
            stream_url = self._resolve_iframe(embed_url)
            
            if stream_url:
                self._log(f"SUCCESS: Server {idx + 1} verified!", xbmc.LOGINFO)
                
                # Cache server index
                self.cache.set_server_index(cache_key, idx)
                
                return [{
                    'name': f'Server {idx + 1}',
                    'url': stream_url,
                    'quality': self._guess_quality(stream_url)
                }]
        
        # Step 5: Fallback to remaining servers
        if len(embed_urls) > max_to_test:
            self._log(f"Trying remaining {len(embed_urls) - max_to_test} servers...", xbmc.LOGINFO)
            
            for idx, embed_url in enumerate(embed_urls[max_to_test:], start=max_to_test):
                if idx == cached_server_index:
                    continue
                
                if not embed_url.startswith('http'):
                    embed_url = urljoin(episode_url, embed_url)
                
                stream_url = self._resolve_iframe(embed_url)
                
                if stream_url:
                    self._log(f"SUCCESS: Server {idx + 1} verified!", xbmc.LOGINFO)
                    
                    # Cache server index
                    self.cache.set_server_index(cache_key, idx)
                    
                    return [{
                        'name': f'Server {idx + 1}',
                        'url': stream_url,
                        'quality': self._guess_quality(stream_url)
                    }]
        
        self._log("No working stream found", xbmc.LOGERROR)
        return []
    
    def _resolve_iframe(self, iframe_url, max_depth=3):
        """
        YOUR PROVEN iframe resolver
        Handles OK.RU, Tukipasti, Dwish, and nested iframes
        """
        if max_depth <= 0:
            self._log("Max iframe depth reached", xbmc.LOGWARNING)
            return None
        
        self._log(f"Resolving iframe (depth {3-max_depth}): {iframe_url[:80]}...", xbmc.LOGDEBUG)
        
        try:
            response = self._request(iframe_url)
            if not response:
                return None
            
            html_content = response.text
            
            # OK.RU specific handling
            if 'ok.ru' in iframe_url or 'ok.ru' in html_content:
                self._log("Detected OK.RU embed", xbmc.LOGINFO)
                
                # Method 1: hlsManifestUrl
                hls_match = re.search(r'"hlsManifestUrl"\s*:\s*"([^"]+)"', html_content)
                if hls_match:
                    url = hls_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                    if url.startswith('http'):
                        self._log("Found OK.RU HLS manifest", xbmc.LOGINFO)
                        return url
                
                # Method 2: Videos array
                videos_match = re.search(r'"videos"\s*:\s*\[([^\]]+)\]', html_content)
                if videos_match:
                    for quality in ['hd', 'sd', 'low']:
                        q_match = re.search(
                            rf'"name"\s*:\s*"{quality}"\s*,\s*"url"\s*:\s*"([^"]+)"',
                            videos_match.group(1)
                        )
                        if q_match:
                            url = q_match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                            if url.startswith('http'):
                                self._log(f"Found OK.RU {quality} quality", xbmc.LOGINFO)
                                return url
            
            # Tukipasti/Dwish specific
            if 'tukipasti' in iframe_url or 'dwish' in iframe_url:
                self._log("Detected Tukipasti/Dwish embed", xbmc.LOGINFO)
                m3u8_match = re.search(r'(https?://[^\s"\']*\.m3u8[^\s"\']*)', html_content)
                if m3u8_match:
                    url = m3u8_match.group(1)
                    self._log("Found Tukipasti/Dwish m3u8", xbmc.LOGINFO)
                    return url
            
            # Generic extraction using YOUR PATTERNS
            stream_url = self._extract_stream_from_html(html_content)
            if stream_url:
                return stream_url
            
            # Nested iframe
            nested = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html_content, re.IGNORECASE)
            if nested:
                next_url = nested.group(1)
                if not next_url.startswith('http'):
                    next_url = urljoin(iframe_url, next_url)
                
                if not next_url.startswith('about:') and not next_url.startswith('javascript:'):
                    return self._resolve_iframe(next_url, max_depth - 1)
            
            return None
            
        except Exception as e:
            self._log(f"Error resolving iframe: {e}", xbmc.LOGERROR)
            return None
    
    def _extract_stream_from_html(self, html_content):
        """
        Extract stream URL using YOUR PROVEN PATTERNS
        """
        # Unpack JavaScript if needed
        if 'eval(function(p,a,c,k,e,d)' in html_content:
            unpacked = unpack_js(html_content)
            if unpacked:
                html_content = unpacked
        
        # Try each pattern from YOUR config
        for pattern, name in STREAM_PATTERNS:
            match = re.search(pattern, html_content)
            if match:
                url = match.group(1) if match.lastindex else match.group(0)
                url = url.replace('\\/', '/').replace('\\u0026', '&').replace('&amp;', '&')
                
                if url.startswith('http') and any(ext in url.lower() for ext in ['.m3u8', '.mp4', '.mkv']):
                    self._log(f"Extracted via {name}: {url[:100]}", xbmc.LOGINFO)
                    return url
        
        return None
    
    def _test_stream_url(self, url):
        """
        YOUR PROVEN stream URL validation
        """
        try:
            head_response = self.session.head(url, timeout=3, allow_redirects=True)
            
            if head_response.status_code == 200:
                return True
            elif head_response.status_code in [301, 302, 303, 307, 308]:
                return True
            elif head_response.status_code == 403:
                # Try GET with range header
                get_response = self.session.get(
                    url,
                    headers={'Range': 'bytes=0-512'},
                    timeout=3
                )
                return get_response.status_code in [200, 206]
            
            return False
        except:
            return False
    
    def _guess_quality(self, url):
        """Guess quality from URL"""
        url_lower = url.lower()
        if '1080' in url_lower or 'fhd' in url_lower:
            return '1080p'
        elif '720' in url_lower or 'hd' in url_lower:
            return '720p'
        elif '480' in url_lower or 'sd' in url_lower:
            return '480p'
        return 'Auto'
    
    # === BaseEngine interface methods ===
    
    def search_series(self, series_names):
        """Implement BaseEngine abstract method"""
        return self.search(series_names)
    
    def get_episode_url(self, search_results, season, episode):
        """Find specific episode URL"""
        for ep in search_results:
            if ep.get('episode_number') == episode and ep.get('season', 1) == season:
                return ep.get('episode_url')
        return None
    
    def get_engine_name(self):
        """Get engine name"""
        return "Turkish123"
    
    def get_audio_language(self):
        """Get audio language"""
        return "en"
