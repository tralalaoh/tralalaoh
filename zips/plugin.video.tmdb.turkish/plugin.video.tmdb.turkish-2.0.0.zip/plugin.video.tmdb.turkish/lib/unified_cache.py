"""
Unified Series Cache Manager
Based on dual-URL approach: stores BOTH 3SK and Turkish123 URLs per episode

Episode Structure:
{
    'episode_number': 1,
    'season': 1,
    'title': 'Episode 1',
    'urls': {
        'ar': 'https://3sk.co/...',         # Arabic URL (3SK)
        'en': 'https://turkish123.org/...'  # English URL (Turkish123)
    }
}
"""

import sqlite3
import json
import os
import time
from datetime import datetime, timedelta


class UnifiedSeriesCache:
    """
    Unified cache that stores MULTIPLE URLs per episode
    
    Key Innovation:
    - Each episode can have BOTH 3SK URL and Turkish123 URL
    - Lazy loading: only fetch URLs for requested language
    - No cache invalidation on preference change
    - Automatic merging of new URLs into existing cache
    """
    
    def __init__(self, cache_dir):
        """
        Initialize unified cache
        
        Args:
            cache_dir: Directory to store cache.db
        """
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
        self.db_path = os.path.join(cache_dir, 'unified_cache.db')
        self._init_db()
    
    def _init_db(self):
        """Create tables if they don't exist"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Unified series cache table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS unified_series (
                tmdb_id TEXT PRIMARY KEY,
                series_name TEXT,
                episodes_json TEXT,
                total_episodes INTEGER,
                cached_at INTEGER,
                expires_at INTEGER
            )
        ''')
        
        # Create indexes for faster queries
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_expires 
            ON unified_series(expires_at)
        ''')
        
        conn.commit()
        conn.close()
    
    def get_series(self, tmdb_id):
        """
        Get cached series with all available URLs
        
        Args:
            tmdb_id: TMDB series ID
            
        Returns:
            dict with episodes or None if not cached/expired
            {
                'series_name': str,
                'episodes': [
                    {
                        'episode_number': int,
                        'season': int,
                        'title': str,
                        'urls': {
                            'ar': 'https://...',  # May be missing
                            'en': 'https://...'   # May be missing
                        }
                    },
                    ...
                ],
                'total_episodes': int,
                'cached_at': datetime
            }
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT series_name, episodes_json, total_episodes, cached_at, expires_at
            FROM unified_series
            WHERE tmdb_id = ?
        ''', (str(tmdb_id),))
        
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return None
        
        series_name, episodes_json, total_episodes, cached_at, expires_at = row
        
        # Check if expired
        now = int(time.time())
        if now > expires_at:
            return None
        
        # Parse episodes
        try:
            episodes = json.loads(episodes_json)
        except:
            return None
        
        return {
            'series_name': series_name,
            'episodes': episodes,
            'total_episodes': total_episodes,
            'cached_at': datetime.fromtimestamp(cached_at)
        }
    
    def has_language_urls(self, tmdb_id, language):
        """
        Check if cache has URLs for specific language
        
        Args:
            tmdb_id: TMDB series ID
            language: 'ar' or 'en'
        
        Returns:
            bool: True if at least one episode has URL for this language
        """
        cached = self.get_series(tmdb_id)
        if not cached:
            print(f"UnifiedCache: has_language_urls({language}) → No cached series")
            return False
        
        # Check if any episode has this language URL
        found_count = 0
        for ep in cached['episodes']:
            if language in ep.get('urls', {}):
                found_count += 1
        
        print(f"UnifiedCache: has_language_urls({language}) → Found {found_count}/{len(cached['episodes'])} episodes with {language} URLs")
        
        if found_count > 0:
            # Debug: Show sample episode structure
            sample_ep = cached['episodes'][0]
            print(f"UnifiedCache: Sample episode structure: {sample_ep}")
        
        return found_count > 0
    
    def merge_language_urls(self, tmdb_id, series_name, new_episodes, language, cache_days=7):
        """
        Merge new URLs for a language into existing cache
        
        This is the KEY FUNCTION that implements your brilliant approach!
        
        Args:
            tmdb_id: TMDB series ID
            series_name: Series name for display
            new_episodes: List of episodes with URLs for ONE language
                [
                    {'episode_number': 1, 'season': 1, 'title': '...', 'episode_url': 'https://...'},
                    ...
                ]
            language: 'ar' or 'en'
            cache_days: How many days to keep cache
        """
        # Get existing cache
        cached = self.get_series(tmdb_id)
        
        if cached:
            # MERGE MODE: Add new URLs to existing episodes
            existing_episodes = {ep['episode_number']: ep for ep in cached['episodes']}
            
            for new_ep in new_episodes:
                ep_num = new_ep['episode_number']
                season = new_ep.get('season', 1)
                
                if ep_num in existing_episodes:
                    # Episode exists - add new language URL
                    existing_episodes[ep_num]['urls'][language] = new_ep.get('episode_url') or new_ep.get('url')
                else:
                    # New episode - create it
                    existing_episodes[ep_num] = {
                        'episode_number': ep_num,
                        'season': season,
                        'title': new_ep.get('episode_title') or new_ep.get('title', f'Episode {ep_num}'),
                        'urls': {
                            language: new_ep.get('episode_url') or new_ep.get('url')
                        }
                    }
            
            # Convert back to list
            merged_episodes = list(existing_episodes.values())
            merged_episodes.sort(key=lambda x: x['episode_number'], reverse=True)
        else:
            # NEW SERIES: Create fresh cache
            merged_episodes = []
            for ep in new_episodes:
                merged_episodes.append({
                    'episode_number': ep['episode_number'],
                    'season': ep.get('season', 1),
                    'title': ep.get('episode_title') or ep.get('title', f'Episode {ep["episode_number"]}'),
                    'urls': {
                        language: ep.get('episode_url') or ep.get('url')
                    }
                })
            merged_episodes.sort(key=lambda x: x['episode_number'], reverse=True)
        
        # Save to database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        now = int(time.time())
        expires_at = now + (cache_days * 24 * 60 * 60)
        
        episodes_json = json.dumps(merged_episodes, ensure_ascii=False)
        
        cursor.execute('''
            INSERT OR REPLACE INTO unified_series 
            (tmdb_id, series_name, episodes_json, total_episodes, cached_at, expires_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            str(tmdb_id),
            series_name,
            episodes_json,
            len(merged_episodes),
            now,
            expires_at
        ))
        
        conn.commit()
        conn.close()
    
    def get_episode_url(self, tmdb_id, season, episode, language):
        """
        Get episode URL for specific language
        
        Args:
            tmdb_id: TMDB series ID
            season: Season number
            episode: Episode number
            language: 'ar' or 'en'
        
        Returns:
            str: Episode URL or None if not found
        """
        cached = self.get_series(tmdb_id)
        if not cached:
            return None
        
        for ep in cached['episodes']:
            if ep['episode_number'] == episode and ep.get('season', 1) == season:
                return ep.get('urls', {}).get(language)
        
        return None
    
    def clear_old(self):
        """Clear expired cache entries"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        now = int(time.time())
        cursor.execute('DELETE FROM unified_series WHERE expires_at < ?', (now,))
        deleted = cursor.rowcount
        
        conn.commit()
        conn.close()
        
        if deleted > 0:
            print(f"UnifiedCache: Cleared {deleted} expired entries")


def get_unified_cache(cache_dir):
    """Factory function to get cache instance"""
    return UnifiedSeriesCache(cache_dir)
