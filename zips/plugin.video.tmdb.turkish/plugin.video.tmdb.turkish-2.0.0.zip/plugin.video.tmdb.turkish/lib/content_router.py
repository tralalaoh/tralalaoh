# -*- coding: utf-8 -*-
"""
Content Router
Bridges TMDB frontend with streaming engines (3SK, Turkish123, etc.)
"""

try:
    import xbmc
    import xbmcgui
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGDEBUG = 0
        LOGINFO = 1
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"ContentRouter: {msg}")
    
    class xbmcgui:
        class DialogProgress:
            def create(self, *args): pass
            def update(self, percent, *args): pass
            def close(self): pass


# Handle imports for both Kodi and standalone
try:
    from .engines import Engine3SK, EngineTurkish123
    from .unified_cache import get_unified_cache
except ImportError:
    # Standalone execution
    from engines import Engine3SK, EngineTurkish123
    from unified_cache import get_unified_cache


class ContentRouter:
    """
    Routes playback requests to appropriate streaming engine
    
    Workflow:
    1. Get series metadata from TMDB
    2. Get all name translations (Turkish, Arabic, English, etc.)
    3. Check user audio preference
    4. Try engines in order (3SK for Arabic, Turkish123 for English)
    5. Return stream URL or None
    
    PHASE 2C: SQLite Caching
    - Cache virtual series folders (episode lists)
    - Only scrape streams on-demand when user clicks play
    - Cache lasts 7 days (configurable)
    """
    
    def __init__(self, tmdb_api, settings, cache_dir=None):
        """
        Initialize content router
        
        Args:
            tmdb_api: TMDBApi instance
            settings: Addon settings object
            cache_dir: Directory for SQLite cache (optional)
        """
        self.tmdb = tmdb_api
        self.settings = settings
        
        # Initialize UNIFIED series cache (PHASE 2D - Dual URL Storage)
        self.series_cache = get_unified_cache(cache_dir)
        self._log(f"âœ“ Unified series cache initialized", xbmc.LOGINFO)
        
        # Initialize engines
        self._log("Initializing streaming engines...", xbmc.LOGINFO)
        
        # 3SK Engine (Arabic audio)
        try:
            self.engine_3sk = Engine3SK()
            self._log("âœ“ 3SK Engine ready", xbmc.LOGINFO)
        except Exception as e:
            self._log(f"âœ— 3SK Engine failed: {e}", xbmc.LOGERROR)
            self.engine_3sk = None
        
        # Turkish123 Engine (English audio)
        try:
            self.engine_turkish123 = EngineTurkish123()
            self._log("âœ“ Turkish123 Engine ready", xbmc.LOGINFO)
        except Exception as e:
            self._log(f"âœ— Turkish123 Engine failed: {e}", xbmc.LOGERROR)
            self.engine_turkish123 = None
        
        self._log("ContentRouter initialized", xbmc.LOGINFO)
    
    def play_episode(self, tmdb_id, season, episode, episode_title=""):
        """
        Play episode using ON-DEMAND stream scraping
        
        PHASE 2C Architecture:
        1. Get episode URL from SQLite cache (instant!)
        2. Scrape servers for THIS episode only (on-demand!)
        3. Return working stream
        
        Args:
            tmdb_id (int): TMDB series ID
            season (int): Season number
            episode (int): Episode number
            episode_title (str): Episode title for display (optional)
        
        Returns:
            dict: Playback result or None
                {
                    'stream_url': 'https://...',
                    'engine': '3sk',
                    'quality': 'HD',
                    'episode_url': 'https://...'
                }
        """
        self._log(f"=== PLAY EPISODE (ON-DEMAND) - UNIFIED CACHE ===", xbmc.LOGINFO)
        self._log(f"TMDB ID: {tmdb_id}, S{season:02d}E{episode:02d}", xbmc.LOGINFO)
        
        try:
            # Step 1: Get user preference (ar or en)
            audio_pref = self._get_audio_preference()
            language = audio_pref  # Always 'ar' or 'en'
            
            self._log(f"Audio preference: {language}", xbmc.LOGINFO)
            
            # Step 2: Get episode URL for language
            episode_url = self.series_cache.get_episode_url(tmdb_id, season, episode, language)
            
            if not episode_url:
                self._log(f"Episode S{season:02d}E{episode:02d} not found for language '{language}'!", xbmc.LOGERROR)
                self._log("Episode list may need refreshing", xbmc.LOGWARNING)
                return None
            
            self._log(f"Episode URL ({language}): {episode_url[:80]}...", xbmc.LOGINFO)
            
            # Step 3: Use corresponding engine
            if language == 'ar':
                engine = self.engine_3sk
                engine_name = '3SK'
            else:
                engine = self.engine_turkish123
                engine_name = 'Turkish123'
            
            if not engine:
                self._log(f"{engine_name} engine not available!", xbmc.LOGERROR)
                return None
            
            # Step 4: Scrape stream
            self._log(f"Scraping {engine_name} servers...", xbmc.LOGINFO)
            stream_options = engine.get_stream_url(episode_url)
            
            if not stream_options or len(stream_options) == 0:
                self._log("No working stream found", xbmc.LOGWARNING)
                return None
            
            # Get first working stream
            first_stream = stream_options[0]
            stream_url = first_stream.get('url')
            quality = first_stream.get('quality', 'Auto')
            
            if not stream_url:
                self._log("Stream URL missing from result", xbmc.LOGERROR)
                return None
            
            self._log(f"Stream found: {stream_url[:80]}...", xbmc.LOGINFO)
            self._log(f"Quality: {quality}", xbmc.LOGINFO)
            
            # Return playback result
            return {
                'stream_url': stream_url,  # Now it's a string!
                'engine': '3sk',
                'quality': quality,
                'episode_url': episode_url
            }
        
        except Exception as e:
            self._log(f"Play episode error: {e}", xbmc.LOGERROR)
            import traceback
            self._log(traceback.format_exc(), xbmc.LOGERROR)
            return None
    
    def get_episodes(self, tmdb_id, force_refresh=False):
        """
        Get all episodes for a series (with caching!)
        
        PHASE 2C: SQLite Caching Architecture
        1. Check cache first (instant if available)
        2. If not cached or expired:
           - Get series metadata from TMDB
           - Get name translations
           - Search 3SK (get ANY episode)
           - Build virtual folder from landing page (ALL episodes)
           - Cache to SQLite (lasts 7 days)
        3. Return episode list
        
        Args:
            tmdb_id (int): TMDB series ID
            force_refresh (bool): Force rebuild cache
        
        Returns:
            dict: Episode data or None
            {
                'series_name': str,
                'total_episodes': int,
                'cached_at': datetime,
                'episodes': [
                    {'title': str, 'url': str, 'episode_number': int, 'season': int},
                    ...
                ]
            }
        """
        self._log(f"=== GET EPISODES (TMDB {tmdb_id}) - UNIFIED CACHE ===", xbmc.LOGINFO)
        
        # Step 1: Get user audio preference (ar or en)
        audio_pref = self._get_audio_preference()
        required_language = audio_pref  # Always 'ar' or 'en'
        
        self._log(f"User preference: {audio_pref}", xbmc.LOGINFO)
        
        # Step 2: Check if cache has URLs for required language
        if not force_refresh:
            cached = self.series_cache.get_series(tmdb_id)
            
            if cached:
                self._log(f"Found cached series with {len(cached['episodes'])} episodes", xbmc.LOGINFO)
                
                # Check if we have URLs for the required language
                has_urls = self.series_cache.has_language_urls(tmdb_id, required_language)
                self._log(f"Cache check: has_{required_language}_urls = {has_urls}", xbmc.LOGINFO)
                
                if has_urls:
                    self._log(f"âœ“ CACHE HIT! Series has {required_language} URLs", xbmc.LOGINFO)
                    self._log(f"  Cached at: {cached['cached_at']}", xbmc.LOGINFO)
                    self._log(f"  Total episodes: {len(cached['episodes'])}", xbmc.LOGINFO)
                    return cached
                else:
                    self._log(f"âš  MISSING {required_language} URLs! Will fetch them...", xbmc.LOGWARNING)
                    # Fall through to fetch missing URLs
            else:
                self._log("No cached series found", xbmc.LOGINFO)
        
        self._log("Fetching episode URLs (will merge with existing cache)...", xbmc.LOGINFO)
        
        # Step 3: Get series metadata from TMDB
        self._log("Getting series metadata from TMDB", xbmc.LOGINFO)
        metadata = self.tmdb.get_series_details(tmdb_id)
        
        if not metadata:
            self._log("Failed to get TMDB metadata", xbmc.LOGERROR)
            return None
        
        series_name = metadata['name']
        self._log(f"Series: {series_name}", xbmc.LOGINFO)
        
        # Step 4: Get name translations
        self._log("Getting name translations from TMDB", xbmc.LOGINFO)
        translations = self.tmdb.get_name_translations(tmdb_id)
        names = translations.get('names', [])
        
        if not names:
            self._log("No names found", xbmc.LOGWARNING)
            return None
        
        self._log(f"Search names: {names[:3]}...", xbmc.LOGINFO)
        
        # Step 5: Use the engine for the required language
        language = required_language  # 'ar' or 'en'
        
        if language == 'ar':
            engine = self.engine_3sk
            lang_name = 'Arabic'
        else:
            engine = self.engine_turkish123
            lang_name = 'English'
        
        if not engine:
            self._log(f"{lang_name} engine not available", xbmc.LOGERROR)
            return None
        
        # Step 6: Fetch URLs from engine
        self._log(f"Fetching {lang_name} URLs...", xbmc.LOGINFO)
        
        # Search and build virtual folder
        if language == 'ar':
            arabic_names = self._filter_arabic_names(names)
            if not arabic_names:
                self._log("No Arabic names available", xbmc.LOGWARNING)
                return None
            
            search_results = engine.search_series(arabic_names)
        else:
            search_results = engine.search(names)
        
        if not search_results:
            self._log(f"No {lang_name} search results", xbmc.LOGWARNING)
            return None
        
        # Build virtual folder
        virtual_folder = engine.build_virtual_series_folder(search_results)
        
        if not virtual_folder:
            self._log(f"Failed to build {lang_name} virtual folder", xbmc.LOGWARNING)
            return None
        
        # MERGE URLs into cache!
        self._log(f"Merging {len(virtual_folder)} {lang_name} URLs into cache...", xbmc.LOGINFO)
        self.series_cache.merge_language_urls(tmdb_id, series_name, virtual_folder, language)
        
        # Return updated cache
        return self.series_cache.get_series(tmdb_id)
    def _filter_arabic_names(self, names):
        """Filter list to only Arabic names"""
        # Simple heuristic: Check for Arabic Unicode range
        arabic_names = []
        for name in names:
            if any('\u0600' <= c <= '\u06FF' or '\u0750' <= c <= '\u077F' for c in name):
                arabic_names.append(name)
        
        # If no Arabic names detected, return all names (let engine decide)
        return arabic_names if arabic_names else names[:3]
    
    def _try_3sk_engine(self, names, season, episode, progress=None):
        """
        Attempt playback with 3SK engine
        
        Args:
            names (list): Series names to search
            season (int): Season number
            episode (int): Episode number
            progress: Progress dialog (optional)
        
        Returns:
            dict: Playback result or None
        """
        try:
            self._log("=== TRYING 3SK ENGINE ===", xbmc.LOGINFO)
            
            # Search for series
            if KODI_ENV and progress:
                progress.update(45, 'Searching 3SK database...')
            
            search_results = self.engine_3sk.search_series(names)
            
            if not search_results:
                self._log("3SK: No results found", xbmc.LOGWARNING)
                return None
            
            self._log(f"3SK: Found {len(search_results)} results", xbmc.LOGINFO)
            
            # Find specific episode
            if KODI_ENV and progress:
                progress.update(60, f'Finding S{season:02d}E{episode:02d}...')
            
            episode_url = self.engine_3sk.get_episode_url(search_results, season, episode)
            
            if not episode_url:
                self._log(f"3SK: Episode S{season:02d}E{episode:02d} not found", xbmc.LOGWARNING)
                return None
            
            self._log(f"3SK: Found episode URL", xbmc.LOGINFO)
            
            # Get stream URL (uses YOUR smart caching!)
            if KODI_ENV and progress:
                progress.update(75, 'Extracting stream URL...')
            
            stream_urls = self.engine_3sk.get_stream_url(episode_url)
            
            if stream_urls and len(stream_urls) > 0:
                self._log("3SK: âœ“ Stream found!", xbmc.LOGINFO)
                return {
                    'stream_url': stream_urls[0]['url'],
                    'engine': '3sk',
                    'audio_language': 'Arabic',
                    'quality': stream_urls[0].get('quality', 'Auto'),
                    'episode_url': episode_url,
                    'server_name': stream_urls[0].get('name', 'Server 1')
                }
            
            self._log("3SK: No working streams", xbmc.LOGWARNING)
            return None
        
        except Exception as e:
            self._log(f"3SK engine error: {e}", xbmc.LOGERROR)
            import traceback
            self._log(traceback.format_exc(), xbmc.LOGERROR)
            return None
    
    def _get_audio_preference(self):
        """
        Get user audio language preference
        
        Returns:
            str: 'ar' (Arabic/3SK) or 'en' (English/Turkish123)
        """
        try:
            if KODI_ENV:
                # Boolean setting: True = Arabic (3SK), False = English (Turkish123)
                use_arabic_raw = self.settings.getSetting('audio_language')
                
                # DIAGNOSTIC LOGGING
                self._log("="*50, xbmc.LOGINFO)
                self._log("AUDIO PREFERENCE CHECK", xbmc.LOGINFO)
                self._log(f"Raw value: '{use_arabic_raw}'", xbmc.LOGINFO)
                self._log(f"Type: {type(use_arabic_raw).__name__}", xbmc.LOGINFO)
                
                # Convert to boolean if it's a string
                if isinstance(use_arabic_raw, str):
                    use_arabic = use_arabic_raw.lower() in ('true', '1', 'yes')
                    self._log(f"String '{use_arabic_raw}' -> Boolean {use_arabic}", xbmc.LOGINFO)
                elif isinstance(use_arabic_raw, bool):
                    use_arabic = use_arabic_raw
                    self._log(f"Already boolean: {use_arabic}", xbmc.LOGINFO)
                else:
                    self._log(f"WARNING: Unexpected type! Defaulting to False", xbmc.LOGWARNING)
                    use_arabic = False
                
                pref = 'ar' if use_arabic else 'en'
                
                self._log(f"Final preference: '{pref}'", xbmc.LOGINFO)
                
                if pref == 'ar':
                    self._log("===> WILL USE: 3SK Engine (Arabic Audio)", xbmc.LOGINFO)
                else:
                    self._log("===> WILL USE: Turkish123 Engine (English Audio)", xbmc.LOGINFO)
                
                self._log("="*50, xbmc.LOGINFO)
                
                return pref
            else:
                self._log("Test mode: defaulting to 'en'", xbmc.LOGDEBUG)
                return 'en'  # Default for testing
        except Exception as e:
            self._log(f"ERROR reading audio preference: {e}", xbmc.LOGERROR)
            import traceback
            self._log(f"Traceback:\n{traceback.format_exc()}", xbmc.LOGERROR)
            self._log("Falling back to English (Turkish123)", xbmc.LOGWARNING)
            return 'en'  # Default to English
    
    def _log(self, message, level=xbmc.LOGINFO):
        """Log message"""
        if KODI_ENV:
            xbmc.log(f"ContentRouter: {message}", level)
        else:
            print(f"ContentRouter: {message}")
