# -*- coding: utf-8 -*-
"""
Turkish Series (TMDB) - Library Module
"""

from .tmdb_api import TMDBApi

__version__ = '1.0.0'
__all__ = ['TMDBApi']
