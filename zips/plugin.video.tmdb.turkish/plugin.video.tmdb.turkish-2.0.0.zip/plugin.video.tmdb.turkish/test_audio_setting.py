#!/usr/bin/env python3
"""
Test Audio Preference Setting
==============================

This script simulates reading the audio_language setting to help diagnose issues.
Run this from your addon directory.
"""

import os
import sys
import xml.etree.ElementTree as ET

def test_setting_read():
    """Test reading the audio_language setting"""
    
    print("\n" + "="*60)
    print("  Testing Audio Preference Setting")
    print("="*60 + "\n")
    
    # Check if we're in the addon directory
    if not os.path.exists('addon.xml'):
        print("❌ ERROR: Must run from addon directory!")
        print(f"   Current: {os.getcwd()}")
        print(f"   Expected: .../plugin.video.tmdb.turkish/")
        return False
    
    # Read addon.xml to get addon ID
    try:
        tree = ET.parse('addon.xml')
        root = tree.getroot()
        addon_id = root.get('id')
        print(f"✓ Addon ID: {addon_id}")
    except Exception as e:
        print(f"❌ Error reading addon.xml: {e}")
        return False
    
    # Find the settings file
    # In Kodi, settings are stored in userdata/addon_data/<addon_id>/settings.xml
    possible_paths = [
        os.path.expanduser(f'~/.kodi/userdata/addon_data/{addon_id}/settings.xml'),
        os.path.expanduser(f'~/.var/app/tv.kodi.Kodi/.kodi/userdata/addon_data/{addon_id}/settings.xml'),
    ]
    
    settings_path = None
    for path in possible_paths:
        if os.path.exists(path):
            settings_path = path
            break
    
    if settings_path:
        print(f"✓ Settings file found: {settings_path}\n")
        
        try:
            # Read the settings
            tree = ET.parse(settings_path)
            root = tree.getroot()
            
            # Find audio_language setting
            audio_lang = None
            for setting in root.findall('.//setting'):
                if setting.get('id') == 'audio_language':
                    audio_lang = setting.get('value')
                    break
            
            if audio_lang is not None:
                print(f"Current Setting Value:")
                print(f"  audio_language = '{audio_lang}'")
                print()
                
                # Interpret the value
                if audio_lang.lower() in ('true', '1', 'yes'):
                    print(f"✓ Interpretation: TRUE")
                    print(f"  → Should use: 3SK Engine (Arabic Audio)")
                else:
                    print(f"✓ Interpretation: FALSE")
                    print(f"  → Should use: Turkish123 Engine (English Audio)")
                print()
                
                return True
            else:
                print(f"❌ audio_language setting not found in settings file")
                print(f"   This might be first run - setting not saved yet")
                print()
                print(f"Default value from resources/settings.xml should be used")
                
                # Check resources/settings.xml
                if os.path.exists('resources/settings.xml'):
                    tree = ET.parse('resources/settings.xml')
                    root = tree.getroot()
                    
                    for setting in root.findall('.//setting'):
                        if setting.get('id') == 'audio_language':
                            default = setting.get('default', 'not specified')
                            print(f"   Default value: '{default}'")
                            
                            if default.lower() in ('true', '1'):
                                print(f"   → Default is: Arabic (3SK)")
                            else:
                                print(f"   → Default is: English (Turkish123)")
                            break
                
                return False
                
        except Exception as e:
            print(f"❌ Error reading settings: {e}")
            return False
    else:
        print(f"⚠ Settings file not found")
        print(f"   Checked:")
        for path in possible_paths:
            print(f"   - {path}")
        print()
        print(f"This is normal if addon hasn't been configured yet.")
        print(f"The default value from resources/settings.xml will be used.")
        print()
        
        # Check resources/settings.xml
        if os.path.exists('resources/settings.xml'):
            print(f"Checking resources/settings.xml for default value...")
            try:
                tree = ET.parse('resources/settings.xml')
                root = tree.getroot()
                
                for setting in root.findall('.//setting'):
                    if setting.get('id') == 'audio_language':
                        default = setting.get('default', 'not specified')
                        print(f"✓ Default value: '{default}'")
                        
                        if default.lower() in ('true', '1'):
                            print(f"  → Default is: Arabic (3SK)")
                        else:
                            print(f"  → Default is: English (Turkish123)")
                        break
            except Exception as e:
                print(f"❌ Error reading resources/settings.xml: {e}")
        
        return False

def show_next_steps():
    """Show what to do next"""
    print("\n" + "="*60)
    print("  Next Steps")
    print("="*60 + "\n")
    
    print("1. Apply the fix to content_router.py")
    print("   (See AUDIO_PREFERENCE_FIX_README.md)")
    print()
    print("2. Restart Kodi")
    print()
    print("3. Enable debug logging:")
    print("   Settings → System → Logging → Enable debug logging")
    print()
    print("4. Open the addon and play a series")
    print()
    print("5. Check Kodi log for these lines:")
    print("   grep 'AUDIO PREFERENCE CHECK' ~/.kodi/temp/kodi.log")
    print("   (or Flatpak path)")
    print()
    print("6. Look for:")
    print("   'WILL USE: 3SK Engine' or 'WILL USE: Turkish123 Engine'")
    print()

if __name__ == '__main__':
    success = test_setting_read()
    show_next_steps()
    
    if success:
        print("="*60)
        print("✓ Test Complete - Setting found and interpreted")
        print("="*60 + "\n")
    else:
        print("="*60)
        print("⚠ Test Incomplete - But this is OK for first run")
        print("="*60 + "\n")
