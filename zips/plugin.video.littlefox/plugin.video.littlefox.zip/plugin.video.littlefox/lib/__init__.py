# -*- coding: utf-8 -*-
"""
Little Fox - Turkish Series Player Library
🦊 Your clever companion for Turkish series streaming!

Version 2.5.2 - Little Fox Release
"""

__version__ = '2.5.3'
__author__ = 'Hamza'
__name__ = 'Little Fox'
