# -*- coding: utf-8 -*-
"""
EgyDead Provider (Arabic Audio)
Extracts embed URLs from egydead.rip

Based on egydead_scraper.py
"""

import re
from urllib.parse import urljoin, quote
from bs4 import BeautifulSoup

try:
    import xbmc
    KODI_ENV = True
except ImportError:
    KODI_ENV = False
    class xbmc:
        LOGDEBUG = 0
        LOGINFO = 1
        LOGWARNING = 2
        LOGERROR = 3
        @staticmethod
        def log(msg, level=1):
            print(f"🦊 [EgyDead] {msg}")

from .base_provider import BaseProvider


class ProviderEgyDead(BaseProvider):
    """
    EgyDead provider - Arabic content
    
    IMPORTANT: This provider extracts UNRESOLVED embed URLs only!
    """
    
    SEARCH_LANGUAGES = ['ar', 'tr']  # Arabic and Turkish only (skip English)
    
    def __init__(self):
        """Initialize EgyDead provider"""
        super().__init__()
        
        self.base_url = "https://egydead.rip"
        
        self.session.headers.update({
            'Accept-Language': 'ar,en-US;q=0.7,en;q=0.3',
            'Referer': self.base_url + '/'
        })
        
        self._log("EgyDead Provider initialized", xbmc.LOGINFO)
    
    def get_name(self):
        """Get provider name"""
        return "EgyDead"
    
    def get_audio_language(self):
        """
        Get audio language
        
        Note: EgyDead has both:
        - Dubbed (Arabic audio)
        - Subtitled (Original audio + Arabic subs)
        
        This returns 'ar' as primary, but actual audio varies per content
        """
        return "ar"  # Primary language (Arabic dubbed or Arabic subs)
    
    def search_series(self, series_names):
        """
        Search EgyDead for series using Turkish and Arabic names
        
        IMPORTANT: EgyDead has Turkish series with:
        - Arabic dubbed (Ù…Ø¯Ø¨Ù„Ø¬) - Only Arabic title
        - Arabic subtitled (Ù…ØªØ±Ø¬Ù…) - Turkish name + Arabic subs
        
        Search strategy:
        - Turkish names (normalized like "Veliaht") â†’ Find subtitled
        - Arabic names ("Ø§Ù„ÙˆØ±ÙŠØ«") â†’ Find dubbed
        - SKIP English names (not used on EgyDead)
        """
        
        self._log(f"Searching EgyDead with {len(series_names)} names", xbmc.LOGINFO)
        
        results = []
        
        for name in series_names:
            # Skip English names - EgyDead uses Turkish and Arabic only
            if self._is_english_name(name):
                self._log(f"Skipping English name: {name}", xbmc.LOGDEBUG)
                continue
            
            # Search with Turkish (normalized) and Arabic names
            search_query = name
            
            self._log(f"Searching for: {search_query[:30]}...", xbmc.LOGINFO)
            
            search_url = f"{self.base_url}/?s={quote(search_query)}"
            
            try:
                response = self.session.get(search_url, timeout=10)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Find all search results
                items = soup.find_all('li', class_='movieItem')
                
                self._log(f"Found {len(items)} results for '{search_query}'", xbmc.LOGINFO)
                
                for item in items[:10]:  # Check more results to find both types
                    try:
                        link = item.find('a')
                        if not link:
                            continue
                        
                        href = link.get('href')
                        title_elem = link.find('h1', class_='BottomTitle')
                        
                        if href and title_elem:
                            result_title = title_elem.text.strip()
                            
                            # Detect if dubbed or subtitled
                            is_dubbed = 'Ù…Ø¯Ø¨Ù„Ø¬' in result_title
                            is_subbed = 'Ù…ØªØ±Ø¬Ù…' in result_title
                            
                            # Determine audio type
                            if is_dubbed:
                                audio_type = 'dubbed'  # Arabic audio
                                audio_label = 'Ù…Ø¯Ø¨Ù„Ø¬ (Arabic Audio)'
                            elif is_subbed:
                                audio_type = 'subbed'  # Original audio + Arabic subs
                                audio_label = 'Ù…ØªØ±Ø¬Ù… (Arabic Subs)'
                            else:
                                audio_type = 'unknown'
                                audio_label = 'Unknown'
                            
                            results.append({
                                'series_url': href,
                                'series_title': result_title,
                                'audio_type': audio_type,
                                'audio_label': audio_label
                            })
                            
                            self._log(f"Found: {result_title[:40]}... [{audio_label}]", xbmc.LOGDEBUG)
                    
                    except Exception as e:
                        self._log(f"Error parsing result: {e}", xbmc.LOGERROR)
                        continue
            
            except Exception as e:
                self._log(f"Search error for '{search_query}': {e}", xbmc.LOGERROR)
                continue
        
        # Deduplicate by URL but keep both dubbed and subbed versions
        seen = {}
        unique_results = []
        
        for r in results:
            url = r['series_url']
            audio_type = r.get('audio_type', 'unknown')
            key = (url, audio_type)
            
            if key not in seen:
                seen[key] = True
                unique_results.append(r)
        
        self._log(f"Found {len(unique_results)} unique results (dubbed + subbed)", xbmc.LOGINFO)
        
        # Log breakdown
        dubbed_count = sum(1 for r in unique_results if r.get('audio_type') == 'dubbed')
        subbed_count = sum(1 for r in unique_results if r.get('audio_type') == 'subbed')
        self._log(f"Breakdown: {dubbed_count} dubbed, {subbed_count} subtitled", xbmc.LOGINFO)
        
        return unique_results
    
    def _is_english_name(self, text):
        """
        Check if name is English (to skip it)
        
        English names typically:
        - Are common words like "The", "A", etc.
        - Don't contain Turkish special characters (Ã§, ÄŸ, Ä±, Ã¶, ÅŸ, Ã¼)
        - Don't contain Arabic characters
        
        Turkish names like "Veliaht" should NOT be detected as English
        
        Args:
            text (str): Name to check
        
        Returns:
            bool: True if English name (should skip)
        """
        
        if not text:
            return False
        
        # If it has Arabic characters, it's not English
        if self._is_arabic(text):
            return False
        
        # If it has Turkish special characters, it's Turkish (not English)
        turkish_chars = ['Ã§', 'ÄŸ', 'Ä±', 'Ã¶', 'ÅŸ', 'Ã¼', 'Ã‡', 'Äž', 'Ä°', 'Ã–', 'Åž', 'Ãœ']
        if any(char in text for char in turkish_chars):
            return False
        
        # Check for common English words/patterns
        english_indicators = [
            'the ', ' the ', 'a ', ' a ',  # Articles
            ' and ', ' or ', ' of ',        # Conjunctions
            ' in ', ' on ', ' at ',         # Prepositions
        ]
        
        text_lower = text.lower()
        for indicator in english_indicators:
            if indicator in text_lower:
                return True
        
        # If it's a single word with only Latin letters, it could be Turkish
        # Don't filter it out
        return False
    
    def get_episode_servers(self, series_url, season, episode):
        """
        Get UNRESOLVED embed URLs for episode
        
        EgyDead strategy:
        1. series_url is actually the direct episode page (from search)
        2. GET the page
        3. POST with View=1 to get servers
        4. Extract server URLs
        5. Mark if dubbed or subtitled
        """
        
        self._log(f"Getting EgyDead servers for S{season:02d}E{episode:02d}", xbmc.LOGINFO)
        
        # Note: series_url from search can be a dict with audio_type
        audio_type = 'unknown'
        audio_label = ''
        
        if isinstance(series_url, dict):
            # Extract audio type from dict
            audio_type = series_url.get('audio_type', 'unknown')
            audio_label = series_url.get('audio_label', '')
            episode_url = series_url.get('series_url', series_url)
        else:
            # It's a string URL
            episode_url = series_url
        
        servers = self._extract_servers_from_episode(episode_url, audio_type, audio_label)
        
        self._log(f"Found {len(servers)} servers on EgyDead ({audio_label})", xbmc.LOGINFO)
        
        return servers
    
    def _extract_servers_from_episode(self, episode_url, audio_type='unknown', audio_label=''):
        """
        Extract server URLs from episode page
        
        EgyDead requires POST with View=1 to get servers
        """
        
        self._log(f"Fetching episode page: {episode_url[:60]}...", xbmc.LOGDEBUG)
        
        try:
            # First GET request to get the page
            response = self.session.get(episode_url, timeout=10)
            response.raise_for_status()
            
            # Then POST with View=1 to get the servers
            post_response = self.session.post(
                episode_url, 
                data={'View': '1'},
                timeout=10
            )
            post_response.raise_for_status()
            
            html_content = post_response.content
            
        except Exception as e:
            self._log(f"Error fetching episode page: {e}", xbmc.LOGERROR)
            return []
        
        soup = BeautifulSoup(html_content, 'html.parser')
        servers = []
        
        # Method 1: Look for serversList
        servers_list = soup.find('ul', class_='serversList')
        if servers_list:
            for li in servers_list.find_all('li'):
                server_url = li.get('data-link')
                server_name = li.get_text(strip=True)
                if server_url:
                    # Build server name with audio type
                    display_name = f"{server_name}"
                    if audio_label:
                        display_name += f" - {audio_label}"
                    
                    servers.append({
                        'embed_url': server_url,
                        'referer': episode_url,
                        'server_name': display_name,
                        'quality': '',  # Unknown
                        'audio_type': audio_type  # Pass through for filtering
                    })
            
            if servers:
                self._log(f"Found {len(servers)} servers via serversList", xbmc.LOGINFO)
                return servers
        
        # Method 2: Look for iframes in watch area
        watch_area = soup.find('div', class_='watchAreaMaster')
        if watch_area:
            iframes = watch_area.find_all('iframe')
            for idx, iframe in enumerate(iframes, 1):
                src = iframe.get('src') or iframe.get('data-src')
                if src:
                    # Build server name with audio type
                    display_name = f'Server {idx}'
                    if audio_label:
                        display_name += f" - {audio_label}"
                    
                    servers.append({
                        'embed_url': src,
                        'referer': episode_url,
                        'server_name': display_name,
                        'quality': '',
                        'audio_type': audio_type
                    })
            
            if servers:
                self._log(f"Found {len(servers)} servers via watchArea iframes", xbmc.LOGINFO)
                return servers
        
        # Method 3: Look for server buttons/links
        server_buttons = soup.find_all(['button', 'a'], class_=re.compile(r'server|watch|play', re.I))
        for idx, button in enumerate(server_buttons, 1):
            url = button.get('data-link') or button.get('data-url') or button.get('href')
            name = button.get_text(strip=True)
            if url and url.startswith('http'):
                # Build server name with audio type
                display_name = name or f'Server {idx}'
                if audio_label:
                    display_name += f" - {audio_label}"
                
                servers.append({
                    'embed_url': url,
                    'referer': episode_url,
                    'server_name': display_name,
                    'quality': '',
                    'audio_type': audio_type
                })
        
        if servers:
            self._log(f"Found {len(servers)} servers via buttons", xbmc.LOGINFO)
        else:
            self._log("No servers found", xbmc.LOGWARNING)
        
        return servers


# ============================================================================
# TESTING (Optional)
# ============================================================================

if __name__ == '__main__':
    """
    Quick test of EgyDead provider
    Run: python provider_egydead.py
    """
    
    provider = ProviderEgyDead()
    
    # Test search with Turkish, Arabic, and English names
    # English should be skipped
    print("\n=== Testing Search ===")
    print("Testing with: Turkish (Veliaht), Arabic (Ø§Ù„ÙˆØ±ÙŠØ«), English (The Heir)")
    
    results = provider.search_series([
        'Ø§Ù„ÙˆØ±ÙŠØ«',        # Arabic - should search
        'Veliaht',       # Turkish - should search
        'The Heir'       # English - should SKIP
    ])
    
    print(f"\nTotal unique results: {len(results)}\n")
    
    for result in results[:5]:
        audio_type = result.get('audio_type', 'unknown')
        audio_label = result.get('audio_label', '')
        print(f"Title: {result['series_title'][:50]}...")
        print(f"Audio: {audio_label} ({audio_type})")
        print(f"URL: {result['series_url']}")
        print()
    
    # Test get servers (if we have results)
    if results:
        print("\n=== Testing Get Servers ===")
        
        # Test with first result (could be dubbed or subtitled)
        first_result = results[0]
        print(f"Testing: {first_result.get('audio_label', 'Unknown')}")
        
        servers = provider.get_episode_servers(first_result, season=1, episode=1)
        
        for server in servers[:3]:
            print(f"Server: {server['server_name']}")
            print(f"Embed URL: {server['embed_url'][:80]}...")
            print(f"Audio Type: {server.get('audio_type', 'unknown')}")
            print()
